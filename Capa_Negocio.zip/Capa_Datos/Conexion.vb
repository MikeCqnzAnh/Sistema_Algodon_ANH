﻿Module Conexion
    Public Function conexionPrincipal()
        'Return ("Data Source=OSCARMERINO\DESARROLLO;Initial Catalog=ALGODON_2V;Integrated Security=True")
        Return ("Data Source = MSISTEMAS;Initial Catalog=ALGODON_2V;Persist Security Info=True;User ID=sa;Password=Usuario01")
    End Function
End Module
