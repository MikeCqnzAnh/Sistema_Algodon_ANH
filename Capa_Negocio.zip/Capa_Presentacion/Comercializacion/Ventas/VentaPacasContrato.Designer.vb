﻿<CompilerServices.DesignerGenerated()>
Partial Class VentaPacasContrato
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(VentaPacasContrato))
        Me.GbDatosGenerales = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.DgvContratos = New System.Windows.Forms.DataGridView()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.BtnBuscarProd = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TbNoPacas = New System.Windows.Forms.TextBox()
        Me.TbIdContrato = New System.Windows.Forms.TextBox()
        Me.BtCastLarFib = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.BtCastigoMicros = New System.Windows.Forms.Button()
        Me.BtCastigoResFibra = New System.Windows.Forms.Button()
        Me.BtModalidadVenta = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TbPrecioQuintal = New System.Windows.Forms.TextBox()
        Me.TbNombreProductor = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TbHastaPaca = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.DtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TbDesdePaca = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CbPlanta = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TbIdProductor = New System.Windows.Forms.TextBox()
        Me.TbIdVentaPaca = New System.Windows.Forms.TextBox()
        Me.MSMenu = New System.Windows.Forms.MenuStrip()
        Me.NuevoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GuardarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GbCompras = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TbKilosComp = New System.Windows.Forms.TextBox()
        Me.TbPacasComp = New System.Windows.Forms.TextBox()
        Me.TbPacasMarc = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TbPacasCompCont = New System.Windows.Forms.TextBox()
        Me.TbPacasDisp = New System.Windows.Forms.TextBox()
        Me.TbPacasCont = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.DgvAgrupadasClases = New System.Windows.Forms.DataGridView()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DgvAgrupadasCliente = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TcCompras = New System.Windows.Forms.TabControl()
        Me.TP1LiquidacionesAVender = New System.Windows.Forms.TabPage()
        Me.DgvDatosLiquidacion = New System.Windows.Forms.DataGridView()
        Me.TP2LiquidacionesVendidas = New System.Windows.Forms.TabPage()
        Me.DgvLiqVendidas = New System.Windows.Forms.DataGridView()
        Me.TP3PacasAVender = New System.Windows.Forms.TabPage()
        Me.DgvPacasVender = New System.Windows.Forms.DataGridView()
        Me.TP4IndividualVendidas = New System.Windows.Forms.TabPage()
        Me.DgvIndVendidas = New System.Windows.Forms.DataGridView()
        Me.TP5PacasSinClasificar = New System.Windows.Forms.TabPage()
        Me.DgvPacasSinClasif = New System.Windows.Forms.DataGridView()
        Me.GbDatosGenerales.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.DgvContratos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.MSMenu.SuspendLayout()
        Me.GbCompras.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.DgvAgrupadasClases, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DgvAgrupadasCliente, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.TcCompras.SuspendLayout()
        Me.TP1LiquidacionesAVender.SuspendLayout()
        CType(Me.DgvDatosLiquidacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TP2LiquidacionesVendidas.SuspendLayout()
        CType(Me.DgvLiqVendidas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TP3PacasAVender.SuspendLayout()
        CType(Me.DgvPacasVender, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TP4IndividualVendidas.SuspendLayout()
        CType(Me.DgvIndVendidas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TP5PacasSinClasificar.SuspendLayout()
        CType(Me.DgvPacasSinClasif, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GbDatosGenerales
        '
        Me.GbDatosGenerales.Controls.Add(Me.GroupBox6)
        Me.GbDatosGenerales.Controls.Add(Me.GroupBox5)
        Me.GbDatosGenerales.Dock = System.Windows.Forms.DockStyle.Top
        Me.GbDatosGenerales.Location = New System.Drawing.Point(0, 24)
        Me.GbDatosGenerales.Name = "GbDatosGenerales"
        Me.GbDatosGenerales.Size = New System.Drawing.Size(1561, 179)
        Me.GbDatosGenerales.TabIndex = 4
        Me.GbDatosGenerales.TabStop = False
        Me.GbDatosGenerales.Text = "Datos Generales"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.DgvContratos)
        Me.GroupBox6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox6.Location = New System.Drawing.Point(1070, 16)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(488, 160)
        Me.GroupBox6.TabIndex = 2
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Contratos"
        '
        'DgvContratos
        '
        Me.DgvContratos.AllowUserToAddRows = False
        Me.DgvContratos.AllowUserToDeleteRows = False
        Me.DgvContratos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvContratos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvContratos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvContratos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvContratos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvContratos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvContratos.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvContratos.Location = New System.Drawing.Point(3, 16)
        Me.DgvContratos.MultiSelect = False
        Me.DgvContratos.Name = "DgvContratos"
        Me.DgvContratos.RowHeadersVisible = False
        Me.DgvContratos.RowHeadersWidth = 40
        Me.DgvContratos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvContratos.Size = New System.Drawing.Size(482, 141)
        Me.DgvContratos.TabIndex = 12
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.BtnBuscarProd)
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Controls.Add(Me.TbNoPacas)
        Me.GroupBox5.Controls.Add(Me.TbIdContrato)
        Me.GroupBox5.Controls.Add(Me.BtCastLarFib)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.BtCastigoMicros)
        Me.GroupBox5.Controls.Add(Me.BtCastigoResFibra)
        Me.GroupBox5.Controls.Add(Me.BtModalidadVenta)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.TbPrecioQuintal)
        Me.GroupBox5.Controls.Add(Me.TbNombreProductor)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.TbHastaPaca)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.DtpFecha)
        Me.GroupBox5.Controls.Add(Me.Label10)
        Me.GroupBox5.Controls.Add(Me.TbDesdePaca)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Controls.Add(Me.CbPlanta)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Controls.Add(Me.TbIdProductor)
        Me.GroupBox5.Controls.Add(Me.TbIdVentaPaca)
        Me.GroupBox5.Cursor = System.Windows.Forms.Cursors.Default
        Me.GroupBox5.Dock = System.Windows.Forms.DockStyle.Left
        Me.GroupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox5.Location = New System.Drawing.Point(3, 16)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(1067, 160)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        '
        'BtnBuscarProd
        '
        Me.BtnBuscarProd.Location = New System.Drawing.Point(505, 39)
        Me.BtnBuscarProd.Name = "BtnBuscarProd"
        Me.BtnBuscarProd.Size = New System.Drawing.Size(41, 23)
        Me.BtnBuscarProd.TabIndex = 55
        Me.BtnBuscarProd.Text = "..."
        Me.BtnBuscarProd.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(275, 120)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 13)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "No. Pacas"
        '
        'TbNoPacas
        '
        Me.TbNoPacas.Enabled = False
        Me.TbNoPacas.Location = New System.Drawing.Point(354, 117)
        Me.TbNoPacas.Name = "TbNoPacas"
        Me.TbNoPacas.Size = New System.Drawing.Size(192, 20)
        Me.TbNoPacas.TabIndex = 39
        '
        'TbIdContrato
        '
        Me.TbIdContrato.Enabled = False
        Me.TbIdContrato.Location = New System.Drawing.Point(354, 67)
        Me.TbIdContrato.Name = "TbIdContrato"
        Me.TbIdContrato.Size = New System.Drawing.Size(192, 20)
        Me.TbIdContrato.TabIndex = 34
        '
        'BtCastLarFib
        '
        Me.BtCastLarFib.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtCastLarFib.Location = New System.Drawing.Point(986, 15)
        Me.BtCastLarFib.MaximumSize = New System.Drawing.Size(75, 62)
        Me.BtCastLarFib.MinimumSize = New System.Drawing.Size(75, 62)
        Me.BtCastLarFib.Name = "BtCastLarFib"
        Me.BtCastLarFib.Size = New System.Drawing.Size(75, 62)
        Me.BtCastLarFib.TabIndex = 54
        Me.BtCastLarFib.Text = "Castigos por largo de fibra"
        Me.BtCastLarFib.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(275, 70)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(59, 13)
        Me.Label12.TabIndex = 37
        Me.Label12.Text = "Id Contrato"
        '
        'BtCastigoMicros
        '
        Me.BtCastigoMicros.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtCastigoMicros.Location = New System.Drawing.Point(905, 15)
        Me.BtCastigoMicros.MaximumSize = New System.Drawing.Size(75, 62)
        Me.BtCastigoMicros.MinimumSize = New System.Drawing.Size(75, 62)
        Me.BtCastigoMicros.Name = "BtCastigoMicros"
        Me.BtCastigoMicros.Size = New System.Drawing.Size(75, 62)
        Me.BtCastigoMicros.TabIndex = 53
        Me.BtCastigoMicros.Text = "Castigo por micros"
        Me.BtCastigoMicros.UseVisualStyleBackColor = True
        '
        'BtCastigoResFibra
        '
        Me.BtCastigoResFibra.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtCastigoResFibra.Location = New System.Drawing.Point(824, 15)
        Me.BtCastigoResFibra.MaximumSize = New System.Drawing.Size(75, 62)
        Me.BtCastigoResFibra.MinimumSize = New System.Drawing.Size(75, 62)
        Me.BtCastigoResFibra.Name = "BtCastigoResFibra"
        Me.BtCastigoResFibra.Size = New System.Drawing.Size(75, 62)
        Me.BtCastigoResFibra.TabIndex = 52
        Me.BtCastigoResFibra.Text = "Castigos por resistencia de fibra"
        Me.BtCastigoResFibra.UseVisualStyleBackColor = True
        '
        'BtModalidadVenta
        '
        Me.BtModalidadVenta.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtModalidadVenta.Location = New System.Drawing.Point(740, 15)
        Me.BtModalidadVenta.MaximumSize = New System.Drawing.Size(75, 62)
        Me.BtModalidadVenta.MinimumSize = New System.Drawing.Size(75, 62)
        Me.BtModalidadVenta.Name = "BtModalidadVenta"
        Me.BtModalidadVenta.Size = New System.Drawing.Size(75, 62)
        Me.BtModalidadVenta.TabIndex = 51
        Me.BtModalidadVenta.Text = "Modalidad de Venta"
        Me.BtModalidadVenta.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(275, 96)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(73, 13)
        Me.Label14.TabIndex = 48
        Me.Label14.Text = "Precio Quintal"
        '
        'TbPrecioQuintal
        '
        Me.TbPrecioQuintal.Enabled = False
        Me.TbPrecioQuintal.Location = New System.Drawing.Point(354, 93)
        Me.TbPrecioQuintal.Name = "TbPrecioQuintal"
        Me.TbPrecioQuintal.Size = New System.Drawing.Size(192, 20)
        Me.TbPrecioQuintal.TabIndex = 44
        '
        'TbNombreProductor
        '
        Me.TbNombreProductor.Enabled = False
        Me.TbNombreProductor.Location = New System.Drawing.Point(204, 41)
        Me.TbNombreProductor.Name = "TbNombreProductor"
        Me.TbNombreProductor.Size = New System.Drawing.Size(295, 20)
        Me.TbNombreProductor.TabIndex = 39
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 44)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Productor"
        '
        'TbHastaPaca
        '
        Me.TbHastaPaca.Enabled = False
        Me.TbHastaPaca.Location = New System.Drawing.Point(217, 121)
        Me.TbHastaPaca.Name = "TbHastaPaca"
        Me.TbHastaPaca.Size = New System.Drawing.Size(45, 20)
        Me.TbHastaPaca.TabIndex = 31
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 96)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 13)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Fecha"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(181, 124)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(25, 13)
        Me.Label11.TabIndex = 28
        Me.Label11.Text = "A la"
        '
        'DtpFecha
        '
        Me.DtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtpFecha.Location = New System.Drawing.Point(123, 95)
        Me.DtpFecha.Name = "DtpFecha"
        Me.DtpFecha.Size = New System.Drawing.Size(139, 20)
        Me.DtpFecha.TabIndex = 29
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(9, 124)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(59, 13)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "De la paca"
        '
        'TbDesdePaca
        '
        Me.TbDesdePaca.Enabled = False
        Me.TbDesdePaca.Location = New System.Drawing.Point(123, 121)
        Me.TbDesdePaca.Name = "TbDesdePaca"
        Me.TbDesdePaca.Size = New System.Drawing.Size(45, 20)
        Me.TbDesdePaca.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 13)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Planta"
        '
        'CbPlanta
        '
        Me.CbPlanta.FormattingEnabled = True
        Me.CbPlanta.Location = New System.Drawing.Point(123, 67)
        Me.CbPlanta.Name = "CbPlanta"
        Me.CbPlanta.Size = New System.Drawing.Size(139, 21)
        Me.CbPlanta.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "ID Venta"
        Me.Label1.UseWaitCursor = True
        '
        'TbIdProductor
        '
        Me.TbIdProductor.Enabled = False
        Me.TbIdProductor.Location = New System.Drawing.Point(123, 41)
        Me.TbIdProductor.Name = "TbIdProductor"
        Me.TbIdProductor.Size = New System.Drawing.Size(75, 20)
        Me.TbIdProductor.TabIndex = 18
        '
        'TbIdVentaPaca
        '
        Me.TbIdVentaPaca.Enabled = False
        Me.TbIdVentaPaca.Location = New System.Drawing.Point(123, 15)
        Me.TbIdVentaPaca.Name = "TbIdVentaPaca"
        Me.TbIdVentaPaca.Size = New System.Drawing.Size(99, 20)
        Me.TbIdVentaPaca.TabIndex = 17
        Me.TbIdVentaPaca.UseWaitCursor = True
        '
        'MSMenu
        '
        Me.MSMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NuevoToolStripMenuItem, Me.GuardarToolStripMenuItem, Me.ConsultarToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MSMenu.Location = New System.Drawing.Point(0, 0)
        Me.MSMenu.Name = "MSMenu"
        Me.MSMenu.Size = New System.Drawing.Size(1561, 24)
        Me.MSMenu.TabIndex = 3
        '
        'NuevoToolStripMenuItem
        '
        Me.NuevoToolStripMenuItem.Image = CType(resources.GetObject("NuevoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NuevoToolStripMenuItem.Name = "NuevoToolStripMenuItem"
        Me.NuevoToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.NuevoToolStripMenuItem.Text = "Nuevo"
        '
        'GuardarToolStripMenuItem
        '
        Me.GuardarToolStripMenuItem.Image = CType(resources.GetObject("GuardarToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GuardarToolStripMenuItem.Name = "GuardarToolStripMenuItem"
        Me.GuardarToolStripMenuItem.Size = New System.Drawing.Size(77, 20)
        Me.GuardarToolStripMenuItem.Text = "Guardar"
        '
        'ConsultarToolStripMenuItem
        '
        Me.ConsultarToolStripMenuItem.Image = CType(resources.GetObject("ConsultarToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ConsultarToolStripMenuItem.Name = "ConsultarToolStripMenuItem"
        Me.ConsultarToolStripMenuItem.Size = New System.Drawing.Size(86, 20)
        Me.ConsultarToolStripMenuItem.Text = "Consultar"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Image = CType(resources.GetObject("SalirToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'GbCompras
        '
        Me.GbCompras.Controls.Add(Me.GroupBox4)
        Me.GbCompras.Controls.Add(Me.GroupBox2)
        Me.GbCompras.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.GbCompras.Location = New System.Drawing.Point(0, 544)
        Me.GbCompras.Name = "GbCompras"
        Me.GbCompras.Size = New System.Drawing.Size(1561, 186)
        Me.GbCompras.TabIndex = 5
        Me.GbCompras.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Panel1)
        Me.GroupBox4.Controls.Add(Me.DgvAgrupadasClases)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox4.Location = New System.Drawing.Point(378, 16)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(1180, 167)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.TbKilosComp)
        Me.Panel1.Controls.Add(Me.TbPacasComp)
        Me.Panel1.Controls.Add(Me.TbPacasMarc)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.TbPacasCompCont)
        Me.Panel1.Controls.Add(Me.TbPacasDisp)
        Me.Panel1.Controls.Add(Me.TbPacasCont)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(421, 16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(756, 148)
        Me.Panel1.TabIndex = 4
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.Control
        Me.Label23.Location = New System.Drawing.Point(270, 65)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(99, 13)
        Me.Label23.TabIndex = 28
        Me.Label23.Text = "Kilos comprados"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.Control
        Me.Label22.Location = New System.Drawing.Point(270, 39)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(107, 13)
        Me.Label22.TabIndex = 27
        Me.Label22.Text = "Pacas compradas"
        '
        'TbKilosComp
        '
        Me.TbKilosComp.Enabled = False
        Me.TbKilosComp.Location = New System.Drawing.Point(390, 62)
        Me.TbKilosComp.Name = "TbKilosComp"
        Me.TbKilosComp.Size = New System.Drawing.Size(100, 20)
        Me.TbKilosComp.TabIndex = 26
        '
        'TbPacasComp
        '
        Me.TbPacasComp.Enabled = False
        Me.TbPacasComp.Location = New System.Drawing.Point(390, 36)
        Me.TbPacasComp.Name = "TbPacasComp"
        Me.TbPacasComp.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasComp.TabIndex = 25
        '
        'TbPacasMarc
        '
        Me.TbPacasMarc.Enabled = False
        Me.TbPacasMarc.Location = New System.Drawing.Point(390, 10)
        Me.TbPacasMarc.Name = "TbPacasMarc"
        Me.TbPacasMarc.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasMarc.TabIndex = 24
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.Control
        Me.Label21.Location = New System.Drawing.Point(270, 13)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(100, 13)
        Me.Label21.TabIndex = 23
        Me.Label21.Text = "Pacas marcadas"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.SystemColors.Control
        Me.Label20.Location = New System.Drawing.Point(13, 65)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(132, 13)
        Me.Label20.TabIndex = 22
        Me.Label20.Text = "Pacas comp. Contrato"
        '
        'TbPacasCompCont
        '
        Me.TbPacasCompCont.Enabled = False
        Me.TbPacasCompCont.Location = New System.Drawing.Point(155, 62)
        Me.TbPacasCompCont.Name = "TbPacasCompCont"
        Me.TbPacasCompCont.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasCompCont.TabIndex = 21
        '
        'TbPacasDisp
        '
        Me.TbPacasDisp.Enabled = False
        Me.TbPacasDisp.Location = New System.Drawing.Point(155, 36)
        Me.TbPacasDisp.Name = "TbPacasDisp"
        Me.TbPacasDisp.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasDisp.TabIndex = 20
        '
        'TbPacasCont
        '
        Me.TbPacasCont.Enabled = False
        Me.TbPacasCont.Location = New System.Drawing.Point(155, 10)
        Me.TbPacasCont.Name = "TbPacasCont"
        Me.TbPacasCont.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasCont.TabIndex = 19
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.Control
        Me.Label19.Location = New System.Drawing.Point(13, 39)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(109, 13)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "Pacas disponibles"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.Control
        Me.Label18.Location = New System.Drawing.Point(13, 13)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(113, 13)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "Pacas contratadas"
        '
        'DgvAgrupadasClases
        '
        Me.DgvAgrupadasClases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvAgrupadasClases.Location = New System.Drawing.Point(6, 16)
        Me.DgvAgrupadasClases.Name = "DgvAgrupadasClases"
        Me.DgvAgrupadasClases.Size = New System.Drawing.Size(409, 148)
        Me.DgvAgrupadasClases.TabIndex = 3
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.LightPink
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(7, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(123, 13)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Agrupadas por clase"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DgvAgrupadasCliente)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Left
        Me.GroupBox2.Location = New System.Drawing.Point(3, 16)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(375, 167)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        '
        'DgvAgrupadasCliente
        '
        Me.DgvAgrupadasCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvAgrupadasCliente.Location = New System.Drawing.Point(7, 17)
        Me.DgvAgrupadasCliente.Name = "DgvAgrupadasCliente"
        Me.DgvAgrupadasCliente.Size = New System.Drawing.Size(362, 141)
        Me.DgvAgrupadasCliente.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.LightPink
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(131, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Agrupadas por cliente"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TcCompras)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 203)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1561, 341)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        '
        'TcCompras
        '
        Me.TcCompras.Controls.Add(Me.TP1LiquidacionesAVender)
        Me.TcCompras.Controls.Add(Me.TP2LiquidacionesVendidas)
        Me.TcCompras.Controls.Add(Me.TP3PacasAVender)
        Me.TcCompras.Controls.Add(Me.TP4IndividualVendidas)
        Me.TcCompras.Controls.Add(Me.TP5PacasSinClasificar)
        Me.TcCompras.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TcCompras.Location = New System.Drawing.Point(3, 16)
        Me.TcCompras.Name = "TcCompras"
        Me.TcCompras.SelectedIndex = 0
        Me.TcCompras.Size = New System.Drawing.Size(1555, 322)
        Me.TcCompras.TabIndex = 1
        '
        'TP1LiquidacionesAVender
        '
        Me.TP1LiquidacionesAVender.BackColor = System.Drawing.Color.Transparent
        Me.TP1LiquidacionesAVender.Controls.Add(Me.DgvDatosLiquidacion)
        Me.TP1LiquidacionesAVender.Location = New System.Drawing.Point(4, 22)
        Me.TP1LiquidacionesAVender.Name = "TP1LiquidacionesAVender"
        Me.TP1LiquidacionesAVender.Padding = New System.Windows.Forms.Padding(3)
        Me.TP1LiquidacionesAVender.Size = New System.Drawing.Size(1547, 296)
        Me.TP1LiquidacionesAVender.TabIndex = 0
        Me.TP1LiquidacionesAVender.Text = "Liquidaciones a Vender"
        '
        'DgvDatosLiquidacion
        '
        Me.DgvDatosLiquidacion.AllowUserToAddRows = False
        Me.DgvDatosLiquidacion.AllowUserToDeleteRows = False
        Me.DgvDatosLiquidacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvDatosLiquidacion.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvDatosLiquidacion.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvDatosLiquidacion.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvDatosLiquidacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvDatosLiquidacion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvDatosLiquidacion.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvDatosLiquidacion.Location = New System.Drawing.Point(3, 3)
        Me.DgvDatosLiquidacion.MultiSelect = False
        Me.DgvDatosLiquidacion.Name = "DgvDatosLiquidacion"
        Me.DgvDatosLiquidacion.RowHeadersVisible = False
        Me.DgvDatosLiquidacion.RowHeadersWidth = 40
        Me.DgvDatosLiquidacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvDatosLiquidacion.Size = New System.Drawing.Size(1541, 290)
        Me.DgvDatosLiquidacion.TabIndex = 13
        '
        'TP2LiquidacionesVendidas
        '
        Me.TP2LiquidacionesVendidas.Controls.Add(Me.DgvLiqVendidas)
        Me.TP2LiquidacionesVendidas.Location = New System.Drawing.Point(4, 22)
        Me.TP2LiquidacionesVendidas.Name = "TP2LiquidacionesVendidas"
        Me.TP2LiquidacionesVendidas.Padding = New System.Windows.Forms.Padding(3)
        Me.TP2LiquidacionesVendidas.Size = New System.Drawing.Size(1547, 296)
        Me.TP2LiquidacionesVendidas.TabIndex = 1
        Me.TP2LiquidacionesVendidas.Text = "Liquidaciones Vendidas"
        Me.TP2LiquidacionesVendidas.UseVisualStyleBackColor = True
        '
        'DgvLiqVendidas
        '
        Me.DgvLiqVendidas.AllowUserToAddRows = False
        Me.DgvLiqVendidas.AllowUserToDeleteRows = False
        Me.DgvLiqVendidas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvLiqVendidas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvLiqVendidas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvLiqVendidas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvLiqVendidas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvLiqVendidas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvLiqVendidas.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvLiqVendidas.Location = New System.Drawing.Point(3, 3)
        Me.DgvLiqVendidas.MultiSelect = False
        Me.DgvLiqVendidas.Name = "DgvLiqVendidas"
        Me.DgvLiqVendidas.ReadOnly = True
        Me.DgvLiqVendidas.RowHeadersVisible = False
        Me.DgvLiqVendidas.RowHeadersWidth = 40
        Me.DgvLiqVendidas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvLiqVendidas.Size = New System.Drawing.Size(1541, 290)
        Me.DgvLiqVendidas.TabIndex = 14
        '
        'TP3PacasAVender
        '
        Me.TP3PacasAVender.Controls.Add(Me.DgvPacasVender)
        Me.TP3PacasAVender.Location = New System.Drawing.Point(4, 22)
        Me.TP3PacasAVender.Name = "TP3PacasAVender"
        Me.TP3PacasAVender.Padding = New System.Windows.Forms.Padding(3)
        Me.TP3PacasAVender.Size = New System.Drawing.Size(1547, 296)
        Me.TP3PacasAVender.TabIndex = 2
        Me.TP3PacasAVender.Text = "Pacas a Vender"
        Me.TP3PacasAVender.UseVisualStyleBackColor = True
        '
        'DgvPacasVender
        '
        Me.DgvPacasVender.AllowUserToAddRows = False
        Me.DgvPacasVender.AllowUserToDeleteRows = False
        Me.DgvPacasVender.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvPacasVender.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvPacasVender.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvPacasVender.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvPacasVender.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvPacasVender.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvPacasVender.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvPacasVender.Location = New System.Drawing.Point(3, 3)
        Me.DgvPacasVender.MultiSelect = False
        Me.DgvPacasVender.Name = "DgvPacasVender"
        Me.DgvPacasVender.RowHeadersVisible = False
        Me.DgvPacasVender.RowHeadersWidth = 40
        Me.DgvPacasVender.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvPacasVender.Size = New System.Drawing.Size(1541, 290)
        Me.DgvPacasVender.TabIndex = 14
        '
        'TP4IndividualVendidas
        '
        Me.TP4IndividualVendidas.Controls.Add(Me.DgvIndVendidas)
        Me.TP4IndividualVendidas.Location = New System.Drawing.Point(4, 22)
        Me.TP4IndividualVendidas.Name = "TP4IndividualVendidas"
        Me.TP4IndividualVendidas.Padding = New System.Windows.Forms.Padding(3)
        Me.TP4IndividualVendidas.Size = New System.Drawing.Size(1547, 296)
        Me.TP4IndividualVendidas.TabIndex = 3
        Me.TP4IndividualVendidas.Text = "Individual Vendidas (por paca)"
        Me.TP4IndividualVendidas.UseVisualStyleBackColor = True
        '
        'DgvIndVendidas
        '
        Me.DgvIndVendidas.AllowUserToAddRows = False
        Me.DgvIndVendidas.AllowUserToDeleteRows = False
        Me.DgvIndVendidas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvIndVendidas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvIndVendidas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvIndVendidas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvIndVendidas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvIndVendidas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvIndVendidas.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvIndVendidas.Location = New System.Drawing.Point(3, 3)
        Me.DgvIndVendidas.MultiSelect = False
        Me.DgvIndVendidas.Name = "DgvIndVendidas"
        Me.DgvIndVendidas.ReadOnly = True
        Me.DgvIndVendidas.RowHeadersVisible = False
        Me.DgvIndVendidas.RowHeadersWidth = 40
        Me.DgvIndVendidas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvIndVendidas.Size = New System.Drawing.Size(1541, 290)
        Me.DgvIndVendidas.TabIndex = 14
        '
        'TP5PacasSinClasificar
        '
        Me.TP5PacasSinClasificar.Controls.Add(Me.DgvPacasSinClasif)
        Me.TP5PacasSinClasificar.Location = New System.Drawing.Point(4, 22)
        Me.TP5PacasSinClasificar.Name = "TP5PacasSinClasificar"
        Me.TP5PacasSinClasificar.Padding = New System.Windows.Forms.Padding(3)
        Me.TP5PacasSinClasificar.Size = New System.Drawing.Size(1547, 296)
        Me.TP5PacasSinClasificar.TabIndex = 4
        Me.TP5PacasSinClasificar.Text = "Pacas Sin Clasificar"
        Me.TP5PacasSinClasificar.UseVisualStyleBackColor = True
        '
        'DgvPacasSinClasif
        '
        Me.DgvPacasSinClasif.AllowUserToAddRows = False
        Me.DgvPacasSinClasif.AllowUserToDeleteRows = False
        Me.DgvPacasSinClasif.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvPacasSinClasif.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvPacasSinClasif.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvPacasSinClasif.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvPacasSinClasif.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvPacasSinClasif.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvPacasSinClasif.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvPacasSinClasif.Location = New System.Drawing.Point(3, 3)
        Me.DgvPacasSinClasif.MultiSelect = False
        Me.DgvPacasSinClasif.Name = "DgvPacasSinClasif"
        Me.DgvPacasSinClasif.ReadOnly = True
        Me.DgvPacasSinClasif.RowHeadersVisible = False
        Me.DgvPacasSinClasif.RowHeadersWidth = 40
        Me.DgvPacasSinClasif.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvPacasSinClasif.Size = New System.Drawing.Size(1541, 290)
        Me.DgvPacasSinClasif.TabIndex = 14
        '
        'VentaPacasContrato
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(1561, 730)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GbCompras)
        Me.Controls.Add(Me.GbDatosGenerales)
        Me.Controls.Add(Me.MSMenu)
        Me.MinimumSize = New System.Drawing.Size(1415, 651)
        Me.Name = "VentaPacasContrato"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Venta de Pacas Por Contrato"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GbDatosGenerales.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.DgvContratos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.MSMenu.ResumeLayout(False)
        Me.MSMenu.PerformLayout()
        Me.GbCompras.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DgvAgrupadasClases, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.DgvAgrupadasCliente, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.TcCompras.ResumeLayout(False)
        Me.TP1LiquidacionesAVender.ResumeLayout(False)
        CType(Me.DgvDatosLiquidacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TP2LiquidacionesVendidas.ResumeLayout(False)
        CType(Me.DgvLiqVendidas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TP3PacasAVender.ResumeLayout(False)
        CType(Me.DgvPacasVender, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TP4IndividualVendidas.ResumeLayout(False)
        CType(Me.DgvIndVendidas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TP5PacasSinClasificar.ResumeLayout(False)
        CType(Me.DgvPacasSinClasif, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GbDatosGenerales As GroupBox
    Friend WithEvents MSMenu As MenuStrip
    Friend WithEvents NuevoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GuardarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConsultarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GbCompras As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TcCompras As TabControl
    Friend WithEvents TP1LiquidacionesAVender As TabPage
    Friend WithEvents TP2LiquidacionesVendidas As TabPage
    Friend WithEvents TP3PacasAVender As TabPage
    Friend WithEvents TP4IndividualVendidas As TabPage
    Friend WithEvents TP5PacasSinClasificar As TabPage
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents BtCastLarFib As Button
    Friend WithEvents BtCastigoMicros As Button
    Friend WithEvents BtCastigoResFibra As Button
    Friend WithEvents BtModalidadVenta As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TbPrecioQuintal As TextBox
    Friend WithEvents TbNoPacas As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TbHastaPaca As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents DtpFecha As DateTimePicker
    Friend WithEvents Label10 As Label
    Friend WithEvents TbDesdePaca As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents CbPlanta As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TbIdProductor As TextBox
    Friend WithEvents TbIdVentaPaca As TextBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents TbNombreProductor As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents TbIdContrato As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents DgvAgrupadasCliente As DataGridView
    Friend WithEvents DgvAgrupadasClases As DataGridView
    Friend WithEvents BtnBuscarProd As Button
    Friend WithEvents DgvContratos As DataGridView
    Friend WithEvents DgvDatosLiquidacion As DataGridView
    Friend WithEvents DgvLiqVendidas As DataGridView
    Friend WithEvents DgvPacasVender As DataGridView
    Friend WithEvents DgvIndVendidas As DataGridView
    Friend WithEvents DgvPacasSinClasif As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents TbKilosComp As TextBox
    Friend WithEvents TbPacasComp As TextBox
    Friend WithEvents TbPacasMarc As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents TbPacasCompCont As TextBox
    Friend WithEvents TbPacasDisp As TextBox
    Friend WithEvents TbPacasCont As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
End Class
