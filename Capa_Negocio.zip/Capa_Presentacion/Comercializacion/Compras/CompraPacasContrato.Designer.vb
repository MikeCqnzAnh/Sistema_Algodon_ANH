﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CompraPacasContrato
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CompraPacasContrato))
        Me.GbDatosGenerales = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BtCastLarFib = New System.Windows.Forms.Button()
        Me.BtnBuscarProd = New System.Windows.Forms.Button()
        Me.BtCastigoMicros = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtCastigoResFibra = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.BtModalidadCompra = New System.Windows.Forms.Button()
        Me.TbIdCompraPaca = New System.Windows.Forms.TextBox()
        Me.TbNoPacas = New System.Windows.Forms.TextBox()
        Me.TbIdProductor = New System.Windows.Forms.TextBox()
        Me.TbIdContrato = New System.Windows.Forms.TextBox()
        Me.CbPlanta = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.DtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TbNombreProductor = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TbPrecioQuintal = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.DgvContratos = New System.Windows.Forms.DataGridView()
        Me.TbHastaPaca = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TbDesdePaca = New System.Windows.Forms.TextBox()
        Me.MSMenu = New System.Windows.Forms.MenuStrip()
        Me.NuevoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GuardarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GbCompras = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.DgvAgrupadasClases = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TbPacasComp = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TbKilosComp = New System.Windows.Forms.TextBox()
        Me.TbPacasContratadas = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TbPacasCompCont = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DgvAgrupadasCliente = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TbPacasDisp = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TbPacasMarc = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TcCompras = New System.Windows.Forms.TabControl()
        Me.TP1LiquidacionesAComprar = New System.Windows.Forms.TabPage()
        Me.DgvDatosLiquidacion = New System.Windows.Forms.DataGridView()
        Me.TP3PacasAComprar = New System.Windows.Forms.TabPage()
        Me.DgvPacasComprar = New System.Windows.Forms.DataGridView()
        Me.GbFiltrado = New System.Windows.Forms.GroupBox()
        Me.BtReiniciaFiltro = New System.Windows.Forms.Button()
        Me.BtFiltro = New System.Windows.Forms.Button()
        Me.CbClases = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TP2LiquidacionesCompradas = New System.Windows.Forms.TabPage()
        Me.DgvLiqCompradas = New System.Windows.Forms.DataGridView()
        Me.TP4IndividualCompradas = New System.Windows.Forms.TabPage()
        Me.DgvIndCompradas = New System.Windows.Forms.DataGridView()
        Me.TP5PacasSinClasificar = New System.Windows.Forms.TabPage()
        Me.DgvPacasSinClasif = New System.Windows.Forms.DataGridView()
        Me.GbCompraActual = New System.Windows.Forms.GroupBox()
        Me.TbKilosSeleccionados = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.GbDatosGenerales.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.DgvContratos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MSMenu.SuspendLayout()
        Me.GbCompras.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DgvAgrupadasClases, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DgvAgrupadasCliente, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TcCompras.SuspendLayout()
        Me.TP1LiquidacionesAComprar.SuspendLayout()
        CType(Me.DgvDatosLiquidacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TP3PacasAComprar.SuspendLayout()
        CType(Me.DgvPacasComprar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GbFiltrado.SuspendLayout()
        Me.TP2LiquidacionesCompradas.SuspendLayout()
        CType(Me.DgvLiqCompradas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TP4IndividualCompradas.SuspendLayout()
        CType(Me.DgvIndCompradas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TP5PacasSinClasificar.SuspendLayout()
        CType(Me.DgvPacasSinClasif, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GbCompraActual.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GbDatosGenerales
        '
        Me.GbDatosGenerales.Controls.Add(Me.Panel2)
        Me.GbDatosGenerales.Controls.Add(Me.GroupBox6)
        Me.GbDatosGenerales.Dock = System.Windows.Forms.DockStyle.Top
        Me.GbDatosGenerales.Location = New System.Drawing.Point(0, 24)
        Me.GbDatosGenerales.Name = "GbDatosGenerales"
        Me.GbDatosGenerales.Size = New System.Drawing.Size(1399, 172)
        Me.GbDatosGenerales.TabIndex = 4
        Me.GbDatosGenerales.TabStop = False
        Me.GbDatosGenerales.Text = "Datos Generales"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.BtCastLarFib)
        Me.Panel2.Controls.Add(Me.BtnBuscarProd)
        Me.Panel2.Controls.Add(Me.BtCastigoMicros)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.BtCastigoResFibra)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.BtModalidadCompra)
        Me.Panel2.Controls.Add(Me.TbIdCompraPaca)
        Me.Panel2.Controls.Add(Me.TbNoPacas)
        Me.Panel2.Controls.Add(Me.TbIdProductor)
        Me.Panel2.Controls.Add(Me.TbIdContrato)
        Me.Panel2.Controls.Add(Me.CbPlanta)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.DtpFecha)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.TbNombreProductor)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.TbPrecioQuintal)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 16)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(949, 153)
        Me.Panel2.TabIndex = 3
        '
        'BtCastLarFib
        '
        Me.BtCastLarFib.Location = New System.Drawing.Point(868, 13)
        Me.BtCastLarFib.MaximumSize = New System.Drawing.Size(75, 62)
        Me.BtCastLarFib.MinimumSize = New System.Drawing.Size(75, 62)
        Me.BtCastLarFib.Name = "BtCastLarFib"
        Me.BtCastLarFib.Size = New System.Drawing.Size(75, 62)
        Me.BtCastLarFib.TabIndex = 54
        Me.BtCastLarFib.Text = "Castigos por largo de fibra"
        Me.BtCastLarFib.UseVisualStyleBackColor = True
        '
        'BtnBuscarProd
        '
        Me.BtnBuscarProd.Location = New System.Drawing.Point(499, 37)
        Me.BtnBuscarProd.Name = "BtnBuscarProd"
        Me.BtnBuscarProd.Size = New System.Drawing.Size(41, 23)
        Me.BtnBuscarProd.TabIndex = 55
        Me.BtnBuscarProd.Text = "..."
        Me.BtnBuscarProd.UseVisualStyleBackColor = True
        '
        'BtCastigoMicros
        '
        Me.BtCastigoMicros.Location = New System.Drawing.Point(787, 13)
        Me.BtCastigoMicros.MaximumSize = New System.Drawing.Size(75, 62)
        Me.BtCastigoMicros.MinimumSize = New System.Drawing.Size(75, 62)
        Me.BtCastigoMicros.Name = "BtCastigoMicros"
        Me.BtCastigoMicros.Size = New System.Drawing.Size(75, 62)
        Me.BtCastigoMicros.TabIndex = 53
        Me.BtCastigoMicros.Text = "Castigo por micros"
        Me.BtCastigoMicros.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "ID Compra"
        Me.Label1.UseWaitCursor = True
        '
        'BtCastigoResFibra
        '
        Me.BtCastigoResFibra.Location = New System.Drawing.Point(706, 13)
        Me.BtCastigoResFibra.MaximumSize = New System.Drawing.Size(75, 62)
        Me.BtCastigoResFibra.MinimumSize = New System.Drawing.Size(75, 62)
        Me.BtCastigoResFibra.Name = "BtCastigoResFibra"
        Me.BtCastigoResFibra.Size = New System.Drawing.Size(75, 62)
        Me.BtCastigoResFibra.TabIndex = 52
        Me.BtCastigoResFibra.Text = "Castigos por resistencia de fibra"
        Me.BtCastigoResFibra.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(269, 120)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 13)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "No. Pacas"
        '
        'BtModalidadCompra
        '
        Me.BtModalidadCompra.Location = New System.Drawing.Point(622, 13)
        Me.BtModalidadCompra.MaximumSize = New System.Drawing.Size(75, 62)
        Me.BtModalidadCompra.MinimumSize = New System.Drawing.Size(75, 62)
        Me.BtModalidadCompra.Name = "BtModalidadCompra"
        Me.BtModalidadCompra.Size = New System.Drawing.Size(75, 62)
        Me.BtModalidadCompra.TabIndex = 51
        Me.BtModalidadCompra.Text = "Modalidad de compra"
        Me.BtModalidadCompra.UseVisualStyleBackColor = True
        '
        'TbIdCompraPaca
        '
        Me.TbIdCompraPaca.Enabled = False
        Me.TbIdCompraPaca.Location = New System.Drawing.Point(117, 13)
        Me.TbIdCompraPaca.Name = "TbIdCompraPaca"
        Me.TbIdCompraPaca.Size = New System.Drawing.Size(99, 20)
        Me.TbIdCompraPaca.TabIndex = 17
        Me.TbIdCompraPaca.UseWaitCursor = True
        '
        'TbNoPacas
        '
        Me.TbNoPacas.Enabled = False
        Me.TbNoPacas.Location = New System.Drawing.Point(348, 117)
        Me.TbNoPacas.Name = "TbNoPacas"
        Me.TbNoPacas.Size = New System.Drawing.Size(192, 20)
        Me.TbNoPacas.TabIndex = 39
        '
        'TbIdProductor
        '
        Me.TbIdProductor.Enabled = False
        Me.TbIdProductor.Location = New System.Drawing.Point(117, 39)
        Me.TbIdProductor.Name = "TbIdProductor"
        Me.TbIdProductor.Size = New System.Drawing.Size(75, 20)
        Me.TbIdProductor.TabIndex = 18
        '
        'TbIdContrato
        '
        Me.TbIdContrato.Enabled = False
        Me.TbIdContrato.Location = New System.Drawing.Point(348, 65)
        Me.TbIdContrato.Name = "TbIdContrato"
        Me.TbIdContrato.Size = New System.Drawing.Size(192, 20)
        Me.TbIdContrato.TabIndex = 34
        '
        'CbPlanta
        '
        Me.CbPlanta.FormattingEnabled = True
        Me.CbPlanta.Location = New System.Drawing.Point(117, 65)
        Me.CbPlanta.Name = "CbPlanta"
        Me.CbPlanta.Size = New System.Drawing.Size(139, 21)
        Me.CbPlanta.TabIndex = 20
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 13)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Planta"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(269, 68)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(59, 13)
        Me.Label12.TabIndex = 37
        Me.Label12.Text = "Id Contrato"
        '
        'DtpFecha
        '
        Me.DtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtpFecha.Location = New System.Drawing.Point(117, 93)
        Me.DtpFecha.Name = "DtpFecha"
        Me.DtpFecha.Size = New System.Drawing.Size(139, 20)
        Me.DtpFecha.TabIndex = 29
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 94)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 13)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Fecha"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 42)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Productor"
        '
        'TbNombreProductor
        '
        Me.TbNombreProductor.Enabled = False
        Me.TbNombreProductor.Location = New System.Drawing.Point(198, 39)
        Me.TbNombreProductor.Name = "TbNombreProductor"
        Me.TbNombreProductor.Size = New System.Drawing.Size(295, 20)
        Me.TbNombreProductor.TabIndex = 39
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(269, 94)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(73, 13)
        Me.Label14.TabIndex = 48
        Me.Label14.Text = "Precio Quintal"
        '
        'TbPrecioQuintal
        '
        Me.TbPrecioQuintal.Enabled = False
        Me.TbPrecioQuintal.Location = New System.Drawing.Point(348, 91)
        Me.TbPrecioQuintal.Name = "TbPrecioQuintal"
        Me.TbPrecioQuintal.Size = New System.Drawing.Size(192, 20)
        Me.TbPrecioQuintal.TabIndex = 44
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.DgvContratos)
        Me.GroupBox6.Dock = System.Windows.Forms.DockStyle.Right
        Me.GroupBox6.Location = New System.Drawing.Point(952, 16)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(444, 153)
        Me.GroupBox6.TabIndex = 2
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Contratos"
        '
        'DgvContratos
        '
        Me.DgvContratos.AllowUserToAddRows = False
        Me.DgvContratos.AllowUserToDeleteRows = False
        Me.DgvContratos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvContratos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvContratos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvContratos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvContratos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvContratos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvContratos.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvContratos.Location = New System.Drawing.Point(3, 16)
        Me.DgvContratos.MultiSelect = False
        Me.DgvContratos.Name = "DgvContratos"
        Me.DgvContratos.RowHeadersVisible = False
        Me.DgvContratos.RowHeadersWidth = 40
        Me.DgvContratos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvContratos.Size = New System.Drawing.Size(438, 134)
        Me.DgvContratos.TabIndex = 12
        '
        'TbHastaPaca
        '
        Me.TbHastaPaca.Location = New System.Drawing.Point(217, 13)
        Me.TbHastaPaca.Name = "TbHastaPaca"
        Me.TbHastaPaca.Size = New System.Drawing.Size(45, 20)
        Me.TbHastaPaca.TabIndex = 31
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(181, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(25, 13)
        Me.Label11.TabIndex = 28
        Me.Label11.Text = "A la"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(9, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(59, 13)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "De la paca"
        '
        'TbDesdePaca
        '
        Me.TbDesdePaca.Location = New System.Drawing.Point(123, 13)
        Me.TbDesdePaca.Name = "TbDesdePaca"
        Me.TbDesdePaca.Size = New System.Drawing.Size(45, 20)
        Me.TbDesdePaca.TabIndex = 25
        '
        'MSMenu
        '
        Me.MSMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NuevoToolStripMenuItem, Me.GuardarToolStripMenuItem, Me.ConsultarToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MSMenu.Location = New System.Drawing.Point(0, 0)
        Me.MSMenu.Name = "MSMenu"
        Me.MSMenu.Size = New System.Drawing.Size(1399, 24)
        Me.MSMenu.TabIndex = 3
        '
        'NuevoToolStripMenuItem
        '
        Me.NuevoToolStripMenuItem.Image = CType(resources.GetObject("NuevoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NuevoToolStripMenuItem.Name = "NuevoToolStripMenuItem"
        Me.NuevoToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.NuevoToolStripMenuItem.Text = "Nuevo"
        '
        'GuardarToolStripMenuItem
        '
        Me.GuardarToolStripMenuItem.Image = CType(resources.GetObject("GuardarToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GuardarToolStripMenuItem.Name = "GuardarToolStripMenuItem"
        Me.GuardarToolStripMenuItem.Size = New System.Drawing.Size(77, 20)
        Me.GuardarToolStripMenuItem.Text = "Guardar"
        '
        'ConsultarToolStripMenuItem
        '
        Me.ConsultarToolStripMenuItem.Image = CType(resources.GetObject("ConsultarToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ConsultarToolStripMenuItem.Name = "ConsultarToolStripMenuItem"
        Me.ConsultarToolStripMenuItem.Size = New System.Drawing.Size(86, 20)
        Me.ConsultarToolStripMenuItem.Text = "Consultar"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Image = CType(resources.GetObject("SalirToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'GbCompras
        '
        Me.GbCompras.Controls.Add(Me.GroupBox4)
        Me.GbCompras.Controls.Add(Me.GroupBox2)
        Me.GbCompras.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.GbCompras.Location = New System.Drawing.Point(0, 544)
        Me.GbCompras.Name = "GbCompras"
        Me.GbCompras.Size = New System.Drawing.Size(1399, 186)
        Me.GbCompras.TabIndex = 5
        Me.GbCompras.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.DgvAgrupadasClases)
        Me.GroupBox4.Controls.Add(Me.Panel1)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox4.Location = New System.Drawing.Point(292, 16)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(1104, 167)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        '
        'DgvAgrupadasClases
        '
        Me.DgvAgrupadasClases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvAgrupadasClases.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvAgrupadasClases.Location = New System.Drawing.Point(3, 16)
        Me.DgvAgrupadasClases.Name = "DgvAgrupadasClases"
        Me.DgvAgrupadasClases.Size = New System.Drawing.Size(314, 148)
        Me.DgvAgrupadasClases.TabIndex = 5
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.TbPacasComp)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.TbKilosComp)
        Me.Panel1.Controls.Add(Me.TbPacasContratadas)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.TbPacasCompCont)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(317, 16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(784, 148)
        Me.Panel1.TabIndex = 4
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.Control
        Me.Label23.Location = New System.Drawing.Point(274, 61)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(99, 13)
        Me.Label23.TabIndex = 28
        Me.Label23.Text = "Kilos comprados"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.Control
        Me.Label22.Location = New System.Drawing.Point(273, 15)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(107, 13)
        Me.Label22.TabIndex = 27
        Me.Label22.Text = "Pacas compradas"
        '
        'TbPacasComp
        '
        Me.TbPacasComp.Enabled = False
        Me.TbPacasComp.Location = New System.Drawing.Point(393, 12)
        Me.TbPacasComp.Name = "TbPacasComp"
        Me.TbPacasComp.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasComp.TabIndex = 25
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.SystemColors.Control
        Me.Label20.Location = New System.Drawing.Point(499, 15)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(168, 13)
        Me.Label20.TabIndex = 22
        Me.Label20.Text = "Pacas P/Completar Contrato"
        '
        'TbKilosComp
        '
        Me.TbKilosComp.Enabled = False
        Me.TbKilosComp.Location = New System.Drawing.Point(393, 58)
        Me.TbKilosComp.Name = "TbKilosComp"
        Me.TbKilosComp.Size = New System.Drawing.Size(100, 20)
        Me.TbKilosComp.TabIndex = 26
        '
        'TbPacasContratadas
        '
        Me.TbPacasContratadas.Enabled = False
        Me.TbPacasContratadas.Location = New System.Drawing.Point(164, 12)
        Me.TbPacasContratadas.Name = "TbPacasContratadas"
        Me.TbPacasContratadas.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasContratadas.TabIndex = 19
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.Control
        Me.Label18.Location = New System.Drawing.Point(22, 15)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(113, 13)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "Pacas contratadas"
        '
        'TbPacasCompCont
        '
        Me.TbPacasCompCont.Enabled = False
        Me.TbPacasCompCont.Location = New System.Drawing.Point(673, 12)
        Me.TbPacasCompCont.Name = "TbPacasCompCont"
        Me.TbPacasCompCont.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasCompCont.TabIndex = 21
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.LightPink
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(123, 13)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Agrupadas por clase"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DgvAgrupadasCliente)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Left
        Me.GroupBox2.Location = New System.Drawing.Point(3, 16)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(289, 167)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        '
        'DgvAgrupadasCliente
        '
        Me.DgvAgrupadasCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvAgrupadasCliente.Dock = System.Windows.Forms.DockStyle.Left
        Me.DgvAgrupadasCliente.Location = New System.Drawing.Point(3, 16)
        Me.DgvAgrupadasCliente.Name = "DgvAgrupadasCliente"
        Me.DgvAgrupadasCliente.Size = New System.Drawing.Size(282, 148)
        Me.DgvAgrupadasCliente.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.LightPink
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(131, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Agrupadas por cliente"
        '
        'TbPacasDisp
        '
        Me.TbPacasDisp.Enabled = False
        Me.TbPacasDisp.Location = New System.Drawing.Point(131, 112)
        Me.TbPacasDisp.Name = "TbPacasDisp"
        Me.TbPacasDisp.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasDisp.TabIndex = 20
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.SystemColors.Control
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label19.Location = New System.Drawing.Point(11, 115)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(92, 13)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "Pacas disponibles"
        '
        'TbPacasMarc
        '
        Me.TbPacasMarc.Enabled = False
        Me.TbPacasMarc.Location = New System.Drawing.Point(131, 25)
        Me.TbPacasMarc.Name = "TbPacasMarc"
        Me.TbPacasMarc.Size = New System.Drawing.Size(100, 20)
        Me.TbPacasMarc.TabIndex = 24
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.SystemColors.Control
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label21.Location = New System.Drawing.Point(11, 28)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(86, 13)
        Me.Label21.TabIndex = 23
        Me.Label21.Text = "Pacas marcadas"
        '
        'TcCompras
        '
        Me.TcCompras.Controls.Add(Me.TP1LiquidacionesAComprar)
        Me.TcCompras.Controls.Add(Me.TP3PacasAComprar)
        Me.TcCompras.Controls.Add(Me.TP2LiquidacionesCompradas)
        Me.TcCompras.Controls.Add(Me.TP4IndividualCompradas)
        Me.TcCompras.Controls.Add(Me.TP5PacasSinClasificar)
        Me.TcCompras.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TcCompras.Location = New System.Drawing.Point(0, 0)
        Me.TcCompras.Name = "TcCompras"
        Me.TcCompras.SelectedIndex = 0
        Me.TcCompras.Size = New System.Drawing.Size(1111, 348)
        Me.TcCompras.TabIndex = 1
        '
        'TP1LiquidacionesAComprar
        '
        Me.TP1LiquidacionesAComprar.BackColor = System.Drawing.Color.Transparent
        Me.TP1LiquidacionesAComprar.Controls.Add(Me.DgvDatosLiquidacion)
        Me.TP1LiquidacionesAComprar.Location = New System.Drawing.Point(4, 22)
        Me.TP1LiquidacionesAComprar.Name = "TP1LiquidacionesAComprar"
        Me.TP1LiquidacionesAComprar.Padding = New System.Windows.Forms.Padding(3)
        Me.TP1LiquidacionesAComprar.Size = New System.Drawing.Size(1103, 322)
        Me.TP1LiquidacionesAComprar.TabIndex = 0
        Me.TP1LiquidacionesAComprar.Text = "Liquidaciones a Comprar"
        '
        'DgvDatosLiquidacion
        '
        Me.DgvDatosLiquidacion.AllowUserToAddRows = False
        Me.DgvDatosLiquidacion.AllowUserToDeleteRows = False
        Me.DgvDatosLiquidacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvDatosLiquidacion.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvDatosLiquidacion.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvDatosLiquidacion.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvDatosLiquidacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvDatosLiquidacion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvDatosLiquidacion.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvDatosLiquidacion.Location = New System.Drawing.Point(3, 3)
        Me.DgvDatosLiquidacion.MultiSelect = False
        Me.DgvDatosLiquidacion.Name = "DgvDatosLiquidacion"
        Me.DgvDatosLiquidacion.RowHeadersVisible = False
        Me.DgvDatosLiquidacion.RowHeadersWidth = 40
        Me.DgvDatosLiquidacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvDatosLiquidacion.Size = New System.Drawing.Size(1097, 316)
        Me.DgvDatosLiquidacion.TabIndex = 13
        '
        'TP3PacasAComprar
        '
        Me.TP3PacasAComprar.Controls.Add(Me.DgvPacasComprar)
        Me.TP3PacasAComprar.Controls.Add(Me.GbFiltrado)
        Me.TP3PacasAComprar.Location = New System.Drawing.Point(4, 22)
        Me.TP3PacasAComprar.Name = "TP3PacasAComprar"
        Me.TP3PacasAComprar.Padding = New System.Windows.Forms.Padding(3)
        Me.TP3PacasAComprar.Size = New System.Drawing.Size(1103, 322)
        Me.TP3PacasAComprar.TabIndex = 2
        Me.TP3PacasAComprar.Text = "Pacas a Comprar"
        Me.TP3PacasAComprar.UseVisualStyleBackColor = True
        '
        'DgvPacasComprar
        '
        Me.DgvPacasComprar.AllowUserToAddRows = False
        Me.DgvPacasComprar.AllowUserToDeleteRows = False
        Me.DgvPacasComprar.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvPacasComprar.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvPacasComprar.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvPacasComprar.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvPacasComprar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvPacasComprar.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvPacasComprar.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvPacasComprar.Location = New System.Drawing.Point(3, 48)
        Me.DgvPacasComprar.MultiSelect = False
        Me.DgvPacasComprar.Name = "DgvPacasComprar"
        Me.DgvPacasComprar.RowHeadersVisible = False
        Me.DgvPacasComprar.RowHeadersWidth = 40
        Me.DgvPacasComprar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvPacasComprar.Size = New System.Drawing.Size(1097, 271)
        Me.DgvPacasComprar.TabIndex = 14
        '
        'GbFiltrado
        '
        Me.GbFiltrado.Controls.Add(Me.BtReiniciaFiltro)
        Me.GbFiltrado.Controls.Add(Me.BtFiltro)
        Me.GbFiltrado.Controls.Add(Me.CbClases)
        Me.GbFiltrado.Controls.Add(Me.Label10)
        Me.GbFiltrado.Controls.Add(Me.TbDesdePaca)
        Me.GbFiltrado.Controls.Add(Me.Label11)
        Me.GbFiltrado.Controls.Add(Me.Label8)
        Me.GbFiltrado.Controls.Add(Me.TbHastaPaca)
        Me.GbFiltrado.Dock = System.Windows.Forms.DockStyle.Top
        Me.GbFiltrado.Location = New System.Drawing.Point(3, 3)
        Me.GbFiltrado.Name = "GbFiltrado"
        Me.GbFiltrado.Size = New System.Drawing.Size(1097, 45)
        Me.GbFiltrado.TabIndex = 3
        Me.GbFiltrado.TabStop = False
        '
        'BtReiniciaFiltro
        '
        Me.BtReiniciaFiltro.Dock = System.Windows.Forms.DockStyle.Right
        Me.BtReiniciaFiltro.Location = New System.Drawing.Point(1007, 16)
        Me.BtReiniciaFiltro.MaximumSize = New System.Drawing.Size(87, 23)
        Me.BtReiniciaFiltro.MinimumSize = New System.Drawing.Size(87, 23)
        Me.BtReiniciaFiltro.Name = "BtReiniciaFiltro"
        Me.BtReiniciaFiltro.Size = New System.Drawing.Size(87, 23)
        Me.BtReiniciaFiltro.TabIndex = 57
        Me.BtReiniciaFiltro.Text = "Reinicia Filtro"
        Me.BtReiniciaFiltro.UseVisualStyleBackColor = True
        '
        'BtFiltro
        '
        Me.BtFiltro.Location = New System.Drawing.Point(513, 11)
        Me.BtFiltro.Name = "BtFiltro"
        Me.BtFiltro.Size = New System.Drawing.Size(75, 23)
        Me.BtFiltro.TabIndex = 57
        Me.BtFiltro.Text = "Aplicar Filtro"
        Me.BtFiltro.UseVisualStyleBackColor = True
        '
        'CbClases
        '
        Me.CbClases.FormattingEnabled = True
        Me.CbClases.Location = New System.Drawing.Point(354, 13)
        Me.CbClases.Name = "CbClases"
        Me.CbClases.Size = New System.Drawing.Size(114, 21)
        Me.CbClases.TabIndex = 56
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(291, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 13)
        Me.Label8.TabIndex = 28
        Me.Label8.Text = "Filtrado por:"
        '
        'TP2LiquidacionesCompradas
        '
        Me.TP2LiquidacionesCompradas.Controls.Add(Me.DgvLiqCompradas)
        Me.TP2LiquidacionesCompradas.Location = New System.Drawing.Point(4, 22)
        Me.TP2LiquidacionesCompradas.Name = "TP2LiquidacionesCompradas"
        Me.TP2LiquidacionesCompradas.Padding = New System.Windows.Forms.Padding(3)
        Me.TP2LiquidacionesCompradas.Size = New System.Drawing.Size(1103, 322)
        Me.TP2LiquidacionesCompradas.TabIndex = 1
        Me.TP2LiquidacionesCompradas.Text = "Liquidaciones Compradas"
        Me.TP2LiquidacionesCompradas.UseVisualStyleBackColor = True
        '
        'DgvLiqCompradas
        '
        Me.DgvLiqCompradas.AllowUserToAddRows = False
        Me.DgvLiqCompradas.AllowUserToDeleteRows = False
        Me.DgvLiqCompradas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvLiqCompradas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvLiqCompradas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvLiqCompradas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvLiqCompradas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvLiqCompradas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvLiqCompradas.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvLiqCompradas.Location = New System.Drawing.Point(3, 3)
        Me.DgvLiqCompradas.MultiSelect = False
        Me.DgvLiqCompradas.Name = "DgvLiqCompradas"
        Me.DgvLiqCompradas.ReadOnly = True
        Me.DgvLiqCompradas.RowHeadersVisible = False
        Me.DgvLiqCompradas.RowHeadersWidth = 40
        Me.DgvLiqCompradas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvLiqCompradas.Size = New System.Drawing.Size(1097, 316)
        Me.DgvLiqCompradas.TabIndex = 14
        '
        'TP4IndividualCompradas
        '
        Me.TP4IndividualCompradas.Controls.Add(Me.DgvIndCompradas)
        Me.TP4IndividualCompradas.Location = New System.Drawing.Point(4, 22)
        Me.TP4IndividualCompradas.Name = "TP4IndividualCompradas"
        Me.TP4IndividualCompradas.Padding = New System.Windows.Forms.Padding(3)
        Me.TP4IndividualCompradas.Size = New System.Drawing.Size(1103, 322)
        Me.TP4IndividualCompradas.TabIndex = 3
        Me.TP4IndividualCompradas.Text = "Individual Compradas (por paca)"
        Me.TP4IndividualCompradas.UseVisualStyleBackColor = True
        '
        'DgvIndCompradas
        '
        Me.DgvIndCompradas.AllowUserToAddRows = False
        Me.DgvIndCompradas.AllowUserToDeleteRows = False
        Me.DgvIndCompradas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvIndCompradas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvIndCompradas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvIndCompradas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvIndCompradas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvIndCompradas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvIndCompradas.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvIndCompradas.Location = New System.Drawing.Point(3, 3)
        Me.DgvIndCompradas.MultiSelect = False
        Me.DgvIndCompradas.Name = "DgvIndCompradas"
        Me.DgvIndCompradas.ReadOnly = True
        Me.DgvIndCompradas.RowHeadersVisible = False
        Me.DgvIndCompradas.RowHeadersWidth = 40
        Me.DgvIndCompradas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvIndCompradas.Size = New System.Drawing.Size(1097, 316)
        Me.DgvIndCompradas.TabIndex = 14
        '
        'TP5PacasSinClasificar
        '
        Me.TP5PacasSinClasificar.Controls.Add(Me.DgvPacasSinClasif)
        Me.TP5PacasSinClasificar.Location = New System.Drawing.Point(4, 22)
        Me.TP5PacasSinClasificar.Name = "TP5PacasSinClasificar"
        Me.TP5PacasSinClasificar.Padding = New System.Windows.Forms.Padding(3)
        Me.TP5PacasSinClasificar.Size = New System.Drawing.Size(1103, 322)
        Me.TP5PacasSinClasificar.TabIndex = 4
        Me.TP5PacasSinClasificar.Text = "Pacas Sin Clasificar"
        Me.TP5PacasSinClasificar.UseVisualStyleBackColor = True
        '
        'DgvPacasSinClasif
        '
        Me.DgvPacasSinClasif.AllowUserToAddRows = False
        Me.DgvPacasSinClasif.AllowUserToDeleteRows = False
        Me.DgvPacasSinClasif.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DgvPacasSinClasif.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.DgvPacasSinClasif.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DgvPacasSinClasif.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DgvPacasSinClasif.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvPacasSinClasif.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgvPacasSinClasif.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.DgvPacasSinClasif.Location = New System.Drawing.Point(3, 3)
        Me.DgvPacasSinClasif.MultiSelect = False
        Me.DgvPacasSinClasif.Name = "DgvPacasSinClasif"
        Me.DgvPacasSinClasif.ReadOnly = True
        Me.DgvPacasSinClasif.RowHeadersVisible = False
        Me.DgvPacasSinClasif.RowHeadersWidth = 40
        Me.DgvPacasSinClasif.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgvPacasSinClasif.Size = New System.Drawing.Size(1097, 316)
        Me.DgvPacasSinClasif.TabIndex = 14
        '
        'GbCompraActual
        '
        Me.GbCompraActual.BackColor = System.Drawing.SystemColors.Control
        Me.GbCompraActual.Controls.Add(Me.TbKilosSeleccionados)
        Me.GbCompraActual.Controls.Add(Me.TbPacasMarc)
        Me.GbCompraActual.Controls.Add(Me.Label7)
        Me.GbCompraActual.Controls.Add(Me.Label21)
        Me.GbCompraActual.Controls.Add(Me.TbPacasDisp)
        Me.GbCompraActual.Controls.Add(Me.Label19)
        Me.GbCompraActual.Dock = System.Windows.Forms.DockStyle.Right
        Me.GbCompraActual.Location = New System.Drawing.Point(1111, 0)
        Me.GbCompraActual.Name = "GbCompraActual"
        Me.GbCompraActual.Size = New System.Drawing.Size(288, 348)
        Me.GbCompraActual.TabIndex = 2
        Me.GbCompraActual.TabStop = False
        Me.GbCompraActual.Text = "Detalles De Compra"
        '
        'TbKilosSeleccionados
        '
        Me.TbKilosSeleccionados.Enabled = False
        Me.TbKilosSeleccionados.Location = New System.Drawing.Point(131, 67)
        Me.TbKilosSeleccionados.Name = "TbKilosSeleccionados"
        Me.TbKilosSeleccionados.Size = New System.Drawing.Size(100, 20)
        Me.TbKilosSeleccionados.TabIndex = 24
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(11, 70)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 13)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Kilos "
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.TcCompras)
        Me.Panel3.Controls.Add(Me.GbCompraActual)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 196)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1399, 348)
        Me.Panel3.TabIndex = 6
        '
        'CompraPacasContrato
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(1399, 730)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.GbCompras)
        Me.Controls.Add(Me.GbDatosGenerales)
        Me.Controls.Add(Me.MSMenu)
        Me.MinimumSize = New System.Drawing.Size(1415, 651)
        Me.Name = "CompraPacasContrato"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Compra de Pacas Por Contrato"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GbDatosGenerales.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.DgvContratos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MSMenu.ResumeLayout(False)
        Me.MSMenu.PerformLayout()
        Me.GbCompras.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.DgvAgrupadasClases, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.DgvAgrupadasCliente, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TcCompras.ResumeLayout(False)
        Me.TP1LiquidacionesAComprar.ResumeLayout(False)
        CType(Me.DgvDatosLiquidacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TP3PacasAComprar.ResumeLayout(False)
        CType(Me.DgvPacasComprar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GbFiltrado.ResumeLayout(False)
        Me.GbFiltrado.PerformLayout()
        Me.TP2LiquidacionesCompradas.ResumeLayout(False)
        CType(Me.DgvLiqCompradas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TP4IndividualCompradas.ResumeLayout(False)
        CType(Me.DgvIndCompradas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TP5PacasSinClasificar.ResumeLayout(False)
        CType(Me.DgvPacasSinClasif, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GbCompraActual.ResumeLayout(False)
        Me.GbCompraActual.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GbDatosGenerales As GroupBox
    Friend WithEvents MSMenu As MenuStrip
    Friend WithEvents NuevoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GuardarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConsultarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GbCompras As GroupBox
    Friend WithEvents TcCompras As TabControl
    Friend WithEvents TP1LiquidacionesAComprar As TabPage
    Friend WithEvents TP2LiquidacionesCompradas As TabPage
    Friend WithEvents TP3PacasAComprar As TabPage
    Friend WithEvents TP4IndividualCompradas As TabPage
    Friend WithEvents TP5PacasSinClasificar As TabPage
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents BtCastLarFib As Button
    Friend WithEvents BtCastigoMicros As Button
    Friend WithEvents BtCastigoResFibra As Button
    Friend WithEvents BtModalidadCompra As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TbPrecioQuintal As TextBox
    Friend WithEvents TbNoPacas As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TbHastaPaca As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents DtpFecha As DateTimePicker
    Friend WithEvents Label10 As Label
    Friend WithEvents TbDesdePaca As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents CbPlanta As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TbIdProductor As TextBox
    Friend WithEvents TbIdCompraPaca As TextBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents TbNombreProductor As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents TbIdContrato As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents DgvAgrupadasCliente As DataGridView
    Friend WithEvents BtnBuscarProd As Button
    Friend WithEvents DgvContratos As DataGridView
    Friend WithEvents DgvDatosLiquidacion As DataGridView
    Friend WithEvents DgvLiqCompradas As DataGridView
    Friend WithEvents DgvPacasComprar As DataGridView
    Friend WithEvents DgvIndCompradas As DataGridView
    Friend WithEvents DgvPacasSinClasif As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents TbKilosComp As TextBox
    Friend WithEvents TbPacasComp As TextBox
    Friend WithEvents TbPacasMarc As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents TbPacasCompCont As TextBox
    Friend WithEvents TbPacasDisp As TextBox
    Friend WithEvents TbPacasContratadas As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents DgvAgrupadasClases As DataGridView
    Friend WithEvents GbCompraActual As GroupBox
    Friend WithEvents TbKilosSeleccionados As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents CbClases As ComboBox
    Friend WithEvents GbFiltrado As GroupBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents BtFiltro As Button
    Friend WithEvents BtReiniciaFiltro As Button
End Class
