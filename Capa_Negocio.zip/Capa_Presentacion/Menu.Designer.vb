﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Menu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Menu))
        Me.MSMenu = New System.Windows.Forms.MenuStrip()
        Me.CatálogosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AsociacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompradoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MunicipiosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColoniasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlantasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TiposDeIncidenciasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IncidenciasDeParoDeOperacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PuestosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmpleadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MaquinariaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RangosDeTemperaturaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProfesionalesFitosanitariosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModalidadesDeCompraDePacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TierrasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VariedadesDeAlgodónToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LargosDeFibraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RendimientosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CastigosPorMicrosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegímenesHídricosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CastigosPorLargosDeFibraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CastigosPorResistenciaDeFibraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CamionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComercializaciónToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComprasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompraDePacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CompraDePacasAProductoresPorContratoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AltaDePacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransferenciaDeRegistrosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LiquidacionFinalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VentasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VentaDePacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VentaDePacasPorContratoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AsignarCompradoresAPaquetesHVIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClasificacionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaquetesHVIToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaquetesParaVentaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaquetesParaVentaPorRangosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClasificaciónDePacasConCertificadoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClasificaciónDePacasConArchivoExcelToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProcesosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CapturaDeLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CapturaDeBoletasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CapturaDeBoletasPorLotesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BoletaPorLotesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CapturaDeProducciónPacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CapturaDePacasConTecladoFijoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChequearEtiquetaDePacaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LiquidacionesPorRomaneajeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CálculoPreeliminarDeParoDeOperacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AsignaciónDePersonalAUnJefeDeTurnoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlmacenesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalidaDePacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalidaDeSemillaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalidaDePacasDeBorraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalidaDeBasuraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdministraciónToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransaccionesAClientesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CartaDeDepositoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClientesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LotesDetalleConMódulosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LotesDetalleConMódulosSegundaFormaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LotesDetalleConMódulosTerceraFormaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResumenDeLiquidacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasPorClienteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasEnGeneralToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasDetalleYAgrupadoPorClaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComercializacionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReporteDeComprasYVentasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VentasToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasSinVenderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasSinComprarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasPorClienteAgrupadoPorClasesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClasificaciónDePacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContratosDeAlgodonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasAgrupadasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasAgrupadasPorColorGradeVsTrashIDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasComercializadasPorProductorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasPorPaquetesHVIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilidadDePacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HVIDetalladoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReporteGeneralToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BoletasMódulosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BoletasConPesoAcumuladoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EntradaDeAlgodónHuesoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PacasFaltantesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExistenciaDeHuesoEnPatiosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExistenciaDeSemillaEnPatiosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SagarpaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalidaDePacasToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalidaDeSemillaToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalidaDePacasDeBorraToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalidaDeBasuraToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportesDeEventosPorIncidenciaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReporteDiarioDeTrabajoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReporteDeCertificadosFitosanitariosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReporteDeRomaneajesVsComprasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeModulosAgrupadoPorColoniaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductividadDePlantasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtileriasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrarPerfilToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BorrarPacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RespaldosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConectarBaseDeDatosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CrearEstructuraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnlaceABaseDeDatosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CambioDePerfilDePacasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CambioDePerfilDeUnProductorAOtroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnvioDeMensajesDeTextoYCorreosAProductoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConfiguracionDeParametrosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TsSalir = New System.Windows.Forms.ToolStripMenuItem()
        Me.SStatus = New System.Windows.Forms.StatusStrip()
        Me.ContratosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContratosDeAlgodónConCompradoresToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContratosDeAlgodónConProductoresToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContratosDeSemillaToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.MSMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'MSMenu
        '
        Me.MSMenu.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MSMenu.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.MSMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible
        Me.MSMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CatálogosToolStripMenuItem, Me.ComercializaciónToolStripMenuItem, Me.ProcesosToolStripMenuItem, Me.AlmacenesToolStripMenuItem, Me.AdministraciónToolStripMenuItem, Me.ReportesToolStripMenuItem, Me.UtileriasToolStripMenuItem, Me.TsSalir})
        Me.MSMenu.Location = New System.Drawing.Point(0, 0)
        Me.MSMenu.Name = "MSMenu"
        Me.MSMenu.Size = New System.Drawing.Size(1578, 27)
        Me.MSMenu.TabIndex = 0
        Me.MSMenu.Text = "MenuStrip1"
        '
        'CatálogosToolStripMenuItem
        '
        Me.CatálogosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClientesToolStripMenuItem, Me.AsociacionesToolStripMenuItem, Me.CompradoresToolStripMenuItem, Me.ToolStripSeparator3, Me.MunicipiosToolStripMenuItem, Me.ColoniasToolStripMenuItem, Me.PlantasToolStripMenuItem, Me.TiposDeIncidenciasToolStripMenuItem, Me.IncidenciasDeParoDeOperacionesToolStripMenuItem, Me.PuestosToolStripMenuItem, Me.EmpleadosToolStripMenuItem, Me.MaquinariaToolStripMenuItem, Me.RangosDeTemperaturaToolStripMenuItem, Me.ProfesionalesFitosanitariosToolStripMenuItem, Me.ModalidadesDeCompraDePacasToolStripMenuItem, Me.TierrasToolStripMenuItem, Me.VariedadesDeAlgodónToolStripMenuItem, Me.LargosDeFibraToolStripMenuItem, Me.RendimientosToolStripMenuItem, Me.CastigosPorMicrosToolStripMenuItem, Me.RegímenesHídricosToolStripMenuItem, Me.CastigosPorLargosDeFibraToolStripMenuItem, Me.CastigosPorResistenciaDeFibraToolStripMenuItem, Me.CamionesToolStripMenuItem})
        Me.CatálogosToolStripMenuItem.Name = "CatálogosToolStripMenuItem"
        Me.CatálogosToolStripMenuItem.Size = New System.Drawing.Size(82, 23)
        Me.CatálogosToolStripMenuItem.Text = "Catálogos"
        '
        'AsociacionesToolStripMenuItem
        '
        Me.AsociacionesToolStripMenuItem.Name = "AsociacionesToolStripMenuItem"
        Me.AsociacionesToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.AsociacionesToolStripMenuItem.Text = "Asociaciones"
        '
        'ClientesToolStripMenuItem
        '
        Me.ClientesToolStripMenuItem.Name = "ClientesToolStripMenuItem"
        Me.ClientesToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.ClientesToolStripMenuItem.Text = "Clientes"
        '
        'CompradoresToolStripMenuItem
        '
        Me.CompradoresToolStripMenuItem.Name = "CompradoresToolStripMenuItem"
        Me.CompradoresToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.CompradoresToolStripMenuItem.Text = "Compradores"
        '
        'MunicipiosToolStripMenuItem
        '
        Me.MunicipiosToolStripMenuItem.Name = "MunicipiosToolStripMenuItem"
        Me.MunicipiosToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.MunicipiosToolStripMenuItem.Text = "Municipios"
        Me.MunicipiosToolStripMenuItem.Visible = False
        '
        'ColoniasToolStripMenuItem
        '
        Me.ColoniasToolStripMenuItem.Name = "ColoniasToolStripMenuItem"
        Me.ColoniasToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.ColoniasToolStripMenuItem.Text = "Colonias"
        '
        'PlantasToolStripMenuItem
        '
        Me.PlantasToolStripMenuItem.Name = "PlantasToolStripMenuItem"
        Me.PlantasToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.PlantasToolStripMenuItem.Text = "Plantas"
        '
        'TiposDeIncidenciasToolStripMenuItem
        '
        Me.TiposDeIncidenciasToolStripMenuItem.Name = "TiposDeIncidenciasToolStripMenuItem"
        Me.TiposDeIncidenciasToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.TiposDeIncidenciasToolStripMenuItem.Text = "Tipos de Incidencias"
        '
        'IncidenciasDeParoDeOperacionesToolStripMenuItem
        '
        Me.IncidenciasDeParoDeOperacionesToolStripMenuItem.Name = "IncidenciasDeParoDeOperacionesToolStripMenuItem"
        Me.IncidenciasDeParoDeOperacionesToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.IncidenciasDeParoDeOperacionesToolStripMenuItem.Text = "Incidencias de Paro de operaciones"
        '
        'PuestosToolStripMenuItem
        '
        Me.PuestosToolStripMenuItem.Name = "PuestosToolStripMenuItem"
        Me.PuestosToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.PuestosToolStripMenuItem.Text = "Puestos"
        '
        'EmpleadosToolStripMenuItem
        '
        Me.EmpleadosToolStripMenuItem.Name = "EmpleadosToolStripMenuItem"
        Me.EmpleadosToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.EmpleadosToolStripMenuItem.Text = "Empleados"
        '
        'MaquinariaToolStripMenuItem
        '
        Me.MaquinariaToolStripMenuItem.Name = "MaquinariaToolStripMenuItem"
        Me.MaquinariaToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.MaquinariaToolStripMenuItem.Text = "Maquinaria"
        '
        'RangosDeTemperaturaToolStripMenuItem
        '
        Me.RangosDeTemperaturaToolStripMenuItem.Name = "RangosDeTemperaturaToolStripMenuItem"
        Me.RangosDeTemperaturaToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.RangosDeTemperaturaToolStripMenuItem.Text = "Rangos de Temperatura"
        '
        'ProfesionalesFitosanitariosToolStripMenuItem
        '
        Me.ProfesionalesFitosanitariosToolStripMenuItem.Name = "ProfesionalesFitosanitariosToolStripMenuItem"
        Me.ProfesionalesFitosanitariosToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.ProfesionalesFitosanitariosToolStripMenuItem.Text = "Profesionales Fitosanitarios"
        '
        'ModalidadesDeCompraDePacasToolStripMenuItem
        '
        Me.ModalidadesDeCompraDePacasToolStripMenuItem.Name = "ModalidadesDeCompraDePacasToolStripMenuItem"
        Me.ModalidadesDeCompraDePacasToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.ModalidadesDeCompraDePacasToolStripMenuItem.Text = "Modalidades de Compra de Pacas"
        '
        'TierrasToolStripMenuItem
        '
        Me.TierrasToolStripMenuItem.Name = "TierrasToolStripMenuItem"
        Me.TierrasToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.TierrasToolStripMenuItem.Text = "Tierras"
        '
        'VariedadesDeAlgodónToolStripMenuItem
        '
        Me.VariedadesDeAlgodónToolStripMenuItem.Name = "VariedadesDeAlgodónToolStripMenuItem"
        Me.VariedadesDeAlgodónToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.VariedadesDeAlgodónToolStripMenuItem.Text = "Variedades de Algodón"
        '
        'LargosDeFibraToolStripMenuItem
        '
        Me.LargosDeFibraToolStripMenuItem.Name = "LargosDeFibraToolStripMenuItem"
        Me.LargosDeFibraToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.LargosDeFibraToolStripMenuItem.Text = "Largos de Fibra"
        '
        'RendimientosToolStripMenuItem
        '
        Me.RendimientosToolStripMenuItem.Name = "RendimientosToolStripMenuItem"
        Me.RendimientosToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.RendimientosToolStripMenuItem.Text = "Rendimientos"
        '
        'CastigosPorMicrosToolStripMenuItem
        '
        Me.CastigosPorMicrosToolStripMenuItem.Name = "CastigosPorMicrosToolStripMenuItem"
        Me.CastigosPorMicrosToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.CastigosPorMicrosToolStripMenuItem.Text = "Castigos por Quintal"
        '
        'RegímenesHídricosToolStripMenuItem
        '
        Me.RegímenesHídricosToolStripMenuItem.Name = "RegímenesHídricosToolStripMenuItem"
        Me.RegímenesHídricosToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.RegímenesHídricosToolStripMenuItem.Text = "Regímenes hídricos"
        '
        'CastigosPorLargosDeFibraToolStripMenuItem
        '
        Me.CastigosPorLargosDeFibraToolStripMenuItem.Name = "CastigosPorLargosDeFibraToolStripMenuItem"
        Me.CastigosPorLargosDeFibraToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.CastigosPorLargosDeFibraToolStripMenuItem.Text = "Castigos por Largos de Fibra"
        '
        'CastigosPorResistenciaDeFibraToolStripMenuItem
        '
        Me.CastigosPorResistenciaDeFibraToolStripMenuItem.Name = "CastigosPorResistenciaDeFibraToolStripMenuItem"
        Me.CastigosPorResistenciaDeFibraToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.CastigosPorResistenciaDeFibraToolStripMenuItem.Text = "Castigos por Resistencia de Fibra"
        '
        'CamionesToolStripMenuItem
        '
        Me.CamionesToolStripMenuItem.Name = "CamionesToolStripMenuItem"
        Me.CamionesToolStripMenuItem.Size = New System.Drawing.Size(291, 24)
        Me.CamionesToolStripMenuItem.Text = "Camiones"
        '
        'ComercializaciónToolStripMenuItem
        '
        Me.ComercializaciónToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContratosToolStripMenuItem, Me.ClasificacionToolStripMenuItem, Me.ComprasToolStripMenuItem, Me.VentasToolStripMenuItem, Me.AsignarCompradoresAPaquetesHVIToolStripMenuItem})
        Me.ComercializaciónToolStripMenuItem.Name = "ComercializaciónToolStripMenuItem"
        Me.ComercializaciónToolStripMenuItem.Size = New System.Drawing.Size(122, 23)
        Me.ComercializaciónToolStripMenuItem.Text = "Comercialización"
        '
        'ComprasToolStripMenuItem
        '
        Me.ComprasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CompraDePacasAProductoresPorContratoToolStripMenuItem, Me.CompraDePacasToolStripMenuItem, Me.AltaDePacasToolStripMenuItem, Me.TransferenciaDeRegistrosToolStripMenuItem, Me.LiquidacionFinalToolStripMenuItem})
        Me.ComprasToolStripMenuItem.Name = "ComprasToolStripMenuItem"
        Me.ComprasToolStripMenuItem.Size = New System.Drawing.Size(309, 24)
        Me.ComprasToolStripMenuItem.Text = "Compras"
        '
        'CompraDePacasToolStripMenuItem
        '
        Me.CompraDePacasToolStripMenuItem.Name = "CompraDePacasToolStripMenuItem"
        Me.CompraDePacasToolStripMenuItem.Size = New System.Drawing.Size(364, 24)
        Me.CompraDePacasToolStripMenuItem.Text = "Compra de Pacas"
        '
        'CompraDePacasAProductoresPorContratoToolStripMenuItem
        '
        Me.CompraDePacasAProductoresPorContratoToolStripMenuItem.Name = "CompraDePacasAProductoresPorContratoToolStripMenuItem"
        Me.CompraDePacasAProductoresPorContratoToolStripMenuItem.Size = New System.Drawing.Size(364, 24)
        Me.CompraDePacasAProductoresPorContratoToolStripMenuItem.Text = "Compra de Pacas a Productores (Por Contrato)"
        '
        'AltaDePacasToolStripMenuItem
        '
        Me.AltaDePacasToolStripMenuItem.Name = "AltaDePacasToolStripMenuItem"
        Me.AltaDePacasToolStripMenuItem.Size = New System.Drawing.Size(364, 24)
        Me.AltaDePacasToolStripMenuItem.Text = "Alta de Pacas"
        '
        'TransferenciaDeRegistrosToolStripMenuItem
        '
        Me.TransferenciaDeRegistrosToolStripMenuItem.Name = "TransferenciaDeRegistrosToolStripMenuItem"
        Me.TransferenciaDeRegistrosToolStripMenuItem.Size = New System.Drawing.Size(364, 24)
        Me.TransferenciaDeRegistrosToolStripMenuItem.Text = "Transferencia de Registros"
        '
        'LiquidacionFinalToolStripMenuItem
        '
        Me.LiquidacionFinalToolStripMenuItem.Name = "LiquidacionFinalToolStripMenuItem"
        Me.LiquidacionFinalToolStripMenuItem.Size = New System.Drawing.Size(364, 24)
        Me.LiquidacionFinalToolStripMenuItem.Text = "Liquidacion Final"
        '
        'VentasToolStripMenuItem
        '
        Me.VentasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VentaDePacasPorContratoToolStripMenuItem, Me.VentaDePacasToolStripMenuItem})
        Me.VentasToolStripMenuItem.Name = "VentasToolStripMenuItem"
        Me.VentasToolStripMenuItem.Size = New System.Drawing.Size(309, 24)
        Me.VentasToolStripMenuItem.Text = "Ventas"
        '
        'VentaDePacasToolStripMenuItem
        '
        Me.VentaDePacasToolStripMenuItem.Name = "VentaDePacasToolStripMenuItem"
        Me.VentaDePacasToolStripMenuItem.Size = New System.Drawing.Size(261, 24)
        Me.VentaDePacasToolStripMenuItem.Text = "Venta de Pacas"
        '
        'VentaDePacasPorContratoToolStripMenuItem
        '
        Me.VentaDePacasPorContratoToolStripMenuItem.Name = "VentaDePacasPorContratoToolStripMenuItem"
        Me.VentaDePacasPorContratoToolStripMenuItem.Size = New System.Drawing.Size(261, 24)
        Me.VentaDePacasPorContratoToolStripMenuItem.Text = "Venta de Pacas (Por Contrato)"
        '
        'AsignarCompradoresAPaquetesHVIToolStripMenuItem
        '
        Me.AsignarCompradoresAPaquetesHVIToolStripMenuItem.Name = "AsignarCompradoresAPaquetesHVIToolStripMenuItem"
        Me.AsignarCompradoresAPaquetesHVIToolStripMenuItem.Size = New System.Drawing.Size(309, 24)
        Me.AsignarCompradoresAPaquetesHVIToolStripMenuItem.Text = "Asignar Compradores a Paquetes HVI"
        '
        'ClasificacionToolStripMenuItem
        '
        Me.ClasificacionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PaquetesHVIToolStripMenuItem1, Me.PaquetesParaVentaToolStripMenuItem, Me.PaquetesParaVentaPorRangosToolStripMenuItem, Me.ClasificaciónDePacasConCertificadoToolStripMenuItem1, Me.ClasificaciónDePacasConArchivoExcelToolStripMenuItem1})
        Me.ClasificacionToolStripMenuItem.Name = "ClasificacionToolStripMenuItem"
        Me.ClasificacionToolStripMenuItem.Size = New System.Drawing.Size(309, 24)
        Me.ClasificacionToolStripMenuItem.Text = "Clasificacion"
        '
        'PaquetesHVIToolStripMenuItem1
        '
        Me.PaquetesHVIToolStripMenuItem1.Name = "PaquetesHVIToolStripMenuItem1"
        Me.PaquetesHVIToolStripMenuItem1.Size = New System.Drawing.Size(328, 24)
        Me.PaquetesHVIToolStripMenuItem1.Text = "Paquetes HVI"
        '
        'PaquetesParaVentaToolStripMenuItem
        '
        Me.PaquetesParaVentaToolStripMenuItem.Name = "PaquetesParaVentaToolStripMenuItem"
        Me.PaquetesParaVentaToolStripMenuItem.Size = New System.Drawing.Size(328, 24)
        Me.PaquetesParaVentaToolStripMenuItem.Text = "Paquetes Para Venta"
        '
        'PaquetesParaVentaPorRangosToolStripMenuItem
        '
        Me.PaquetesParaVentaPorRangosToolStripMenuItem.Name = "PaquetesParaVentaPorRangosToolStripMenuItem"
        Me.PaquetesParaVentaPorRangosToolStripMenuItem.Size = New System.Drawing.Size(328, 24)
        Me.PaquetesParaVentaPorRangosToolStripMenuItem.Text = "Paquetes Para Venta Por Rangos"
        '
        'ClasificaciónDePacasConCertificadoToolStripMenuItem1
        '
        Me.ClasificaciónDePacasConCertificadoToolStripMenuItem1.Name = "ClasificaciónDePacasConCertificadoToolStripMenuItem1"
        Me.ClasificaciónDePacasConCertificadoToolStripMenuItem1.Size = New System.Drawing.Size(328, 24)
        Me.ClasificaciónDePacasConCertificadoToolStripMenuItem1.Text = "Clasificación de Pacas (Con Certificado)"
        '
        'ClasificaciónDePacasConArchivoExcelToolStripMenuItem1
        '
        Me.ClasificaciónDePacasConArchivoExcelToolStripMenuItem1.Name = "ClasificaciónDePacasConArchivoExcelToolStripMenuItem1"
        Me.ClasificaciónDePacasConArchivoExcelToolStripMenuItem1.Size = New System.Drawing.Size(328, 24)
        Me.ClasificaciónDePacasConArchivoExcelToolStripMenuItem1.Text = "Clasificación de Pacas (Con Archivo Excel)"
        '
        'ProcesosToolStripMenuItem
        '
        Me.ProcesosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CapturaDeLToolStripMenuItem, Me.CapturaDeBoletasToolStripMenuItem, Me.CapturaDeBoletasPorLotesToolStripMenuItem, Me.BoletaPorLotesToolStripMenuItem, Me.ToolStripSeparator1, Me.CapturaDeProducciónPacasToolStripMenuItem, Me.CapturaDePacasConTecladoFijoToolStripMenuItem, Me.ChequearEtiquetaDePacaToolStripMenuItem, Me.ToolStripSeparator2, Me.LiquidacionesPorRomaneajeToolStripMenuItem, Me.CálculoPreeliminarDeParoDeOperacionesToolStripMenuItem, Me.AsignaciónDePersonalAUnJefeDeTurnoToolStripMenuItem})
        Me.ProcesosToolStripMenuItem.Name = "ProcesosToolStripMenuItem"
        Me.ProcesosToolStripMenuItem.Size = New System.Drawing.Size(75, 23)
        Me.ProcesosToolStripMenuItem.Text = "Procesos"
        '
        'CapturaDeLToolStripMenuItem
        '
        Me.CapturaDeLToolStripMenuItem.Name = "CapturaDeLToolStripMenuItem"
        Me.CapturaDeLToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.CapturaDeLToolStripMenuItem.Text = "Ordenes de Trabajo"
        '
        'CapturaDeBoletasToolStripMenuItem
        '
        Me.CapturaDeBoletasToolStripMenuItem.Name = "CapturaDeBoletasToolStripMenuItem"
        Me.CapturaDeBoletasToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.CapturaDeBoletasToolStripMenuItem.Text = "Captura de Boletas"
        '
        'CapturaDeBoletasPorLotesToolStripMenuItem
        '
        Me.CapturaDeBoletasPorLotesToolStripMenuItem.Name = "CapturaDeBoletasPorLotesToolStripMenuItem"
        Me.CapturaDeBoletasPorLotesToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.CapturaDeBoletasPorLotesToolStripMenuItem.Text = "Captura de Boletas (Por Lotes)"
        '
        'BoletaPorLotesToolStripMenuItem
        '
        Me.BoletaPorLotesToolStripMenuItem.Name = "BoletaPorLotesToolStripMenuItem"
        Me.BoletaPorLotesToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.BoletaPorLotesToolStripMenuItem.Text = "Boleta por Lotes"
        '
        'CapturaDeProducciónPacasToolStripMenuItem
        '
        Me.CapturaDeProducciónPacasToolStripMenuItem.Name = "CapturaDeProducciónPacasToolStripMenuItem"
        Me.CapturaDeProducciónPacasToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.CapturaDeProducciónPacasToolStripMenuItem.Text = "Captura de Producción (Pacas)"
        '
        'CapturaDePacasConTecladoFijoToolStripMenuItem
        '
        Me.CapturaDePacasConTecladoFijoToolStripMenuItem.Name = "CapturaDePacasConTecladoFijoToolStripMenuItem"
        Me.CapturaDePacasConTecladoFijoToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.CapturaDePacasConTecladoFijoToolStripMenuItem.Text = "Captura de Pacas (Con teclado fijo)"
        '
        'ChequearEtiquetaDePacaToolStripMenuItem
        '
        Me.ChequearEtiquetaDePacaToolStripMenuItem.Name = "ChequearEtiquetaDePacaToolStripMenuItem"
        Me.ChequearEtiquetaDePacaToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.ChequearEtiquetaDePacaToolStripMenuItem.Text = "Etiqueta de Paca"
        '
        'LiquidacionesPorRomaneajeToolStripMenuItem
        '
        Me.LiquidacionesPorRomaneajeToolStripMenuItem.Name = "LiquidacionesPorRomaneajeToolStripMenuItem"
        Me.LiquidacionesPorRomaneajeToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.LiquidacionesPorRomaneajeToolStripMenuItem.Text = "Liquidaciones por Romaneaje"
        '
        'CálculoPreeliminarDeParoDeOperacionesToolStripMenuItem
        '
        Me.CálculoPreeliminarDeParoDeOperacionesToolStripMenuItem.Name = "CálculoPreeliminarDeParoDeOperacionesToolStripMenuItem"
        Me.CálculoPreeliminarDeParoDeOperacionesToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.CálculoPreeliminarDeParoDeOperacionesToolStripMenuItem.Text = "Cálculo preeliminar de paro de operaciones"
        '
        'AsignaciónDePersonalAUnJefeDeTurnoToolStripMenuItem
        '
        Me.AsignaciónDePersonalAUnJefeDeTurnoToolStripMenuItem.Name = "AsignaciónDePersonalAUnJefeDeTurnoToolStripMenuItem"
        Me.AsignaciónDePersonalAUnJefeDeTurnoToolStripMenuItem.Size = New System.Drawing.Size(341, 24)
        Me.AsignaciónDePersonalAUnJefeDeTurnoToolStripMenuItem.Text = "Asignación de Personal a un jefe de turno"
        '
        'AlmacenesToolStripMenuItem
        '
        Me.AlmacenesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SalidaDePacasToolStripMenuItem, Me.SalidaDeSemillaToolStripMenuItem, Me.SalidaDePacasDeBorraToolStripMenuItem, Me.SalidaDeBasuraToolStripMenuItem})
        Me.AlmacenesToolStripMenuItem.Name = "AlmacenesToolStripMenuItem"
        Me.AlmacenesToolStripMenuItem.Size = New System.Drawing.Size(86, 23)
        Me.AlmacenesToolStripMenuItem.Text = "Almacenes"
        '
        'SalidaDePacasToolStripMenuItem
        '
        Me.SalidaDePacasToolStripMenuItem.Name = "SalidaDePacasToolStripMenuItem"
        Me.SalidaDePacasToolStripMenuItem.Size = New System.Drawing.Size(226, 24)
        Me.SalidaDePacasToolStripMenuItem.Text = "Salida de Pacas"
        '
        'SalidaDeSemillaToolStripMenuItem
        '
        Me.SalidaDeSemillaToolStripMenuItem.Name = "SalidaDeSemillaToolStripMenuItem"
        Me.SalidaDeSemillaToolStripMenuItem.Size = New System.Drawing.Size(226, 24)
        Me.SalidaDeSemillaToolStripMenuItem.Text = "Salida de Semilla"
        '
        'SalidaDePacasDeBorraToolStripMenuItem
        '
        Me.SalidaDePacasDeBorraToolStripMenuItem.Name = "SalidaDePacasDeBorraToolStripMenuItem"
        Me.SalidaDePacasDeBorraToolStripMenuItem.Size = New System.Drawing.Size(226, 24)
        Me.SalidaDePacasDeBorraToolStripMenuItem.Text = "Salida de Pacas de Borra"
        '
        'SalidaDeBasuraToolStripMenuItem
        '
        Me.SalidaDeBasuraToolStripMenuItem.Name = "SalidaDeBasuraToolStripMenuItem"
        Me.SalidaDeBasuraToolStripMenuItem.Size = New System.Drawing.Size(226, 24)
        Me.SalidaDeBasuraToolStripMenuItem.Text = "Salida de Basura"
        '
        'AdministraciónToolStripMenuItem
        '
        Me.AdministraciónToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TransaccionesAClientesToolStripMenuItem, Me.CartaDeDepositoToolStripMenuItem})
        Me.AdministraciónToolStripMenuItem.Name = "AdministraciónToolStripMenuItem"
        Me.AdministraciónToolStripMenuItem.Size = New System.Drawing.Size(112, 23)
        Me.AdministraciónToolStripMenuItem.Text = "Administración"
        '
        'TransaccionesAClientesToolStripMenuItem
        '
        Me.TransaccionesAClientesToolStripMenuItem.Name = "TransaccionesAClientesToolStripMenuItem"
        Me.TransaccionesAClientesToolStripMenuItem.Size = New System.Drawing.Size(224, 24)
        Me.TransaccionesAClientesToolStripMenuItem.Text = "Transacciones a Clientes"
        '
        'CartaDeDepositoToolStripMenuItem
        '
        Me.CartaDeDepositoToolStripMenuItem.Name = "CartaDeDepositoToolStripMenuItem"
        Me.CartaDeDepositoToolStripMenuItem.Size = New System.Drawing.Size(224, 24)
        Me.CartaDeDepositoToolStripMenuItem.Text = "Carta de Deposito"
        '
        'ReportesToolStripMenuItem
        '
        Me.ReportesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClientesToolStripMenuItem1, Me.LotesDetalleConMódulosToolStripMenuItem, Me.LotesDetalleConMódulosSegundaFormaToolStripMenuItem, Me.LotesDetalleConMódulosTerceraFormaToolStripMenuItem, Me.ResumenDeLiquidacionesToolStripMenuItem, Me.PacasPorClienteToolStripMenuItem, Me.PacasEnGeneralToolStripMenuItem, Me.PacasDetalleYAgrupadoPorClaseToolStripMenuItem, Me.RecapToolStripMenuItem, Me.ComercializacionToolStripMenuItem, Me.ReporteGeneralToolStripMenuItem, Me.BoletasMódulosToolStripMenuItem, Me.BoletasConPesoAcumuladoToolStripMenuItem, Me.EntradaDeAlgodónHuesoToolStripMenuItem, Me.PacasFaltantesToolStripMenuItem, Me.ExistenciaDeHuesoEnPatiosToolStripMenuItem, Me.ExistenciaDeSemillaEnPatiosToolStripMenuItem, Me.SagarpaToolStripMenuItem, Me.SalidaDePacasToolStripMenuItem1, Me.SalidaDeSemillaToolStripMenuItem1, Me.SalidaDePacasDeBorraToolStripMenuItem1, Me.SalidaDeBasuraToolStripMenuItem1, Me.ReportesDeEventosPorIncidenciaToolStripMenuItem, Me.ReporteDiarioDeTrabajoToolStripMenuItem, Me.ReporteDeCertificadosFitosanitariosToolStripMenuItem, Me.ReporteDeRomaneajesVsComprasToolStripMenuItem, Me.DeModulosAgrupadoPorColoniaToolStripMenuItem, Me.ProductividadDePlantasToolStripMenuItem})
        Me.ReportesToolStripMenuItem.Name = "ReportesToolStripMenuItem"
        Me.ReportesToolStripMenuItem.Size = New System.Drawing.Size(75, 23)
        Me.ReportesToolStripMenuItem.Text = "Reportes"
        '
        'ClientesToolStripMenuItem1
        '
        Me.ClientesToolStripMenuItem1.Name = "ClientesToolStripMenuItem1"
        Me.ClientesToolStripMenuItem1.Size = New System.Drawing.Size(349, 24)
        Me.ClientesToolStripMenuItem1.Text = "Clientes"
        '
        'LotesDetalleConMódulosToolStripMenuItem
        '
        Me.LotesDetalleConMódulosToolStripMenuItem.Name = "LotesDetalleConMódulosToolStripMenuItem"
        Me.LotesDetalleConMódulosToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.LotesDetalleConMódulosToolStripMenuItem.Text = "Lotes (Detalle con Módulos)"
        '
        'LotesDetalleConMódulosSegundaFormaToolStripMenuItem
        '
        Me.LotesDetalleConMódulosSegundaFormaToolStripMenuItem.Name = "LotesDetalleConMódulosSegundaFormaToolStripMenuItem"
        Me.LotesDetalleConMódulosSegundaFormaToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.LotesDetalleConMódulosSegundaFormaToolStripMenuItem.Text = "Lotes (Detalle con Módulos Segunda Forma)"
        '
        'LotesDetalleConMódulosTerceraFormaToolStripMenuItem
        '
        Me.LotesDetalleConMódulosTerceraFormaToolStripMenuItem.Name = "LotesDetalleConMódulosTerceraFormaToolStripMenuItem"
        Me.LotesDetalleConMódulosTerceraFormaToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.LotesDetalleConMódulosTerceraFormaToolStripMenuItem.Text = "Lotes (Detalle con Módulos Tercera Forma)"
        '
        'ResumenDeLiquidacionesToolStripMenuItem
        '
        Me.ResumenDeLiquidacionesToolStripMenuItem.Name = "ResumenDeLiquidacionesToolStripMenuItem"
        Me.ResumenDeLiquidacionesToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ResumenDeLiquidacionesToolStripMenuItem.Text = "Resumen de Liquidaciones"
        '
        'PacasPorClienteToolStripMenuItem
        '
        Me.PacasPorClienteToolStripMenuItem.Name = "PacasPorClienteToolStripMenuItem"
        Me.PacasPorClienteToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.PacasPorClienteToolStripMenuItem.Text = "Pacas por Cliente"
        '
        'PacasEnGeneralToolStripMenuItem
        '
        Me.PacasEnGeneralToolStripMenuItem.Name = "PacasEnGeneralToolStripMenuItem"
        Me.PacasEnGeneralToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.PacasEnGeneralToolStripMenuItem.Text = "Pacas en General"
        '
        'PacasDetalleYAgrupadoPorClaseToolStripMenuItem
        '
        Me.PacasDetalleYAgrupadoPorClaseToolStripMenuItem.Name = "PacasDetalleYAgrupadoPorClaseToolStripMenuItem"
        Me.PacasDetalleYAgrupadoPorClaseToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.PacasDetalleYAgrupadoPorClaseToolStripMenuItem.Text = "Pacas (Detalle y agrupado por Clase)"
        '
        'RecapToolStripMenuItem
        '
        Me.RecapToolStripMenuItem.Name = "RecapToolStripMenuItem"
        Me.RecapToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.RecapToolStripMenuItem.Text = "Recap"
        '
        'ComercializacionToolStripMenuItem
        '
        Me.ComercializacionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReporteDeComprasYVentasToolStripMenuItem, Me.VentasToolStripMenuItem1, Me.PacasSinVenderToolStripMenuItem, Me.PacasSinComprarToolStripMenuItem, Me.PacasPorClienteAgrupadoPorClasesToolStripMenuItem, Me.ClasificaciónDePacasToolStripMenuItem, Me.ContratosDeAlgodonToolStripMenuItem, Me.PacasAgrupadasToolStripMenuItem, Me.PacasAgrupadasPorColorGradeVsTrashIDToolStripMenuItem, Me.PacasComercializadasPorProductorToolStripMenuItem, Me.PacasPorPaquetesHVIToolStripMenuItem, Me.UtilidadDePacasToolStripMenuItem, Me.HVIDetalladoToolStripMenuItem})
        Me.ComercializacionToolStripMenuItem.Name = "ComercializacionToolStripMenuItem"
        Me.ComercializacionToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ComercializacionToolStripMenuItem.Text = "Comercializacion"
        '
        'ReporteDeComprasYVentasToolStripMenuItem
        '
        Me.ReporteDeComprasYVentasToolStripMenuItem.Name = "ReporteDeComprasYVentasToolStripMenuItem"
        Me.ReporteDeComprasYVentasToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.ReporteDeComprasYVentasToolStripMenuItem.Text = "Reporte de Compras y Ventas"
        '
        'VentasToolStripMenuItem1
        '
        Me.VentasToolStripMenuItem1.Name = "VentasToolStripMenuItem1"
        Me.VentasToolStripMenuItem1.Size = New System.Drawing.Size(350, 24)
        Me.VentasToolStripMenuItem1.Text = "Ventas"
        '
        'PacasSinVenderToolStripMenuItem
        '
        Me.PacasSinVenderToolStripMenuItem.Name = "PacasSinVenderToolStripMenuItem"
        Me.PacasSinVenderToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.PacasSinVenderToolStripMenuItem.Text = "Pacas sin Vender"
        '
        'PacasSinComprarToolStripMenuItem
        '
        Me.PacasSinComprarToolStripMenuItem.Name = "PacasSinComprarToolStripMenuItem"
        Me.PacasSinComprarToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.PacasSinComprarToolStripMenuItem.Text = "Pacas sin Comprar"
        '
        'PacasPorClienteAgrupadoPorClasesToolStripMenuItem
        '
        Me.PacasPorClienteAgrupadoPorClasesToolStripMenuItem.Name = "PacasPorClienteAgrupadoPorClasesToolStripMenuItem"
        Me.PacasPorClienteAgrupadoPorClasesToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.PacasPorClienteAgrupadoPorClasesToolStripMenuItem.Text = "Pacas por Cliente (Agrupado por Clases)"
        '
        'ClasificaciónDePacasToolStripMenuItem
        '
        Me.ClasificaciónDePacasToolStripMenuItem.Name = "ClasificaciónDePacasToolStripMenuItem"
        Me.ClasificaciónDePacasToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.ClasificaciónDePacasToolStripMenuItem.Text = "Clasificación de Pacas"
        '
        'ContratosDeAlgodonToolStripMenuItem
        '
        Me.ContratosDeAlgodonToolStripMenuItem.Name = "ContratosDeAlgodonToolStripMenuItem"
        Me.ContratosDeAlgodonToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.ContratosDeAlgodonToolStripMenuItem.Text = "Contratos de Algodón"
        '
        'PacasAgrupadasToolStripMenuItem
        '
        Me.PacasAgrupadasToolStripMenuItem.Name = "PacasAgrupadasToolStripMenuItem"
        Me.PacasAgrupadasToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.PacasAgrupadasToolStripMenuItem.Text = "Pacas Agrupadas Por Clase"
        '
        'PacasAgrupadasPorColorGradeVsTrashIDToolStripMenuItem
        '
        Me.PacasAgrupadasPorColorGradeVsTrashIDToolStripMenuItem.Name = "PacasAgrupadasPorColorGradeVsTrashIDToolStripMenuItem"
        Me.PacasAgrupadasPorColorGradeVsTrashIDToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.PacasAgrupadasPorColorGradeVsTrashIDToolStripMenuItem.Text = "Pacas Agrupadas Por ColorGrade vs. TrashID"
        '
        'PacasComercializadasPorProductorToolStripMenuItem
        '
        Me.PacasComercializadasPorProductorToolStripMenuItem.Name = "PacasComercializadasPorProductorToolStripMenuItem"
        Me.PacasComercializadasPorProductorToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.PacasComercializadasPorProductorToolStripMenuItem.Text = "Pacas Comercializadas por Productor"
        '
        'PacasPorPaquetesHVIToolStripMenuItem
        '
        Me.PacasPorPaquetesHVIToolStripMenuItem.Name = "PacasPorPaquetesHVIToolStripMenuItem"
        Me.PacasPorPaquetesHVIToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.PacasPorPaquetesHVIToolStripMenuItem.Text = "Pacas por Paquetes HVI"
        '
        'UtilidadDePacasToolStripMenuItem
        '
        Me.UtilidadDePacasToolStripMenuItem.Name = "UtilidadDePacasToolStripMenuItem"
        Me.UtilidadDePacasToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.UtilidadDePacasToolStripMenuItem.Text = "Utilidad de Pacas"
        '
        'HVIDetalladoToolStripMenuItem
        '
        Me.HVIDetalladoToolStripMenuItem.Name = "HVIDetalladoToolStripMenuItem"
        Me.HVIDetalladoToolStripMenuItem.Size = New System.Drawing.Size(350, 24)
        Me.HVIDetalladoToolStripMenuItem.Text = "HVI Detallado"
        '
        'ReporteGeneralToolStripMenuItem
        '
        Me.ReporteGeneralToolStripMenuItem.Name = "ReporteGeneralToolStripMenuItem"
        Me.ReporteGeneralToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ReporteGeneralToolStripMenuItem.Text = "Reporte General"
        '
        'BoletasMódulosToolStripMenuItem
        '
        Me.BoletasMódulosToolStripMenuItem.Name = "BoletasMódulosToolStripMenuItem"
        Me.BoletasMódulosToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.BoletasMódulosToolStripMenuItem.Text = "Boletas (Módulos)"
        '
        'BoletasConPesoAcumuladoToolStripMenuItem
        '
        Me.BoletasConPesoAcumuladoToolStripMenuItem.Name = "BoletasConPesoAcumuladoToolStripMenuItem"
        Me.BoletasConPesoAcumuladoToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.BoletasConPesoAcumuladoToolStripMenuItem.Text = "Boletas (Con peso acumulado)"
        '
        'EntradaDeAlgodónHuesoToolStripMenuItem
        '
        Me.EntradaDeAlgodónHuesoToolStripMenuItem.Name = "EntradaDeAlgodónHuesoToolStripMenuItem"
        Me.EntradaDeAlgodónHuesoToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.EntradaDeAlgodónHuesoToolStripMenuItem.Text = "Entrada de Algodón Hueso"
        '
        'PacasFaltantesToolStripMenuItem
        '
        Me.PacasFaltantesToolStripMenuItem.Name = "PacasFaltantesToolStripMenuItem"
        Me.PacasFaltantesToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.PacasFaltantesToolStripMenuItem.Text = "Pacas Faltantes"
        '
        'ExistenciaDeHuesoEnPatiosToolStripMenuItem
        '
        Me.ExistenciaDeHuesoEnPatiosToolStripMenuItem.Name = "ExistenciaDeHuesoEnPatiosToolStripMenuItem"
        Me.ExistenciaDeHuesoEnPatiosToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ExistenciaDeHuesoEnPatiosToolStripMenuItem.Text = "Existencia de Hueso en Patios"
        '
        'ExistenciaDeSemillaEnPatiosToolStripMenuItem
        '
        Me.ExistenciaDeSemillaEnPatiosToolStripMenuItem.Name = "ExistenciaDeSemillaEnPatiosToolStripMenuItem"
        Me.ExistenciaDeSemillaEnPatiosToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ExistenciaDeSemillaEnPatiosToolStripMenuItem.Text = "Existencia de Semilla en Patios"
        '
        'SagarpaToolStripMenuItem
        '
        Me.SagarpaToolStripMenuItem.Name = "SagarpaToolStripMenuItem"
        Me.SagarpaToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.SagarpaToolStripMenuItem.Text = "Sagarpa"
        '
        'SalidaDePacasToolStripMenuItem1
        '
        Me.SalidaDePacasToolStripMenuItem1.Name = "SalidaDePacasToolStripMenuItem1"
        Me.SalidaDePacasToolStripMenuItem1.Size = New System.Drawing.Size(349, 24)
        Me.SalidaDePacasToolStripMenuItem1.Text = "Salida de Pacas"
        '
        'SalidaDeSemillaToolStripMenuItem1
        '
        Me.SalidaDeSemillaToolStripMenuItem1.Name = "SalidaDeSemillaToolStripMenuItem1"
        Me.SalidaDeSemillaToolStripMenuItem1.Size = New System.Drawing.Size(349, 24)
        Me.SalidaDeSemillaToolStripMenuItem1.Text = "Salida de Semilla"
        '
        'SalidaDePacasDeBorraToolStripMenuItem1
        '
        Me.SalidaDePacasDeBorraToolStripMenuItem1.Name = "SalidaDePacasDeBorraToolStripMenuItem1"
        Me.SalidaDePacasDeBorraToolStripMenuItem1.Size = New System.Drawing.Size(349, 24)
        Me.SalidaDePacasDeBorraToolStripMenuItem1.Text = "Salida de Pacas de Borra"
        '
        'SalidaDeBasuraToolStripMenuItem1
        '
        Me.SalidaDeBasuraToolStripMenuItem1.Name = "SalidaDeBasuraToolStripMenuItem1"
        Me.SalidaDeBasuraToolStripMenuItem1.Size = New System.Drawing.Size(349, 24)
        Me.SalidaDeBasuraToolStripMenuItem1.Text = "Salida de Basura"
        '
        'ReportesDeEventosPorIncidenciaToolStripMenuItem
        '
        Me.ReportesDeEventosPorIncidenciaToolStripMenuItem.Name = "ReportesDeEventosPorIncidenciaToolStripMenuItem"
        Me.ReportesDeEventosPorIncidenciaToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ReportesDeEventosPorIncidenciaToolStripMenuItem.Text = "Reportes de Eventos por Incidencia"
        '
        'ReporteDiarioDeTrabajoToolStripMenuItem
        '
        Me.ReporteDiarioDeTrabajoToolStripMenuItem.Name = "ReporteDiarioDeTrabajoToolStripMenuItem"
        Me.ReporteDiarioDeTrabajoToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ReporteDiarioDeTrabajoToolStripMenuItem.Text = "Reporte Diario de Trabajo"
        '
        'ReporteDeCertificadosFitosanitariosToolStripMenuItem
        '
        Me.ReporteDeCertificadosFitosanitariosToolStripMenuItem.Name = "ReporteDeCertificadosFitosanitariosToolStripMenuItem"
        Me.ReporteDeCertificadosFitosanitariosToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ReporteDeCertificadosFitosanitariosToolStripMenuItem.Text = "Reporte de Certificados Fitosanitarios"
        '
        'ReporteDeRomaneajesVsComprasToolStripMenuItem
        '
        Me.ReporteDeRomaneajesVsComprasToolStripMenuItem.Name = "ReporteDeRomaneajesVsComprasToolStripMenuItem"
        Me.ReporteDeRomaneajesVsComprasToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ReporteDeRomaneajesVsComprasToolStripMenuItem.Text = "Reporte de Romaneajes vs Compras"
        '
        'DeModulosAgrupadoPorColoniaToolStripMenuItem
        '
        Me.DeModulosAgrupadoPorColoniaToolStripMenuItem.Name = "DeModulosAgrupadoPorColoniaToolStripMenuItem"
        Me.DeModulosAgrupadoPorColoniaToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.DeModulosAgrupadoPorColoniaToolStripMenuItem.Text = "De Modulos agrupado por Colonia"
        '
        'ProductividadDePlantasToolStripMenuItem
        '
        Me.ProductividadDePlantasToolStripMenuItem.Name = "ProductividadDePlantasToolStripMenuItem"
        Me.ProductividadDePlantasToolStripMenuItem.Size = New System.Drawing.Size(349, 24)
        Me.ProductividadDePlantasToolStripMenuItem.Text = "Productividad de Plantas"
        '
        'UtileriasToolStripMenuItem
        '
        Me.UtileriasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BorrarPerfilToolStripMenuItem, Me.BorrarPacasToolStripMenuItem, Me.RespaldosToolStripMenuItem, Me.ConectarBaseDeDatosToolStripMenuItem, Me.CrearEstructuraToolStripMenuItem, Me.EnlaceABaseDeDatosToolStripMenuItem, Me.CambioDePerfilDePacasToolStripMenuItem, Me.CambioDePerfilDeUnProductorAOtroToolStripMenuItem, Me.EnvioDeMensajesDeTextoYCorreosAProductoresToolStripMenuItem, Me.ConfiguracionDeParametrosToolStripMenuItem})
        Me.UtileriasToolStripMenuItem.Name = "UtileriasToolStripMenuItem"
        Me.UtileriasToolStripMenuItem.Size = New System.Drawing.Size(70, 23)
        Me.UtileriasToolStripMenuItem.Text = "Utilerias"
        '
        'BorrarPerfilToolStripMenuItem
        '
        Me.BorrarPerfilToolStripMenuItem.Name = "BorrarPerfilToolStripMenuItem"
        Me.BorrarPerfilToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.BorrarPerfilToolStripMenuItem.Text = "Borrar Perfil"
        '
        'BorrarPacasToolStripMenuItem
        '
        Me.BorrarPacasToolStripMenuItem.Name = "BorrarPacasToolStripMenuItem"
        Me.BorrarPacasToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.BorrarPacasToolStripMenuItem.Text = "Borrar Pacas"
        '
        'RespaldosToolStripMenuItem
        '
        Me.RespaldosToolStripMenuItem.Name = "RespaldosToolStripMenuItem"
        Me.RespaldosToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.RespaldosToolStripMenuItem.Text = "Respaldos"
        '
        'ConectarBaseDeDatosToolStripMenuItem
        '
        Me.ConectarBaseDeDatosToolStripMenuItem.Name = "ConectarBaseDeDatosToolStripMenuItem"
        Me.ConectarBaseDeDatosToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.ConectarBaseDeDatosToolStripMenuItem.Text = "Conectar Base de Datos"
        '
        'CrearEstructuraToolStripMenuItem
        '
        Me.CrearEstructuraToolStripMenuItem.Name = "CrearEstructuraToolStripMenuItem"
        Me.CrearEstructuraToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.CrearEstructuraToolStripMenuItem.Text = "Crear Estructura"
        '
        'EnlaceABaseDeDatosToolStripMenuItem
        '
        Me.EnlaceABaseDeDatosToolStripMenuItem.Name = "EnlaceABaseDeDatosToolStripMenuItem"
        Me.EnlaceABaseDeDatosToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.EnlaceABaseDeDatosToolStripMenuItem.Text = "Enlace a Base de Datos"
        '
        'CambioDePerfilDePacasToolStripMenuItem
        '
        Me.CambioDePerfilDePacasToolStripMenuItem.Name = "CambioDePerfilDePacasToolStripMenuItem"
        Me.CambioDePerfilDePacasToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.CambioDePerfilDePacasToolStripMenuItem.Text = "Cambio de Perfil de Pacas"
        '
        'CambioDePerfilDeUnProductorAOtroToolStripMenuItem
        '
        Me.CambioDePerfilDeUnProductorAOtroToolStripMenuItem.Name = "CambioDePerfilDeUnProductorAOtroToolStripMenuItem"
        Me.CambioDePerfilDeUnProductorAOtroToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.CambioDePerfilDeUnProductorAOtroToolStripMenuItem.Text = "Cambio de Perfil de un Productor a Otro"
        '
        'EnvioDeMensajesDeTextoYCorreosAProductoresToolStripMenuItem
        '
        Me.EnvioDeMensajesDeTextoYCorreosAProductoresToolStripMenuItem.Name = "EnvioDeMensajesDeTextoYCorreosAProductoresToolStripMenuItem"
        Me.EnvioDeMensajesDeTextoYCorreosAProductoresToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.EnvioDeMensajesDeTextoYCorreosAProductoresToolStripMenuItem.Text = "Envio de Mensajes de texto y correos a Productores"
        '
        'ConfiguracionDeParametrosToolStripMenuItem
        '
        Me.ConfiguracionDeParametrosToolStripMenuItem.Name = "ConfiguracionDeParametrosToolStripMenuItem"
        Me.ConfiguracionDeParametrosToolStripMenuItem.Size = New System.Drawing.Size(394, 24)
        Me.ConfiguracionDeParametrosToolStripMenuItem.Text = "Configuracion De Parametros"
        '
        'TsSalir
        '
        Me.TsSalir.Name = "TsSalir"
        Me.TsSalir.Size = New System.Drawing.Size(46, 23)
        Me.TsSalir.Text = "Salir"
        '
        'SStatus
        '
        Me.SStatus.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.SStatus.Location = New System.Drawing.Point(0, 769)
        Me.SStatus.Name = "SStatus"
        Me.SStatus.Size = New System.Drawing.Size(1578, 22)
        Me.SStatus.TabIndex = 1
        Me.SStatus.Text = "StatusStrip1"
        '
        'ContratosToolStripMenuItem
        '
        Me.ContratosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContratosDeAlgodónConProductoresToolStripMenuItem1, Me.ContratosDeAlgodónConCompradoresToolStripMenuItem1, Me.ContratosDeSemillaToolStripMenuItem1})
        Me.ContratosToolStripMenuItem.Name = "ContratosToolStripMenuItem"
        Me.ContratosToolStripMenuItem.Size = New System.Drawing.Size(309, 24)
        Me.ContratosToolStripMenuItem.Text = "Contratos"
        '
        'ContratosDeAlgodónConCompradoresToolStripMenuItem1
        '
        Me.ContratosDeAlgodónConCompradoresToolStripMenuItem1.Name = "ContratosDeAlgodónConCompradoresToolStripMenuItem1"
        Me.ContratosDeAlgodónConCompradoresToolStripMenuItem1.Size = New System.Drawing.Size(338, 24)
        Me.ContratosDeAlgodónConCompradoresToolStripMenuItem1.Text = "Contratos de Algodón (Con Compradores)"
        '
        'ContratosDeAlgodónConProductoresToolStripMenuItem1
        '
        Me.ContratosDeAlgodónConProductoresToolStripMenuItem1.Name = "ContratosDeAlgodónConProductoresToolStripMenuItem1"
        Me.ContratosDeAlgodónConProductoresToolStripMenuItem1.Size = New System.Drawing.Size(338, 24)
        Me.ContratosDeAlgodónConProductoresToolStripMenuItem1.Text = "Contratos de Algodón (Con Productores)"
        '
        'ContratosDeSemillaToolStripMenuItem1
        '
        Me.ContratosDeSemillaToolStripMenuItem1.Name = "ContratosDeSemillaToolStripMenuItem1"
        Me.ContratosDeSemillaToolStripMenuItem1.Size = New System.Drawing.Size(338, 24)
        Me.ContratosDeSemillaToolStripMenuItem1.Text = "Contratos de Semilla"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(338, 6)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(338, 6)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(288, 6)
        '
        'Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(1578, 791)
        Me.Controls.Add(Me.SStatus)
        Me.Controls.Add(Me.MSMenu)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MSMenu
        Me.Name = "Menu"
        Me.Text = "Menu Principal"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MSMenu.ResumeLayout(False)
        Me.MSMenu.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MSMenu As MenuStrip
    Friend WithEvents CatálogosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClientesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AsociacionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MunicipiosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ColoniasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PlantasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IncidenciasDeParoDeOperacionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EmpleadosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PuestosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MaquinariaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RangosDeTemperaturaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProfesionalesFitosanitariosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ModalidadesDeCompraDePacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TierrasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VariedadesDeAlgodónToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LargosDeFibraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RendimientosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CastigosPorMicrosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegímenesHídricosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CastigosPorLargosDeFibraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CastigosPorResistenciaDeFibraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CamionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProcesosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CapturaDeLToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CapturaDeBoletasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CapturaDeBoletasPorLotesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BoletaPorLotesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CapturaDeProducciónPacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CapturaDePacasConTecladoFijoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChequearEtiquetaDePacaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LiquidacionesPorRomaneajeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CálculoPreeliminarDeParoDeOperacionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AsignaciónDePersonalAUnJefeDeTurnoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AlmacenesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalidaDePacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalidaDeSemillaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalidaDePacasDeBorraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalidaDeBasuraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AdministraciónToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TransaccionesAClientesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CartaDeDepositoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ComercializaciónToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ComprasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CompraDePacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CompraDePacasAProductoresPorContratoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AltaDePacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TransferenciaDeRegistrosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LiquidacionFinalToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VentasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VentaDePacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VentaDePacasPorContratoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AsignarCompradoresAPaquetesHVIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClientesToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents LotesDetalleConMódulosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LotesDetalleConMódulosSegundaFormaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LotesDetalleConMódulosTerceraFormaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResumenDeLiquidacionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasPorClienteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasEnGeneralToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasDetalleYAgrupadoPorClaseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RecapToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ComercializacionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReporteDeComprasYVentasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VentasToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents PacasSinVenderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasSinComprarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasPorClienteAgrupadoPorClasesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClasificaciónDePacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContratosDeAlgodonToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasAgrupadasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasAgrupadasPorColorGradeVsTrashIDToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasComercializadasPorProductorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasPorPaquetesHVIToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UtilidadDePacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HVIDetalladoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReporteGeneralToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BoletasMódulosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BoletasConPesoAcumuladoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EntradaDeAlgodónHuesoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PacasFaltantesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExistenciaDeHuesoEnPatiosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExistenciaDeSemillaEnPatiosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SagarpaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalidaDePacasToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SalidaDeSemillaToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SalidaDePacasDeBorraToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SalidaDeBasuraToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ReportesDeEventosPorIncidenciaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReporteDiarioDeTrabajoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReporteDeCertificadosFitosanitariosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReporteDeRomaneajesVsComprasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeModulosAgrupadoPorColoniaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProductividadDePlantasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UtileriasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BorrarPerfilToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BorrarPacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RespaldosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConectarBaseDeDatosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CrearEstructuraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EnlaceABaseDeDatosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CambioDePerfilDePacasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CambioDePerfilDeUnProductorAOtroToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EnvioDeMensajesDeTextoYCorreosAProductoresToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TsSalir As ToolStripMenuItem
    Friend WithEvents CompradoresToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TiposDeIncidenciasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClasificacionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PaquetesParaVentaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PaquetesParaVentaPorRangosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConfiguracionDeParametrosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SStatus As StatusStrip
    Friend WithEvents ClasificaciónDePacasConCertificadoToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ClasificaciónDePacasConArchivoExcelToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents PaquetesHVIToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ContratosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContratosDeAlgodónConProductoresToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ContratosDeAlgodónConCompradoresToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ContratosDeSemillaToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
End Class
