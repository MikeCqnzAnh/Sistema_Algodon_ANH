﻿Public Class VarGlob2
    Public Shared IdProductor As Integer
    Public Shared NombreProductor As String
    Public Shared PrecioQuintal As Double
End Class
