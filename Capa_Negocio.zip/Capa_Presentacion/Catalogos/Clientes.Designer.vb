﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Clientes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MSMenu = New System.Windows.Forms.MenuStrip()
        Me.NuevoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GuardarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TbIdCliente = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TbSocio = New System.Windows.Forms.TextBox()
        Me.TbNombre = New System.Windows.Forms.TextBox()
        Me.CbTipoPersona = New System.Windows.Forms.ComboBox()
        Me.TCTipoPersona = New System.Windows.Forms.TabControl()
        Me.TPPersonaFisica = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CbMunicipioFis = New System.Windows.Forms.ComboBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.TbRfcFis = New System.Windows.Forms.TextBox()
        Me.CbEstadoFis = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TbCelularFis = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TbColoniaFis = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TbCurpFis = New System.Windows.Forms.TextBox()
        Me.TbCalleFis = New System.Windows.Forms.TextBox()
        Me.TbApoderadoFis = New System.Windows.Forms.TextBox()
        Me.TbNumeroFis = New System.Windows.Forms.TextBox()
        Me.TbTelefonoFis = New System.Windows.Forms.TextBox()
        Me.TbCorreoFis = New System.Windows.Forms.TextBox()
        Me.TPPersonaMoral = New System.Windows.Forms.TabPage()
        Me.GbApoderado = New System.Windows.Forms.GroupBox()
        Me.TbCorreoApoderado = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TbCelularApoderado = New System.Windows.Forms.TextBox()
        Me.TbTelefonoApoderado = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.CbMunicipioApoderado = New System.Windows.Forms.ComboBox()
        Me.CbEstadoApoderado = New System.Windows.Forms.ComboBox()
        Me.TbCalleApoderado = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TbIneApoderado = New System.Windows.Forms.TextBox()
        Me.TbCurpApoderado = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.TbRfcApoderado = New System.Windows.Forms.TextBox()
        Me.GbActaConstitutiva = New System.Windows.Forms.GroupBox()
        Me.TbFolioMercantil = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TbLibroActa = New System.Windows.Forms.TextBox()
        Me.TbNumeroActa = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TbRegPubActa = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TbNotarioActa = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.DtpFechaActa = New System.Windows.Forms.DateTimePicker()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.CbEstadoActa = New System.Windows.Forms.ComboBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TbFolioActa = New System.Windows.Forms.TextBox()
        Me.GbMovilizacion = New System.Windows.Forms.GroupBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.CbEstadoMovilizacion = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.CbCuentaDe = New System.Windows.Forms.ComboBox()
        Me.TbPredio = New System.Windows.Forms.TextBox()
        Me.TbSuperficie = New System.Windows.Forms.TextBox()
        Me.TbCertificado = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.CbMunicipioMovilizacion = New System.Windows.Forms.ComboBox()
        Me.CbEstatus = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.MSMenu.SuspendLayout()
        Me.TCTipoPersona.SuspendLayout()
        Me.TPPersonaFisica.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TPPersonaMoral.SuspendLayout()
        Me.GbApoderado.SuspendLayout()
        Me.GbActaConstitutiva.SuspendLayout()
        Me.GbMovilizacion.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MSMenu
        '
        Me.MSMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NuevoToolStripMenuItem, Me.GuardarToolStripMenuItem, Me.ConsultarToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MSMenu.Location = New System.Drawing.Point(0, 0)
        Me.MSMenu.Name = "MSMenu"
        Me.MSMenu.Size = New System.Drawing.Size(984, 24)
        Me.MSMenu.TabIndex = 0
        '
        'NuevoToolStripMenuItem
        '
        Me.NuevoToolStripMenuItem.Name = "NuevoToolStripMenuItem"
        Me.NuevoToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.NuevoToolStripMenuItem.Text = "Nuevo"
        '
        'GuardarToolStripMenuItem
        '
        Me.GuardarToolStripMenuItem.Name = "GuardarToolStripMenuItem"
        Me.GuardarToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.GuardarToolStripMenuItem.Text = "Guardar"
        '
        'ConsultarToolStripMenuItem
        '
        Me.ConsultarToolStripMenuItem.Name = "ConsultarToolStripMenuItem"
        Me.ConsultarToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.ConsultarToolStripMenuItem.Text = "Consultar"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(18, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "ID"
        '
        'TbIdCliente
        '
        Me.TbIdCliente.Enabled = False
        Me.TbIdCliente.Location = New System.Drawing.Point(124, 3)
        Me.TbIdCliente.Name = "TbIdCliente"
        Me.TbIdCliente.Size = New System.Drawing.Size(50, 20)
        Me.TbIdCliente.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(34, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Socio"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 62)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Nombre"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 85)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "TIpo de persona"
        '
        'TbSocio
        '
        Me.TbSocio.Location = New System.Drawing.Point(124, 29)
        Me.TbSocio.Name = "TbSocio"
        Me.TbSocio.Size = New System.Drawing.Size(139, 20)
        Me.TbSocio.TabIndex = 6
        '
        'TbNombre
        '
        Me.TbNombre.Location = New System.Drawing.Point(124, 55)
        Me.TbNombre.Name = "TbNombre"
        Me.TbNombre.Size = New System.Drawing.Size(313, 20)
        Me.TbNombre.TabIndex = 7
        '
        'CbTipoPersona
        '
        Me.CbTipoPersona.FormattingEnabled = True
        Me.CbTipoPersona.Location = New System.Drawing.Point(124, 82)
        Me.CbTipoPersona.Name = "CbTipoPersona"
        Me.CbTipoPersona.Size = New System.Drawing.Size(210, 21)
        Me.CbTipoPersona.TabIndex = 8
        '
        'TCTipoPersona
        '
        Me.TCTipoPersona.Controls.Add(Me.TPPersonaFisica)
        Me.TCTipoPersona.Controls.Add(Me.TPPersonaMoral)
        Me.TCTipoPersona.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TCTipoPersona.Location = New System.Drawing.Point(0, 181)
        Me.TCTipoPersona.Name = "TCTipoPersona"
        Me.TCTipoPersona.SelectedIndex = 0
        Me.TCTipoPersona.Size = New System.Drawing.Size(984, 306)
        Me.TCTipoPersona.TabIndex = 9
        '
        'TPPersonaFisica
        '
        Me.TPPersonaFisica.Controls.Add(Me.Panel1)
        Me.TPPersonaFisica.Location = New System.Drawing.Point(4, 22)
        Me.TPPersonaFisica.Name = "TPPersonaFisica"
        Me.TPPersonaFisica.Padding = New System.Windows.Forms.Padding(3)
        Me.TPPersonaFisica.Size = New System.Drawing.Size(976, 280)
        Me.TPPersonaFisica.TabIndex = 0
        Me.TPPersonaFisica.Text = "Persona Fisica"
        Me.TPPersonaFisica.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.CbMunicipioFis)
        Me.Panel1.Controls.Add(Me.Label39)
        Me.Panel1.Controls.Add(Me.TbRfcFis)
        Me.Panel1.Controls.Add(Me.CbEstadoFis)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.TbCelularFis)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.TbColoniaFis)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.TbCurpFis)
        Me.Panel1.Controls.Add(Me.TbCalleFis)
        Me.Panel1.Controls.Add(Me.TbApoderadoFis)
        Me.Panel1.Controls.Add(Me.TbNumeroFis)
        Me.Panel1.Controls.Add(Me.TbTelefonoFis)
        Me.Panel1.Controls.Add(Me.TbCorreoFis)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(970, 274)
        Me.Panel1.TabIndex = 10
        '
        'CbMunicipioFis
        '
        Me.CbMunicipioFis.FormattingEnabled = True
        Me.CbMunicipioFis.Location = New System.Drawing.Point(107, 149)
        Me.CbMunicipioFis.Name = "CbMunicipioFis"
        Me.CbMunicipioFis.Size = New System.Drawing.Size(210, 21)
        Me.CbMunicipioFis.TabIndex = 22
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(10, 156)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(52, 13)
        Me.Label39.TabIndex = 21
        Me.Label39.Text = "Municipio"
        '
        'TbRfcFis
        '
        Me.TbRfcFis.Location = New System.Drawing.Point(107, 14)
        Me.TbRfcFis.Name = "TbRfcFis"
        Me.TbRfcFis.Size = New System.Drawing.Size(210, 20)
        Me.TbRfcFis.TabIndex = 8
        '
        'CbEstadoFis
        '
        Me.CbEstadoFis.FormattingEnabled = True
        Me.CbEstadoFis.Location = New System.Drawing.Point(107, 122)
        Me.CbEstadoFis.Name = "CbEstadoFis"
        Me.CbEstadoFis.Size = New System.Drawing.Size(210, 21)
        Me.CbEstadoFis.TabIndex = 20
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 129)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 13)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Estado"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(406, 69)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 13)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "Telefono"
        '
        'TbCelularFis
        '
        Me.TbCelularFis.Location = New System.Drawing.Point(507, 40)
        Me.TbCelularFis.Name = "TbCelularFis"
        Me.TbCelularFis.Size = New System.Drawing.Size(210, 20)
        Me.TbCelularFis.TabIndex = 19
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 102)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Numero"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(406, 95)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(93, 13)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "Correo electronico"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(406, 43)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(39, 13)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "Celular"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(10, 75)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(30, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Calle"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(406, 121)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(59, 13)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "Apoderado"
        '
        'TbColoniaFis
        '
        Me.TbColoniaFis.Location = New System.Drawing.Point(507, 14)
        Me.TbColoniaFis.Name = "TbColoniaFis"
        Me.TbColoniaFis.Size = New System.Drawing.Size(210, 20)
        Me.TbColoniaFis.TabIndex = 17
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(10, 48)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(37, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "CURP"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 21)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "RFC"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(406, 17)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(42, 13)
        Me.Label13.TabIndex = 16
        Me.Label13.Text = "Colonia"
        '
        'TbCurpFis
        '
        Me.TbCurpFis.Location = New System.Drawing.Point(107, 41)
        Me.TbCurpFis.Name = "TbCurpFis"
        Me.TbCurpFis.Size = New System.Drawing.Size(210, 20)
        Me.TbCurpFis.TabIndex = 9
        '
        'TbCalleFis
        '
        Me.TbCalleFis.Location = New System.Drawing.Point(107, 68)
        Me.TbCalleFis.Name = "TbCalleFis"
        Me.TbCalleFis.Size = New System.Drawing.Size(210, 20)
        Me.TbCalleFis.TabIndex = 10
        '
        'TbApoderadoFis
        '
        Me.TbApoderadoFis.Location = New System.Drawing.Point(507, 118)
        Me.TbApoderadoFis.Name = "TbApoderadoFis"
        Me.TbApoderadoFis.Size = New System.Drawing.Size(280, 20)
        Me.TbApoderadoFis.TabIndex = 15
        '
        'TbNumeroFis
        '
        Me.TbNumeroFis.Location = New System.Drawing.Point(107, 95)
        Me.TbNumeroFis.Name = "TbNumeroFis"
        Me.TbNumeroFis.Size = New System.Drawing.Size(210, 20)
        Me.TbNumeroFis.TabIndex = 11
        '
        'TbTelefonoFis
        '
        Me.TbTelefonoFis.Location = New System.Drawing.Point(507, 66)
        Me.TbTelefonoFis.Name = "TbTelefonoFis"
        Me.TbTelefonoFis.Size = New System.Drawing.Size(210, 20)
        Me.TbTelefonoFis.TabIndex = 13
        '
        'TbCorreoFis
        '
        Me.TbCorreoFis.Location = New System.Drawing.Point(507, 92)
        Me.TbCorreoFis.Name = "TbCorreoFis"
        Me.TbCorreoFis.Size = New System.Drawing.Size(280, 20)
        Me.TbCorreoFis.TabIndex = 14
        '
        'TPPersonaMoral
        '
        Me.TPPersonaMoral.Controls.Add(Me.GbApoderado)
        Me.TPPersonaMoral.Controls.Add(Me.GbActaConstitutiva)
        Me.TPPersonaMoral.Location = New System.Drawing.Point(4, 22)
        Me.TPPersonaMoral.Name = "TPPersonaMoral"
        Me.TPPersonaMoral.Padding = New System.Windows.Forms.Padding(3)
        Me.TPPersonaMoral.Size = New System.Drawing.Size(976, 280)
        Me.TPPersonaMoral.TabIndex = 1
        Me.TPPersonaMoral.Text = "Persona Moral"
        Me.TPPersonaMoral.UseVisualStyleBackColor = True
        '
        'GbApoderado
        '
        Me.GbApoderado.Controls.Add(Me.TbCorreoApoderado)
        Me.GbApoderado.Controls.Add(Me.Label37)
        Me.GbApoderado.Controls.Add(Me.Label36)
        Me.GbApoderado.Controls.Add(Me.Label35)
        Me.GbApoderado.Controls.Add(Me.TbCelularApoderado)
        Me.GbApoderado.Controls.Add(Me.TbTelefonoApoderado)
        Me.GbApoderado.Controls.Add(Me.Label34)
        Me.GbApoderado.Controls.Add(Me.Label33)
        Me.GbApoderado.Controls.Add(Me.Label32)
        Me.GbApoderado.Controls.Add(Me.CbMunicipioApoderado)
        Me.GbApoderado.Controls.Add(Me.CbEstadoApoderado)
        Me.GbApoderado.Controls.Add(Me.TbCalleApoderado)
        Me.GbApoderado.Controls.Add(Me.Label31)
        Me.GbApoderado.Controls.Add(Me.Label30)
        Me.GbApoderado.Controls.Add(Me.TbIneApoderado)
        Me.GbApoderado.Controls.Add(Me.TbCurpApoderado)
        Me.GbApoderado.Controls.Add(Me.Label29)
        Me.GbApoderado.Controls.Add(Me.TbRfcApoderado)
        Me.GbApoderado.Location = New System.Drawing.Point(486, 9)
        Me.GbApoderado.Name = "GbApoderado"
        Me.GbApoderado.Size = New System.Drawing.Size(453, 241)
        Me.GbApoderado.TabIndex = 1
        Me.GbApoderado.TabStop = False
        Me.GbApoderado.Text = "Apoderado"
        '
        'TbCorreoApoderado
        '
        Me.TbCorreoApoderado.Location = New System.Drawing.Point(288, 16)
        Me.TbCorreoApoderado.Name = "TbCorreoApoderado"
        Me.TbCorreoApoderado.Size = New System.Drawing.Size(146, 20)
        Me.TbCorreoApoderado.TabIndex = 17
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(244, 19)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(38, 13)
        Me.Label37.TabIndex = 16
        Me.Label37.Text = "Correo"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(6, 203)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(39, 13)
        Me.Label36.TabIndex = 15
        Me.Label36.Text = "Celular"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(6, 177)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(49, 13)
        Me.Label35.TabIndex = 14
        Me.Label35.Text = "Telefono"
        '
        'TbCelularApoderado
        '
        Me.TbCelularApoderado.Location = New System.Drawing.Point(80, 200)
        Me.TbCelularApoderado.Name = "TbCelularApoderado"
        Me.TbCelularApoderado.Size = New System.Drawing.Size(148, 20)
        Me.TbCelularApoderado.TabIndex = 13
        '
        'TbTelefonoApoderado
        '
        Me.TbTelefonoApoderado.Location = New System.Drawing.Point(80, 174)
        Me.TbTelefonoApoderado.Name = "TbTelefonoApoderado"
        Me.TbTelefonoApoderado.Size = New System.Drawing.Size(148, 20)
        Me.TbTelefonoApoderado.TabIndex = 12
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(6, 150)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(52, 13)
        Me.Label34.TabIndex = 11
        Me.Label34.Text = "Municipio"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(6, 123)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(40, 13)
        Me.Label33.TabIndex = 10
        Me.Label33.Text = "Estado"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(6, 97)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(30, 13)
        Me.Label32.TabIndex = 9
        Me.Label32.Text = "Calle"
        '
        'CbMunicipioApoderado
        '
        Me.CbMunicipioApoderado.FormattingEnabled = True
        Me.CbMunicipioApoderado.Location = New System.Drawing.Point(80, 147)
        Me.CbMunicipioApoderado.Name = "CbMunicipioApoderado"
        Me.CbMunicipioApoderado.Size = New System.Drawing.Size(148, 21)
        Me.CbMunicipioApoderado.TabIndex = 8
        '
        'CbEstadoApoderado
        '
        Me.CbEstadoApoderado.FormattingEnabled = True
        Me.CbEstadoApoderado.Location = New System.Drawing.Point(80, 120)
        Me.CbEstadoApoderado.Name = "CbEstadoApoderado"
        Me.CbEstadoApoderado.Size = New System.Drawing.Size(148, 21)
        Me.CbEstadoApoderado.TabIndex = 7
        '
        'TbCalleApoderado
        '
        Me.TbCalleApoderado.Location = New System.Drawing.Point(80, 94)
        Me.TbCalleApoderado.Name = "TbCalleApoderado"
        Me.TbCalleApoderado.Size = New System.Drawing.Size(148, 20)
        Me.TbCalleApoderado.TabIndex = 6
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(6, 71)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(43, 13)
        Me.Label31.TabIndex = 5
        Me.Label31.Text = "No. IFE"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(6, 45)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(37, 13)
        Me.Label30.TabIndex = 4
        Me.Label30.Text = "CURP"
        '
        'TbIneApoderado
        '
        Me.TbIneApoderado.Location = New System.Drawing.Point(80, 68)
        Me.TbIneApoderado.Name = "TbIneApoderado"
        Me.TbIneApoderado.Size = New System.Drawing.Size(148, 20)
        Me.TbIneApoderado.TabIndex = 3
        '
        'TbCurpApoderado
        '
        Me.TbCurpApoderado.Location = New System.Drawing.Point(80, 42)
        Me.TbCurpApoderado.Name = "TbCurpApoderado"
        Me.TbCurpApoderado.Size = New System.Drawing.Size(148, 20)
        Me.TbCurpApoderado.TabIndex = 2
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(6, 19)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(28, 13)
        Me.Label29.TabIndex = 1
        Me.Label29.Text = "RFC"
        '
        'TbRfcApoderado
        '
        Me.TbRfcApoderado.Location = New System.Drawing.Point(80, 16)
        Me.TbRfcApoderado.Name = "TbRfcApoderado"
        Me.TbRfcApoderado.Size = New System.Drawing.Size(148, 20)
        Me.TbRfcApoderado.TabIndex = 0
        '
        'GbActaConstitutiva
        '
        Me.GbActaConstitutiva.Controls.Add(Me.TbFolioMercantil)
        Me.GbActaConstitutiva.Controls.Add(Me.Label28)
        Me.GbActaConstitutiva.Controls.Add(Me.Label27)
        Me.GbActaConstitutiva.Controls.Add(Me.Label25)
        Me.GbActaConstitutiva.Controls.Add(Me.TbLibroActa)
        Me.GbActaConstitutiva.Controls.Add(Me.TbNumeroActa)
        Me.GbActaConstitutiva.Controls.Add(Me.Label24)
        Me.GbActaConstitutiva.Controls.Add(Me.TbRegPubActa)
        Me.GbActaConstitutiva.Controls.Add(Me.Label23)
        Me.GbActaConstitutiva.Controls.Add(Me.TbNotarioActa)
        Me.GbActaConstitutiva.Controls.Add(Me.Label22)
        Me.GbActaConstitutiva.Controls.Add(Me.DtpFechaActa)
        Me.GbActaConstitutiva.Controls.Add(Me.Label21)
        Me.GbActaConstitutiva.Controls.Add(Me.CbEstadoActa)
        Me.GbActaConstitutiva.Controls.Add(Me.Label20)
        Me.GbActaConstitutiva.Controls.Add(Me.TbFolioActa)
        Me.GbActaConstitutiva.Location = New System.Drawing.Point(6, 6)
        Me.GbActaConstitutiva.Name = "GbActaConstitutiva"
        Me.GbActaConstitutiva.Size = New System.Drawing.Size(461, 241)
        Me.GbActaConstitutiva.TabIndex = 0
        Me.GbActaConstitutiva.TabStop = False
        Me.GbActaConstitutiva.Text = "Acta Constitutiva"
        '
        'TbFolioMercantil
        '
        Me.TbFolioMercantil.Location = New System.Drawing.Point(329, 19)
        Me.TbFolioMercantil.Name = "TbFolioMercantil"
        Me.TbFolioMercantil.Size = New System.Drawing.Size(126, 20)
        Me.TbFolioMercantil.TabIndex = 17
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(249, 22)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(75, 13)
        Me.Label28.TabIndex = 16
        Me.Label28.Text = "Folio Mercantil"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(7, 179)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(30, 13)
        Me.Label27.TabIndex = 15
        Me.Label27.Text = "Libro"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(7, 153)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(85, 13)
        Me.Label25.TabIndex = 13
        Me.Label25.Text = "Bajo del Numero"
        '
        'TbLibroActa
        '
        Me.TbLibroActa.Location = New System.Drawing.Point(104, 176)
        Me.TbLibroActa.Name = "TbLibroActa"
        Me.TbLibroActa.Size = New System.Drawing.Size(139, 20)
        Me.TbLibroActa.TabIndex = 12
        '
        'TbNumeroActa
        '
        Me.TbNumeroActa.Location = New System.Drawing.Point(104, 150)
        Me.TbNumeroActa.Name = "TbNumeroActa"
        Me.TbNumeroActa.Size = New System.Drawing.Size(139, 20)
        Me.TbNumeroActa.TabIndex = 10
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(7, 127)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(84, 13)
        Me.Label24.TabIndex = 9
        Me.Label24.Text = "Registro Publico"
        '
        'TbRegPubActa
        '
        Me.TbRegPubActa.Location = New System.Drawing.Point(104, 124)
        Me.TbRegPubActa.Name = "TbRegPubActa"
        Me.TbRegPubActa.Size = New System.Drawing.Size(139, 20)
        Me.TbRegPubActa.TabIndex = 8
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(7, 101)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(69, 13)
        Me.Label23.TabIndex = 7
        Me.Label23.Text = "Num. Notario"
        '
        'TbNotarioActa
        '
        Me.TbNotarioActa.Location = New System.Drawing.Point(104, 98)
        Me.TbNotarioActa.Name = "TbNotarioActa"
        Me.TbNotarioActa.Size = New System.Drawing.Size(139, 20)
        Me.TbNotarioActa.TabIndex = 6
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(7, 78)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(37, 13)
        Me.Label22.TabIndex = 5
        Me.Label22.Text = "Fecha"
        '
        'DtpFechaActa
        '
        Me.DtpFechaActa.Location = New System.Drawing.Point(104, 72)
        Me.DtpFechaActa.Name = "DtpFechaActa"
        Me.DtpFechaActa.Size = New System.Drawing.Size(139, 20)
        Me.DtpFechaActa.TabIndex = 4
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(7, 48)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(40, 13)
        Me.Label21.TabIndex = 3
        Me.Label21.Text = "Estado"
        '
        'CbEstadoActa
        '
        Me.CbEstadoActa.FormattingEnabled = True
        Me.CbEstadoActa.Location = New System.Drawing.Point(104, 45)
        Me.CbEstadoActa.Name = "CbEstadoActa"
        Me.CbEstadoActa.Size = New System.Drawing.Size(139, 21)
        Me.CbEstadoActa.TabIndex = 2
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(7, 22)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(29, 13)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Folio"
        '
        'TbFolioActa
        '
        Me.TbFolioActa.Location = New System.Drawing.Point(104, 19)
        Me.TbFolioActa.Name = "TbFolioActa"
        Me.TbFolioActa.Size = New System.Drawing.Size(139, 20)
        Me.TbFolioActa.TabIndex = 0
        '
        'GbMovilizacion
        '
        Me.GbMovilizacion.Controls.Add(Me.Label38)
        Me.GbMovilizacion.Controls.Add(Me.CbEstadoMovilizacion)
        Me.GbMovilizacion.Controls.Add(Me.Label19)
        Me.GbMovilizacion.Controls.Add(Me.Label18)
        Me.GbMovilizacion.Controls.Add(Me.Label17)
        Me.GbMovilizacion.Controls.Add(Me.Label16)
        Me.GbMovilizacion.Controls.Add(Me.CbCuentaDe)
        Me.GbMovilizacion.Controls.Add(Me.TbPredio)
        Me.GbMovilizacion.Controls.Add(Me.TbSuperficie)
        Me.GbMovilizacion.Controls.Add(Me.TbCertificado)
        Me.GbMovilizacion.Controls.Add(Me.Label15)
        Me.GbMovilizacion.Controls.Add(Me.CbMunicipioMovilizacion)
        Me.GbMovilizacion.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.GbMovilizacion.Location = New System.Drawing.Point(0, 487)
        Me.GbMovilizacion.Name = "GbMovilizacion"
        Me.GbMovilizacion.Size = New System.Drawing.Size(984, 150)
        Me.GbMovilizacion.TabIndex = 10
        Me.GbMovilizacion.TabStop = False
        Me.GbMovilizacion.Text = "Movilizacion de Algodon"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(8, 22)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(40, 13)
        Me.Label38.TabIndex = 11
        Me.Label38.Text = "Estado"
        '
        'CbEstadoMovilizacion
        '
        Me.CbEstadoMovilizacion.FormattingEnabled = True
        Me.CbEstadoMovilizacion.Location = New System.Drawing.Point(110, 19)
        Me.CbEstadoMovilizacion.Name = "CbEstadoMovilizacion"
        Me.CbEstadoMovilizacion.Size = New System.Drawing.Size(210, 21)
        Me.CbEstadoMovilizacion.TabIndex = 10
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(409, 78)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(75, 13)
        Me.Label19.TabIndex = 9
        Me.Label19.Text = "Por Cuenta de"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(409, 52)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(37, 13)
        Me.Label18.TabIndex = 8
        Me.Label18.Text = "Predio"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(409, 25)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(86, 13)
        Me.Label17.TabIndex = 7
        Me.Label17.Text = "Sup. Cosechada"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 76)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(57, 13)
        Me.Label16.TabIndex = 6
        Me.Label16.Text = "Certificado"
        '
        'CbCuentaDe
        '
        Me.CbCuentaDe.FormattingEnabled = True
        Me.CbCuentaDe.Location = New System.Drawing.Point(510, 75)
        Me.CbCuentaDe.Name = "CbCuentaDe"
        Me.CbCuentaDe.Size = New System.Drawing.Size(280, 21)
        Me.CbCuentaDe.TabIndex = 5
        '
        'TbPredio
        '
        Me.TbPredio.Location = New System.Drawing.Point(510, 49)
        Me.TbPredio.Name = "TbPredio"
        Me.TbPredio.Size = New System.Drawing.Size(210, 20)
        Me.TbPredio.TabIndex = 4
        '
        'TbSuperficie
        '
        Me.TbSuperficie.Location = New System.Drawing.Point(510, 22)
        Me.TbSuperficie.Name = "TbSuperficie"
        Me.TbSuperficie.Size = New System.Drawing.Size(210, 20)
        Me.TbSuperficie.TabIndex = 3
        '
        'TbCertificado
        '
        Me.TbCertificado.Location = New System.Drawing.Point(110, 73)
        Me.TbCertificado.Name = "TbCertificado"
        Me.TbCertificado.Size = New System.Drawing.Size(210, 20)
        Me.TbCertificado.TabIndex = 2
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(6, 49)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(52, 13)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Municipio"
        '
        'CbMunicipioMovilizacion
        '
        Me.CbMunicipioMovilizacion.FormattingEnabled = True
        Me.CbMunicipioMovilizacion.Location = New System.Drawing.Point(110, 46)
        Me.CbMunicipioMovilizacion.Name = "CbMunicipioMovilizacion"
        Me.CbMunicipioMovilizacion.Size = New System.Drawing.Size(210, 21)
        Me.CbMunicipioMovilizacion.TabIndex = 0
        '
        'CbEstatus
        '
        Me.CbEstatus.FormattingEnabled = True
        Me.CbEstatus.Location = New System.Drawing.Point(124, 109)
        Me.CbEstatus.Name = "CbEstatus"
        Me.CbEstatus.Size = New System.Drawing.Size(210, 21)
        Me.CbEstatus.TabIndex = 11
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(7, 112)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(42, 13)
        Me.Label26.TabIndex = 12
        Me.Label26.Text = "Estatus"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.TbIdCliente)
        Me.Panel2.Controls.Add(Me.Label26)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.CbEstatus)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.CbTipoPersona)
        Me.Panel2.Controls.Add(Me.TbSocio)
        Me.Panel2.Controls.Add(Me.TbNombre)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 24)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(984, 157)
        Me.Panel2.TabIndex = 13
        '
        'Clientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 637)
        Me.Controls.Add(Me.TCTipoPersona)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.GbMovilizacion)
        Me.Controls.Add(Me.MSMenu)
        Me.MainMenuStrip = Me.MSMenu
        Me.Name = "Clientes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Clientes"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MSMenu.ResumeLayout(False)
        Me.MSMenu.PerformLayout()
        Me.TCTipoPersona.ResumeLayout(False)
        Me.TPPersonaFisica.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TPPersonaMoral.ResumeLayout(False)
        Me.GbApoderado.ResumeLayout(False)
        Me.GbApoderado.PerformLayout()
        Me.GbActaConstitutiva.ResumeLayout(False)
        Me.GbActaConstitutiva.PerformLayout()
        Me.GbMovilizacion.ResumeLayout(False)
        Me.GbMovilizacion.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MSMenu As MenuStrip
    Friend WithEvents NuevoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GuardarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConsultarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents TbIdCliente As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TbSocio As TextBox
    Friend WithEvents TbNombre As TextBox
    Friend WithEvents CbTipoPersona As ComboBox
    Friend WithEvents TCTipoPersona As TabControl
    Friend WithEvents TPPersonaFisica As TabPage
    Friend WithEvents CbEstadoFis As ComboBox
    Friend WithEvents TbCelularFis As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents TbColoniaFis As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents TbApoderadoFis As TextBox
    Friend WithEvents TbCorreoFis As TextBox
    Friend WithEvents TbTelefonoFis As TextBox
    Friend WithEvents TbNumeroFis As TextBox
    Friend WithEvents TbCalleFis As TextBox
    Friend WithEvents TbCurpFis As TextBox
    Friend WithEvents TbRfcFis As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TPPersonaMoral As TabPage
    Friend WithEvents Panel1 As Panel
    Friend WithEvents GbMovilizacion As GroupBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents CbCuentaDe As ComboBox
    Friend WithEvents TbPredio As TextBox
    Friend WithEvents TbSuperficie As TextBox
    Friend WithEvents TbCertificado As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents CbMunicipioMovilizacion As ComboBox
    Friend WithEvents GbApoderado As GroupBox
    Friend WithEvents GbActaConstitutiva As GroupBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents TbLibroActa As TextBox
    Friend WithEvents TbNumeroActa As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents TbRegPubActa As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents TbNotarioActa As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents DtpFechaActa As DateTimePicker
    Friend WithEvents Label21 As Label
    Friend WithEvents CbEstadoActa As ComboBox
    Friend WithEvents Label20 As Label
    Friend WithEvents TbFolioActa As TextBox
    Friend WithEvents TbFolioMercantil As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents CbMunicipioApoderado As ComboBox
    Friend WithEvents CbEstadoApoderado As ComboBox
    Friend WithEvents TbCalleApoderado As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents TbIneApoderado As TextBox
    Friend WithEvents TbCurpApoderado As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents TbRfcApoderado As TextBox
    Friend WithEvents TbCorreoApoderado As TextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents TbCelularApoderado As TextBox
    Friend WithEvents TbTelefonoApoderado As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents CbEstadoMovilizacion As ComboBox
    Friend WithEvents CbMunicipioFis As ComboBox
    Friend WithEvents Label39 As Label
    Friend WithEvents CbEstatus As ComboBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Panel2 As Panel
End Class
