﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProduccionTecladoFijo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MSMenu = New System.Windows.Forms.MenuStrip()
        Me.NuevoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GuardarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GbDatosGenerales = New System.Windows.Forms.GroupBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GbResumen = New System.Windows.Forms.GroupBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.GbDatosProduccion = New System.Windows.Forms.GroupBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GbModulos = New System.Windows.Forms.GroupBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.DgvPacas = New System.Windows.Forms.DataGridView()
        Me.GbCapturaAutomatica = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.GbLotes = New System.Windows.Forms.GroupBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.GbTeclado = New System.Windows.Forms.GroupBox()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.MSMenu.SuspendLayout()
        Me.GbDatosGenerales.SuspendLayout()
        Me.GbResumen.SuspendLayout()
        Me.GbDatosProduccion.SuspendLayout()
        Me.GbModulos.SuspendLayout()
        CType(Me.DgvPacas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GbCapturaAutomatica.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GbLotes.SuspendLayout()
        Me.GbTeclado.SuspendLayout()
        Me.SuspendLayout()
        '
        'MSMenu
        '
        Me.MSMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NuevoToolStripMenuItem, Me.GuardarToolStripMenuItem, Me.ConsultarToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MSMenu.Location = New System.Drawing.Point(0, 0)
        Me.MSMenu.Name = "MSMenu"
        Me.MSMenu.Size = New System.Drawing.Size(1075, 24)
        Me.MSMenu.TabIndex = 0
        '
        'NuevoToolStripMenuItem
        '
        Me.NuevoToolStripMenuItem.Name = "NuevoToolStripMenuItem"
        Me.NuevoToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.NuevoToolStripMenuItem.Text = "Nuevo"
        '
        'GuardarToolStripMenuItem
        '
        Me.GuardarToolStripMenuItem.Name = "GuardarToolStripMenuItem"
        Me.GuardarToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.GuardarToolStripMenuItem.Text = "Guardar"
        '
        'ConsultarToolStripMenuItem
        '
        Me.ConsultarToolStripMenuItem.Name = "ConsultarToolStripMenuItem"
        Me.ConsultarToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.ConsultarToolStripMenuItem.Text = "Consultar"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'GbDatosGenerales
        '
        Me.GbDatosGenerales.Controls.Add(Me.ComboBox1)
        Me.GbDatosGenerales.Controls.Add(Me.Label7)
        Me.GbDatosGenerales.Controls.Add(Me.Label1)
        Me.GbDatosGenerales.Controls.Add(Me.ComboBox5)
        Me.GbDatosGenerales.Controls.Add(Me.TextBox1)
        Me.GbDatosGenerales.Controls.Add(Me.Label6)
        Me.GbDatosGenerales.Controls.Add(Me.Label2)
        Me.GbDatosGenerales.Controls.Add(Me.ComboBox4)
        Me.GbDatosGenerales.Controls.Add(Me.ComboBox2)
        Me.GbDatosGenerales.Controls.Add(Me.Label5)
        Me.GbDatosGenerales.Controls.Add(Me.Label3)
        Me.GbDatosGenerales.Controls.Add(Me.ComboBox3)
        Me.GbDatosGenerales.Controls.Add(Me.DateTimePicker1)
        Me.GbDatosGenerales.Controls.Add(Me.Label4)
        Me.GbDatosGenerales.Location = New System.Drawing.Point(12, 27)
        Me.GbDatosGenerales.Name = "GbDatosGenerales"
        Me.GbDatosGenerales.Size = New System.Drawing.Size(424, 208)
        Me.GbDatosGenerales.TabIndex = 16
        Me.GbDatosGenerales.TabStop = False
        Me.GbDatosGenerales.Text = "Datos Generales"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(130, 45)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(188, 21)
        Me.ComboBox1.TabIndex = 3
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(11, 182)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Por Cuenta de"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(18, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "ID"
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(130, 179)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(287, 21)
        Me.ComboBox5.TabIndex = 13
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(130, 19)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(11, 155)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Productor"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Planta Origen"
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(130, 152)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(287, 21)
        Me.ComboBox4.TabIndex = 11
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(130, 72)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(188, 21)
        Me.ComboBox2.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(11, 128)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Tipo"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 75)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Planta Elabora"
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(130, 125)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 9
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(130, 99)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(11, 105)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Fecha"
        '
        'GbResumen
        '
        Me.GbResumen.Controls.Add(Me.TextBox9)
        Me.GbResumen.Controls.Add(Me.Label18)
        Me.GbResumen.Controls.Add(Me.TextBox2)
        Me.GbResumen.Controls.Add(Me.TextBox12)
        Me.GbResumen.Controls.Add(Me.Label8)
        Me.GbResumen.Controls.Add(Me.TextBox11)
        Me.GbResumen.Controls.Add(Me.TextBox3)
        Me.GbResumen.Controls.Add(Me.TextBox10)
        Me.GbResumen.Controls.Add(Me.TextBox4)
        Me.GbResumen.Controls.Add(Me.TextBox5)
        Me.GbResumen.Controls.Add(Me.TextBox8)
        Me.GbResumen.Controls.Add(Me.TextBox6)
        Me.GbResumen.Controls.Add(Me.Label17)
        Me.GbResumen.Controls.Add(Me.Label9)
        Me.GbResumen.Controls.Add(Me.Label16)
        Me.GbResumen.Controls.Add(Me.Label10)
        Me.GbResumen.Controls.Add(Me.Label15)
        Me.GbResumen.Controls.Add(Me.Label11)
        Me.GbResumen.Controls.Add(Me.Label14)
        Me.GbResumen.Controls.Add(Me.Label12)
        Me.GbResumen.Controls.Add(Me.Label13)
        Me.GbResumen.Controls.Add(Me.TextBox7)
        Me.GbResumen.Location = New System.Drawing.Point(442, 30)
        Me.GbResumen.Name = "GbResumen"
        Me.GbResumen.Size = New System.Drawing.Size(353, 205)
        Me.GbResumen.TabIndex = 39
        Me.GbResumen.TabStop = False
        Me.GbResumen.Text = "Resumen"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(241, 45)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 20)
        Me.TextBox9.TabIndex = 33
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(203, 182)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(15, 13)
        Me.Label18.TabIndex = 37
        Me.Label18.Text = "%"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(97, 19)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 16
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(241, 175)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(100, 20)
        Me.TextBox12.TabIndex = 36
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(9, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Total Hueso"
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(241, 149)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(100, 20)
        Me.TextBox11.TabIndex = 35
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(97, 45)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 18
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(241, 123)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 20)
        Me.TextBox10.TabIndex = 34
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(97, 71)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 19
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(97, 97)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 20)
        Me.TextBox5.TabIndex = 20
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(97, 175)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 32
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(97, 123)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 20)
        Me.TextBox6.TabIndex = 21
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(203, 152)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(15, 13)
        Me.Label17.TabIndex = 31
        Me.Label17.Text = "%"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(9, 48)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(37, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Pacas"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(203, 126)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(15, 13)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "%"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(9, 74)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 13)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Pluma (Pacas)"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(203, 48)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(32, 13)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "Borra"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(9, 100)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(87, 13)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "Pluma (Borregos)"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(10, 178)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(39, 13)
        Me.Label14.TabIndex = 28
        Me.Label14.Text = "Merma"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(9, 126)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 13)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "Pluma"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(9, 152)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(40, 13)
        Me.Label13.TabIndex = 27
        Me.Label13.Text = "Semilla"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(97, 149)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 20)
        Me.TextBox7.TabIndex = 26
        '
        'GbDatosProduccion
        '
        Me.GbDatosProduccion.Controls.Add(Me.TextBox13)
        Me.GbDatosProduccion.Controls.Add(Me.Button3)
        Me.GbDatosProduccion.Controls.Add(Me.TextBox14)
        Me.GbDatosProduccion.Controls.Add(Me.Label24)
        Me.GbDatosProduccion.Controls.Add(Me.TextBox15)
        Me.GbDatosProduccion.Controls.Add(Me.Label23)
        Me.GbDatosProduccion.Controls.Add(Me.Label19)
        Me.GbDatosProduccion.Controls.Add(Me.Label22)
        Me.GbDatosProduccion.Controls.Add(Me.Label20)
        Me.GbDatosProduccion.Controls.Add(Me.TextBox18)
        Me.GbDatosProduccion.Controls.Add(Me.Label21)
        Me.GbDatosProduccion.Controls.Add(Me.TextBox17)
        Me.GbDatosProduccion.Controls.Add(Me.Button1)
        Me.GbDatosProduccion.Controls.Add(Me.TextBox16)
        Me.GbDatosProduccion.Controls.Add(Me.Button2)
        Me.GbDatosProduccion.Location = New System.Drawing.Point(801, 30)
        Me.GbDatosProduccion.Name = "GbDatosProduccion"
        Me.GbDatosProduccion.Size = New System.Drawing.Size(256, 205)
        Me.GbDatosProduccion.TabIndex = 55
        Me.GbDatosProduccion.TabStop = False
        Me.GbDatosProduccion.Text = "Datos de Produccion"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(115, 19)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(100, 20)
        Me.TextBox13.TabIndex = 39
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(221, 97)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(25, 23)
        Me.Button3.TabIndex = 53
        Me.Button3.Text = "..."
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(115, 45)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(100, 20)
        Me.TextBox14.TabIndex = 40
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(9, 181)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(29, 13)
        Me.Label24.TabIndex = 52
        Me.Label24.Text = "Kilos"
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(115, 71)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(100, 20)
        Me.TextBox15.TabIndex = 41
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(9, 155)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(69, 13)
        Me.Label23.TabIndex = 51
        Me.Label23.Text = "Folio Clientes"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(9, 22)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(35, 13)
        Me.Label19.TabIndex = 42
        Me.Label19.Text = "Turno"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(9, 129)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(49, 13)
        Me.Label22.TabIndex = 50
        Me.Label22.Text = "Folio CIA"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(9, 48)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(28, 13)
        Me.Label20.TabIndex = 43
        Me.Label20.Text = "Tipo"
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(115, 178)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(100, 20)
        Me.TextBox18.TabIndex = 49
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(9, 74)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(51, 13)
        Me.Label21.TabIndex = 44
        Me.Label21.Text = "Operador"
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(115, 152)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(100, 20)
        Me.TextBox17.TabIndex = 48
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 97)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(95, 23)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "Abrir Produccion"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(115, 126)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(100, 20)
        Me.TextBox16.TabIndex = 47
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(115, 97)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 23)
        Me.Button2.TabIndex = 46
        Me.Button2.Text = "Cerrar Produccion"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GbModulos
        '
        Me.GbModulos.Controls.Add(Me.TextBox20)
        Me.GbModulos.Controls.Add(Me.Label25)
        Me.GbModulos.Controls.Add(Me.TextBox19)
        Me.GbModulos.Location = New System.Drawing.Point(12, 241)
        Me.GbModulos.Name = "GbModulos"
        Me.GbModulos.Size = New System.Drawing.Size(1052, 124)
        Me.GbModulos.TabIndex = 56
        Me.GbModulos.TabStop = False
        Me.GbModulos.Text = "Modulos"
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(101, 97)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(100, 20)
        Me.TextBox20.TabIndex = 56
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(6, 100)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(89, 13)
        Me.Label25.TabIndex = 56
        Me.Label25.Text = "Total de Modulos"
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(6, 19)
        Me.TextBox19.Multiline = True
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(1039, 72)
        Me.TextBox19.TabIndex = 0
        '
        'DgvPacas
        '
        Me.DgvPacas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvPacas.Location = New System.Drawing.Point(12, 371)
        Me.DgvPacas.Name = "DgvPacas"
        Me.DgvPacas.Size = New System.Drawing.Size(724, 409)
        Me.DgvPacas.TabIndex = 57
        '
        'GbCapturaAutomatica
        '
        Me.GbCapturaAutomatica.Controls.Add(Me.Button4)
        Me.GbCapturaAutomatica.Controls.Add(Me.Button7)
        Me.GbCapturaAutomatica.Controls.Add(Me.Button5)
        Me.GbCapturaAutomatica.Controls.Add(Me.Button6)
        Me.GbCapturaAutomatica.Controls.Add(Me.NumericUpDown1)
        Me.GbCapturaAutomatica.Location = New System.Drawing.Point(742, 529)
        Me.GbCapturaAutomatica.Name = "GbCapturaAutomatica"
        Me.GbCapturaAutomatica.Size = New System.Drawing.Size(322, 155)
        Me.GbCapturaAutomatica.TabIndex = 63
        Me.GbCapturaAutomatica.TabStop = False
        Me.GbCapturaAutomatica.Text = "Captura de Lotes Automatico"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(6, 19)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(305, 29)
        Me.Button4.TabIndex = 57
        Me.Button4.Text = "Activar Lectura de Prensa"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(6, 115)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(305, 29)
        Me.Button7.TabIndex = 61
        Me.Button7.Text = "Incidencias"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(6, 54)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(305, 29)
        Me.Button5.TabIndex = 58
        Me.Button5.Text = "Agregar Pacas desde Archivo de Excel"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(127, 86)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 60
        Me.Button6.Text = "Imprimir"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(6, 89)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(120, 20)
        Me.NumericUpDown1.TabIndex = 59
        '
        'GbLotes
        '
        Me.GbLotes.Controls.Add(Me.Button11)
        Me.GbLotes.Controls.Add(Me.Button10)
        Me.GbLotes.Controls.Add(Me.Button9)
        Me.GbLotes.Controls.Add(Me.Button8)
        Me.GbLotes.Location = New System.Drawing.Point(742, 690)
        Me.GbLotes.Name = "GbLotes"
        Me.GbLotes.Size = New System.Drawing.Size(322, 90)
        Me.GbLotes.TabIndex = 64
        Me.GbLotes.TabStop = False
        Me.GbLotes.Text = "Lotes"
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(185, 48)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(131, 23)
        Me.Button11.TabIndex = 3
        Me.Button11.Text = "Final"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(6, 48)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(131, 23)
        Me.Button10.TabIndex = 2
        Me.Button10.Text = "Inicio"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(184, 19)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(131, 23)
        Me.Button9.TabIndex = 1
        Me.Button9.Text = "Siguiente"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(6, 19)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(131, 23)
        Me.Button8.TabIndex = 0
        Me.Button8.Text = "Anterior"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'GbTeclado
        '
        Me.GbTeclado.Controls.Add(Me.Button23)
        Me.GbTeclado.Controls.Add(Me.Button22)
        Me.GbTeclado.Controls.Add(Me.Button21)
        Me.GbTeclado.Controls.Add(Me.Button20)
        Me.GbTeclado.Controls.Add(Me.Button19)
        Me.GbTeclado.Controls.Add(Me.Button18)
        Me.GbTeclado.Controls.Add(Me.Button17)
        Me.GbTeclado.Controls.Add(Me.Button16)
        Me.GbTeclado.Controls.Add(Me.Button15)
        Me.GbTeclado.Controls.Add(Me.Button14)
        Me.GbTeclado.Controls.Add(Me.Button13)
        Me.GbTeclado.Controls.Add(Me.Button12)
        Me.GbTeclado.Location = New System.Drawing.Point(742, 371)
        Me.GbTeclado.Name = "GbTeclado"
        Me.GbTeclado.Size = New System.Drawing.Size(321, 152)
        Me.GbTeclado.TabIndex = 65
        Me.GbTeclado.TabStop = False
        Me.GbTeclado.Text = "Teclado"
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(6, 19)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(47, 23)
        Me.Button12.TabIndex = 0
        Me.Button12.Text = "1"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(59, 19)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(47, 23)
        Me.Button13.TabIndex = 1
        Me.Button13.Text = "2"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(112, 19)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(47, 23)
        Me.Button14.TabIndex = 2
        Me.Button14.Text = "3"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(6, 48)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(47, 23)
        Me.Button15.TabIndex = 3
        Me.Button15.Text = "4"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(59, 48)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(47, 23)
        Me.Button16.TabIndex = 4
        Me.Button16.Text = "5"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(112, 48)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(47, 23)
        Me.Button17.TabIndex = 5
        Me.Button17.Text = "6"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(6, 77)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(47, 23)
        Me.Button18.TabIndex = 6
        Me.Button18.Text = "7"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(59, 77)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(47, 23)
        Me.Button19.TabIndex = 7
        Me.Button19.Text = "8"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(112, 77)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(47, 23)
        Me.Button20.TabIndex = 8
        Me.Button20.Text = "9"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(59, 106)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(47, 23)
        Me.Button21.TabIndex = 9
        Me.Button21.Text = "0"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(174, 19)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(141, 23)
        Me.Button22.TabIndex = 10
        Me.Button22.Text = "Aceptar"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(174, 48)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(141, 23)
        Me.Button23.TabIndex = 11
        Me.Button23.Text = "Borrar"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'ProduccionTecladoFijo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1075, 799)
        Me.Controls.Add(Me.GbTeclado)
        Me.Controls.Add(Me.GbLotes)
        Me.Controls.Add(Me.GbCapturaAutomatica)
        Me.Controls.Add(Me.DgvPacas)
        Me.Controls.Add(Me.GbModulos)
        Me.Controls.Add(Me.GbDatosProduccion)
        Me.Controls.Add(Me.GbResumen)
        Me.Controls.Add(Me.GbDatosGenerales)
        Me.Controls.Add(Me.MSMenu)
        Me.MainMenuStrip = Me.MSMenu
        Me.Name = "ProduccionTecladoFijo"
        Me.Text = "Produccion (Teclado Fijo)"
        Me.MSMenu.ResumeLayout(False)
        Me.MSMenu.PerformLayout()
        Me.GbDatosGenerales.ResumeLayout(False)
        Me.GbDatosGenerales.PerformLayout()
        Me.GbResumen.ResumeLayout(False)
        Me.GbResumen.PerformLayout()
        Me.GbDatosProduccion.ResumeLayout(False)
        Me.GbDatosProduccion.PerformLayout()
        Me.GbModulos.ResumeLayout(False)
        Me.GbModulos.PerformLayout()
        CType(Me.DgvPacas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GbCapturaAutomatica.ResumeLayout(False)
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GbLotes.ResumeLayout(False)
        Me.GbTeclado.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MSMenu As MenuStrip
    Friend WithEvents NuevoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GuardarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConsultarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GbDatosGenerales As GroupBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents GbResumen As GroupBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents GbDatosProduccion As GroupBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents GbModulos As GroupBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents TextBox19 As TextBox
    Friend WithEvents DgvPacas As DataGridView
    Friend WithEvents GbCapturaAutomatica As GroupBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents GbLotes As GroupBox
    Friend WithEvents Button11 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents GbTeclado As GroupBox
    Friend WithEvents Button23 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button12 As Button
End Class
