﻿Public Class Puestos
    Inherits Tarjeta
    Public IdPuesto As Integer
    Public Descripcion As String
    Public IdEstatus As Integer
End Class
