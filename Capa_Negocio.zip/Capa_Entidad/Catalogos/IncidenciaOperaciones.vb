﻿Public Class IncidenciaOperaciones
    Inherits Tarjeta
    Public IdIncidencia As String
    Public IdTipo As Integer
    Public Descripcion As String
    Public IdEstatus As Integer
End Class
