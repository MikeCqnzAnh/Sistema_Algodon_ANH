﻿Public Class Compradores
    Inherits Tarjeta
    Public IdComprador As Integer
    Public Nombre As String
    Public Rfc As String
    Public Curp As String
    Public Domicilio As String
    Public IdEstado As Integer
    Public idMunicipio As Integer
    Public Telefono As String
    Public Correo As String
    Public IdEstatus As Integer
End Class
