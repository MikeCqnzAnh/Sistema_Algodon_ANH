﻿Public Class Plantas
    Inherits Tarjeta
    Public IdPlanta As Integer
    Public Descripcion As String
    Public Registro As String
    Public IdEstatus As Integer
End Class
