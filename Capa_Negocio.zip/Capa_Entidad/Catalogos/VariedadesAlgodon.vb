﻿Public Class VariedadesAlgodon
    Inherits Tarjeta
    Public IdVariedadAlgodon As Integer
    Public Descripcion As String
    Public IdEstatus As Integer
End Class
