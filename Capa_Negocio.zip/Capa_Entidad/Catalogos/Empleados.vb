﻿Public Class Empleados
    Inherits Tarjeta
    Public IdEmpleado As Integer
    Public Nombre As String
    Public IdPuesto As Integer
    Public IdEstatus As Integer
End Class
