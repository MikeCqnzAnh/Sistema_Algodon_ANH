﻿Public Class TiposIncidencias
    Inherits Tarjeta
    Public IdTipoIncidencia As Integer
    Public Descripcion As String
    Public IdEstatus As Integer
End Class
