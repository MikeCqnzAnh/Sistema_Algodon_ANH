﻿Public Class RegimenHidrico
    Inherits Tarjeta
    Public IdRegimen As Integer
    Public Descripcion As String
    Public IdEstatus As Integer
End Class
