﻿Public Class Asociaciones
    Inherits Tarjeta
    Public IdAsociacion As Integer
    Public Descripcion As String
    Public IdEstatus As Integer
End Class
