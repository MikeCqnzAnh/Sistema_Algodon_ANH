﻿Public Class Tierras
    Inherits Tarjeta
    Public IdTierra As Integer
    Public Lote As String
    Public Colonia As Integer
    Public Propietario As Integer
    Public TipoPersona As Integer
    Public RegistroAlterno As String
    Public SuperficieTotal As Double
    Public SuperficieCultivable As Double
    Public LatitudGrados As Double
    Public LatitudHoras As Double
    Public LatitudMinutos As Double
    Public LongitudGrados As Double
    Public LongitudHoras As Double
    Public LongitudMinutos As Double
    Public NumeroRpp As Integer
    Public FolioRpp As Integer
    Public LibroRpp As Integer
    Public Fecha As Date
    Public TituloAgua As String
    Public RegimenHidrico As Integer
    Public FechaTituloAgua As Date
    Public IdEstatus As Integer
End Class
