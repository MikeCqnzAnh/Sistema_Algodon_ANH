﻿Public Class Camiones
    Inherits Tarjeta
    Public IdCamion As Integer
    Public Descripcion As String
    Public Placas As String
    Public IdEstatus As Integer
End Class
