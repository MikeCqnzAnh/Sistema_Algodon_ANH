﻿Public Class Rendimientos
    Inherits Tarjeta
    Public IdRendimiento As Integer
    Public Pluma As Integer
    Public Semilla As Integer
    Public IdEstatus As Integer
End Class
