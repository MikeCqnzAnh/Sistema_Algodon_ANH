﻿Public Class ProfesionalesFitosanitarios
    Inherits Tarjeta
    Public IdProfesionales As Integer
    Public Descripcion As String
    Public IdEstatus As Integer
End Class
