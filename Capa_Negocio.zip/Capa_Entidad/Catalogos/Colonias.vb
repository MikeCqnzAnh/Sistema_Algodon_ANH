﻿Public Class Colonias
    Inherits Tarjeta
    Public IdColonia As Integer
    Public Descripcion As String
    Public NumeroPacas As Integer
    Public IdEstatus As Integer
End Class
