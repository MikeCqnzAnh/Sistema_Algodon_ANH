﻿Public Class CastigoLargoFibra
    Inherits Tarjeta
    Public IdCastigoLargoFibra As Integer
    Public Rango1 As Double
    Public Rango2 As Double
    Public ColorGrade As String
    Public Castigo As Double
    Public IdEstatus As Integer
End Class
