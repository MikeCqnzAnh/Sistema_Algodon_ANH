﻿Public Class CastigoResistenciaFibra
    Inherits Tarjeta
    Public IdCastigoResistenciaFibra As Integer
    Public Rango1 As Double
    Public Rango2 As Double
    Public Castigo As Double
    Public IdEstatus As Integer
End Class
