﻿Public Class Maquinaria
    Inherits Tarjeta
    Public IdMaquinaria As Integer
    Public Descripcion As String
    Public IdEstatus As Integer
End Class
