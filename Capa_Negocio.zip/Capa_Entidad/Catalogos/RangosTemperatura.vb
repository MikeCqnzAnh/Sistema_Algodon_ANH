﻿Public Class RangosTemperatura
    Inherits Tarjeta
    Public IdRango As Integer
    Public RangoInicial As Double
    Public RangoFinal As Double
    Public DentroLimite As Boolean
    Public IdEstatus As Integer
End Class
