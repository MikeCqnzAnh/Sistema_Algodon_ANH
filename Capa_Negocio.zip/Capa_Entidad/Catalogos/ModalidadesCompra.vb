﻿Public Class ModalidadesCompra
    Inherits Tarjeta
    Public IdModoEncabezado As Integer
    Public Descripcion As String
    Public IdEstatus As Integer

    Public TablaClasesClasificacion As DataTable
End Class
