﻿Public Class ConfiguracionParametros
    Inherits Tarjeta
    Public IdConfiguracion As Integer
    Public NombrePC As String
    Public DireccionIP As String
    Public NombrePuerto As String
    Public InicialModulo As Integer
    Public NoCaracterModulo As Integer
    Public InicialTransporte As Integer
    Public NoCaracterTransporte As Integer
    Public InicialBoletasBruto As Integer
    Public NoCaracterBoletasBruto As Integer
    Public InicialBoletasTara As Integer
    Public NoCaracterBoletasTara As Integer
    Public InicialBoletasNeto As Integer
    Public NoCaracterBoletasNeto As Integer
    Public InicialPacas As Integer
    Public NoCaracteresPacas As Integer
    Public NombreInstancia As String
End Class
