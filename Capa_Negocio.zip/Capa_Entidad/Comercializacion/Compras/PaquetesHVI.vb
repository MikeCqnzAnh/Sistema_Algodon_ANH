﻿Public Class PaquetesHVI
    Inherits Tarjeta
    Public IdPaqueteHVI As Integer
    Public NumeroPacas As Integer
    Public IdPlanta As Integer
    Public Fecha As Date
    Public IdPaquete As Integer
    Public Ruta As String
    Public IdEstatus As Integer
    'HVI Detalle
    Public TablaGlobal As DataTable
End Class
