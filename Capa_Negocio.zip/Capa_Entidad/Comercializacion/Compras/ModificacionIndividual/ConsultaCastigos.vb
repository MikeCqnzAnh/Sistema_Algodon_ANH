﻿Public Class ConsultaCastigos
    Inherits Tarjeta
    Public IdModalidadCompra As Integer
    Public IdModalidadVenta As Integer
End Class
