﻿Public Class CompraPacas
    Inherits Tarjeta
End Class
