﻿Public Class ClasificacionPacasExcel
    Inherits Tarjeta
    Public TablaBaleID As DataTable
End Class
