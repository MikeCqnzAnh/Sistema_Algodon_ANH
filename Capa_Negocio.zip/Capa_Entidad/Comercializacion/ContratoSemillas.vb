﻿Public Class ContratoSemillas
    Inherits Tarjeta
    Public IdContratoSemilla As Integer
    Public Folio As String
    Public Fecha As Date
    Public IdComprador As Integer
    Public Cantidad As Double
    Public IdEstatus As Integer
    Public PrecioTonelada As Double
    Public Testigo1 As String
    Public Testigo2 As String
End Class
