﻿Public Class VentaPacas
    Inherits Tarjeta
End Class
