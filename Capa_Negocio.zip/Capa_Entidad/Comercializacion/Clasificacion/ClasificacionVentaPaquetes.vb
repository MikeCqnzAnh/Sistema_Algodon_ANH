﻿Public Class ClasificacionVentaPaquetes
    Inherits Tarjeta
    Public IdClasificacion As Integer
    Public NumeroPaca As Integer
    Public TrashId As Integer
    Public GradoColor As String
    '------
    Public IdPaquete As Integer
    Public IdPlanta As Integer
    Public IdClase As Integer
    Public CantidadPacas As Integer
    Public Descripcion As String
    Public chkrevisado As Boolean
    Public FlagRevisado As Boolean
    Public IdEstatus As Integer
    Public Seleccion As Boolean
End Class
