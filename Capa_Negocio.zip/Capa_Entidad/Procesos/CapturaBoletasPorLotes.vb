﻿Public Class CapturaBoletasPorLotes
    Inherits Tarjeta
    Public NoTransporte As Integer
    Public Idboleta As Integer
    Public Bruto As Double
    Public Tara As Double
    Public Neto As Double
    Public FlagRevisada As Boolean
    Public FlagCancelada As Boolean
    Public TipoFlete As String
    Public IdOrdenTrabajo As Integer
End Class
