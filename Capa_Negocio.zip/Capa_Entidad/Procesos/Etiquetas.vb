﻿Public Class Etiquetas
    Inherits Tarjeta
    Public IdPlanta As Integer
    Public Etiqueta As Integer
    Public IdProduccion As Integer
End Class
