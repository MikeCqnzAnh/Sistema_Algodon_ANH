﻿Public Class OrdenTrabajo
    Inherits Tarjeta
    Public IdOrdenTrabajo As Integer
    Public IdPlanta As Integer
    Public IdProductor As Integer
    Public RangoInicio As Integer
    Public RangoFin As Integer
    Public IdLote As Integer
    Public IdVariedadAlgodon As Integer
    Public IdColonia As Integer
    Public Predio As String
    Public NoModulos As Integer
    Public IdEstatus As Integer
End Class

