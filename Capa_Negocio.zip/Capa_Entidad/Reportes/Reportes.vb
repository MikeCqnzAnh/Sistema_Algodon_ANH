﻿Public Class Reportes
    Inherits Tarjeta
    '---ReporteClientes
    Public IdAsociacion As Integer
    '------------------------------
End Class
