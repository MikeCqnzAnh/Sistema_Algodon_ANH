create proc Sp_obtieneNombreInstancia
as
select @@SERVERNAME as NombreInstancia