create table TierraDetalle
(
IdTierraDetalle int primary key identity(1,1),
IdTierraEncabezado int,
SuperficieRestante decimal(6,2)
)
