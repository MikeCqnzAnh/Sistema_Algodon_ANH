CREATE TABLE [dbo].[ClasesClasificacion]
(
	[IdClasificacion] int  primary key IDENTITY(1,1),
	[ClaveCorta] varchar(6) NULL,
	[Descripcion] varchar(30) NULL
)
