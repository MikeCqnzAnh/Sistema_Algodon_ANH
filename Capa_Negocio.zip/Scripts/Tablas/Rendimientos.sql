create table Rendimientos
(
IdRendimiento int primary key identity(1,1),
Pluma int,
Semilla int,
IdEstatus int,
IdUsuarioCreacion int,
FechaCreacion date
)