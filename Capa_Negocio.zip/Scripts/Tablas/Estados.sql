create table Estados (
IdEstado int not null primary key identity(1,1),
Descripcion varchar(30),
IdEstatus int not null
)