create table TipoPersona (
IdTipoPersona int not null primary key identity(1,1),
Descripcion varchar(15),
IdEstatus int
)