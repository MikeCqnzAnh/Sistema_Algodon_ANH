create table VariedadesAlgodon
(
IdVariedadAlgodon int primary key identity(1,1),
Descripcion varchar(20),
IdEstatus int,
IdUsuarioCreacion int,
FechaCreacion date
)