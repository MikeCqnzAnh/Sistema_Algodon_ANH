create table ResistenciaFibra
(
IdResistenciaFibra int primary key identity(1,1),
Rango1 float,
Rango2 Float,
castigo float,
IdEstatus int,
IdUsuarioCreacion int,
FechaCreacion datetime
) 
