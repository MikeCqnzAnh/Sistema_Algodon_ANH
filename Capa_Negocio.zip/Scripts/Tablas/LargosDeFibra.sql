CREATE TABLE LargosDeFibra
(
IdLargoFibra int primary key Identity(1,1),
Rango1 float,
Rango2 float,
ColorGrade Varchar(5),
Castigo float,
IdUsuarioCreacion int,
FechaCreacion Datetime,
IdEstatus int
)
