create table FolioEtiqueta(
IdEtiqueta int not null identity(1,1),
Etiqueta int not null,
IdPlantaOrigen int not null,
Observacion varchar(100)
)


