create table Municipios (
IdMunicipio int not null primary key identity(1,1),
Descripcion varchar(30),
IdEstado int,
IdEstatus int
)