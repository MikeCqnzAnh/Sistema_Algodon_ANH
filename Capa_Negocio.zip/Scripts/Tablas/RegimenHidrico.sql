create table RegimenHidrico
(
IdRegimen int primary key identity(1,1),
Descripcion varchar(30)
)