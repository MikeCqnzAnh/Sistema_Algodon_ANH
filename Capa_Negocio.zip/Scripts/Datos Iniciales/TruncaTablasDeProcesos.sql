truncate table [dbo].[LiquidacionesPorRomaneaje]
truncate table [dbo].[CalculoClasificacion]
truncate table [dbo].[ContratoCompra]
truncate table [dbo].[ContratoCompraDetalle]
truncate table [dbo].[ContratoSemilla]
truncate table [dbo].[ContratoVenta]
truncate table [dbo].[FolioEtiqueta]
truncate table [dbo].[HVIDetalle]
truncate table [dbo].[HVIEncabezado]
truncate table [dbo].[OrdenTrabajo]
truncate table [dbo].[OrdenTrabajoDetalle]
truncate table [dbo].[PaqueteEncabezado]
truncate table [dbo].[Produccion]
truncate table [dbo].[ProduccionDetalle]
truncate table 
truncate table

select * from  [dbo].[TierraDetalle]

select * from [dbo].[Tierras]