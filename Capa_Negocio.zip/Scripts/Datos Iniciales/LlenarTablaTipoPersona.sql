insert into TipoPersona values ('Fisica',1)
insert into TipoPersona values ('Moral',1)
