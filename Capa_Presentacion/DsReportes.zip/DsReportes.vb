﻿Partial Class DsReportes

End Class
