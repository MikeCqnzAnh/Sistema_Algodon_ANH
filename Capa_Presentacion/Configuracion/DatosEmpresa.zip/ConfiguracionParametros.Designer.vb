﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ConfiguracionParametros
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ConfiguracionParametros))
        Me.PanelParametrosBascula = New System.Windows.Forms.Panel()
        Me.GbPruebaSerial = New System.Windows.Forms.GroupBox()
        Me.TbCadenaPuertoSerial = New System.Windows.Forms.TextBox()
        Me.GbResultado = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtProbarConfiguracion = New System.Windows.Forms.Button()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TbModulo = New System.Windows.Forms.TextBox()
        Me.TbNeto = New System.Windows.Forms.TextBox()
        Me.TbTara = New System.Windows.Forms.TextBox()
        Me.TbBruto = New System.Windows.Forms.TextBox()
        Me.TbIdCamion = New System.Windows.Forms.TextBox()
        Me.LbStatusPuerto = New System.Windows.Forms.Label()
        Me.BtLimpiar = New System.Windows.Forms.Button()
        Me.GbPesoPacas = New System.Windows.Forms.GroupBox()
        Me.BtTestPacas = New System.Windows.Forms.Button()
        Me.TbPacasIndicadorNeto = New System.Windows.Forms.TextBox()
        Me.TbPacasIndicadorTara = New System.Windows.Forms.TextBox()
        Me.TbPacasIndicadorBruto = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NuPacasCaracterNeto = New System.Windows.Forms.NumericUpDown()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.NuPacasPosicionNeto = New System.Windows.Forms.NumericUpDown()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.NuPacasCaracterTara = New System.Windows.Forms.NumericUpDown()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.NuPacasPosicionTara = New System.Windows.Forms.NumericUpDown()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.NuPacasPosicionBruto = New System.Windows.Forms.NumericUpDown()
        Me.NuPesoMinimoPaca = New System.Windows.Forms.NumericUpDown()
        Me.NuPacasCaracterBruto = New System.Windows.Forms.NumericUpDown()
        Me.GbIdProduccion = New System.Windows.Forms.GroupBox()
        Me.BtTestModulos = New System.Windows.Forms.Button()
        Me.TbIndicadorID = New System.Windows.Forms.TextBox()
        Me.TbIndicadorSalida = New System.Windows.Forms.TextBox()
        Me.TbIndicadorNeto = New System.Windows.Forms.TextBox()
        Me.TbIndicadorTara = New System.Windows.Forms.TextBox()
        Me.TbIndicadorBruto = New System.Windows.Forms.TextBox()
        Me.TbIndicadorModulo = New System.Windows.Forms.TextBox()
        Me.TbIndicadorEntrada = New System.Windows.Forms.TextBox()
        Me.NuCaracterNeto = New System.Windows.Forms.NumericUpDown()
        Me.NuCaracterSalida = New System.Windows.Forms.NumericUpDown()
        Me.NuPosicionNeto = New System.Windows.Forms.NumericUpDown()
        Me.NuPosicionSalida = New System.Windows.Forms.NumericUpDown()
        Me.NuCaracterModulo = New System.Windows.Forms.NumericUpDown()
        Me.NuCaracterTara = New System.Windows.Forms.NumericUpDown()
        Me.NuCaracterEntrada = New System.Windows.Forms.NumericUpDown()
        Me.NuPosicionModulo = New System.Windows.Forms.NumericUpDown()
        Me.NuPosicionTara = New System.Windows.Forms.NumericUpDown()
        Me.NuPosicionEntrada = New System.Windows.Forms.NumericUpDown()
        Me.NuCaracterBruto = New System.Windows.Forms.NumericUpDown()
        Me.NuCaracterId = New System.Windows.Forms.NumericUpDown()
        Me.NuPosicionBruto = New System.Windows.Forms.NumericUpDown()
        Me.NuPosicionID = New System.Windows.Forms.NumericUpDown()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GbPuerto = New System.Windows.Forms.GroupBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.CbPlantaElabora = New System.Windows.Forms.ComboBox()
        Me.CbStopBits = New System.Windows.Forms.ComboBox()
        Me.CbParity = New System.Windows.Forms.ComboBox()
        Me.CbDataBits = New System.Windows.Forms.ComboBox()
        Me.CbBaudRate = New System.Windows.Forms.ComboBox()
        Me.CbPuertosSeriales = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TsNombrePc = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TsSeparador = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TsIpComputadora = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TsIdConfiguracion = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TsIdConf = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.GuardarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModificarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.CkTextoIzq = New System.Windows.Forms.CheckBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.CbDtrEnable = New System.Windows.Forms.ComboBox()
        Me.CbHanshake = New System.Windows.Forms.ComboBox()
        Me.TbReadBuffersize = New System.Windows.Forms.TextBox()
        Me.TbWriteBuffersize = New System.Windows.Forms.TextBox()
        Me.TbReceivedBytesThreshold = New System.Windows.Forms.TextBox()
        Me.SpCapturaAuto = New System.IO.Ports.SerialPort(Me.components)
        Me.PanelParametrosBascula.SuspendLayout()
        Me.GbPruebaSerial.SuspendLayout()
        Me.GbResultado.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GbPesoPacas.SuspendLayout()
        CType(Me.NuPacasCaracterNeto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPacasPosicionNeto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPacasCaracterTara, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPacasPosicionTara, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPacasPosicionBruto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPesoMinimoPaca, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPacasCaracterBruto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GbIdProduccion.SuspendLayout()
        CType(Me.NuCaracterNeto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuCaracterSalida, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPosicionNeto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPosicionSalida, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuCaracterModulo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuCaracterTara, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuCaracterEntrada, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPosicionModulo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPosicionTara, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPosicionEntrada, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuCaracterBruto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuCaracterId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPosicionBruto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NuPosicionID, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GbPuerto.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelParametrosBascula
        '
        Me.PanelParametrosBascula.Controls.Add(Me.GbPruebaSerial)
        Me.PanelParametrosBascula.Controls.Add(Me.GbPesoPacas)
        Me.PanelParametrosBascula.Controls.Add(Me.GbIdProduccion)
        Me.PanelParametrosBascula.Controls.Add(Me.GbPuerto)
        Me.PanelParametrosBascula.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelParametrosBascula.Location = New System.Drawing.Point(0, 24)
        Me.PanelParametrosBascula.Name = "PanelParametrosBascula"
        Me.PanelParametrosBascula.Size = New System.Drawing.Size(1141, 730)
        Me.PanelParametrosBascula.TabIndex = 2
        '
        'GbPruebaSerial
        '
        Me.GbPruebaSerial.Controls.Add(Me.TbCadenaPuertoSerial)
        Me.GbPruebaSerial.Controls.Add(Me.GbResultado)
        Me.GbPruebaSerial.Controls.Add(Me.LbStatusPuerto)
        Me.GbPruebaSerial.Controls.Add(Me.BtLimpiar)
        Me.GbPruebaSerial.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GbPruebaSerial.Location = New System.Drawing.Point(0, 389)
        Me.GbPruebaSerial.Name = "GbPruebaSerial"
        Me.GbPruebaSerial.Size = New System.Drawing.Size(1141, 341)
        Me.GbPruebaSerial.TabIndex = 4
        Me.GbPruebaSerial.TabStop = False
        Me.GbPruebaSerial.Text = "Prueba de Puerto Serial"
        '
        'TbCadenaPuertoSerial
        '
        Me.TbCadenaPuertoSerial.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TbCadenaPuertoSerial.Location = New System.Drawing.Point(3, 47)
        Me.TbCadenaPuertoSerial.Multiline = True
        Me.TbCadenaPuertoSerial.Name = "TbCadenaPuertoSerial"
        Me.TbCadenaPuertoSerial.ReadOnly = True
        Me.TbCadenaPuertoSerial.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TbCadenaPuertoSerial.Size = New System.Drawing.Size(607, 291)
        Me.TbCadenaPuertoSerial.TabIndex = 10
        '
        'GbResultado
        '
        Me.GbResultado.Controls.Add(Me.Panel1)
        Me.GbResultado.Controls.Add(Me.Label42)
        Me.GbResultado.Controls.Add(Me.Label13)
        Me.GbResultado.Controls.Add(Me.Label12)
        Me.GbResultado.Controls.Add(Me.Label11)
        Me.GbResultado.Controls.Add(Me.Label10)
        Me.GbResultado.Controls.Add(Me.TbModulo)
        Me.GbResultado.Controls.Add(Me.TbNeto)
        Me.GbResultado.Controls.Add(Me.TbTara)
        Me.GbResultado.Controls.Add(Me.TbBruto)
        Me.GbResultado.Controls.Add(Me.TbIdCamion)
        Me.GbResultado.Dock = System.Windows.Forms.DockStyle.Right
        Me.GbResultado.Location = New System.Drawing.Point(610, 47)
        Me.GbResultado.Name = "GbResultado"
        Me.GbResultado.Size = New System.Drawing.Size(441, 291)
        Me.GbResultado.TabIndex = 13
        Me.GbResultado.TabStop = False
        Me.GbResultado.Text = "Resultado"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtProbarConfiguracion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(3, 244)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(435, 44)
        Me.Panel1.TabIndex = 2
        '
        'BtProbarConfiguracion
        '
        Me.BtProbarConfiguracion.Dock = System.Windows.Forms.DockStyle.Left
        Me.BtProbarConfiguracion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtProbarConfiguracion.Location = New System.Drawing.Point(0, 0)
        Me.BtProbarConfiguracion.Name = "BtProbarConfiguracion"
        Me.BtProbarConfiguracion.Size = New System.Drawing.Size(140, 44)
        Me.BtProbarConfiguracion.TabIndex = 1
        Me.BtProbarConfiguracion.Text = "Probar Configuracion"
        Me.BtProbarConfiguracion.UseVisualStyleBackColor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(6, 116)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(36, 13)
        Me.Label42.TabIndex = 0
        Me.Label42.Text = "Neto :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(6, 90)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(35, 13)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Tara :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(6, 64)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(38, 13)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Bruto :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(210, 35)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Modulo :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(6, 35)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(24, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "ID :"
        '
        'TbModulo
        '
        Me.TbModulo.Location = New System.Drawing.Point(286, 32)
        Me.TbModulo.Name = "TbModulo"
        Me.TbModulo.ReadOnly = True
        Me.TbModulo.Size = New System.Drawing.Size(100, 20)
        Me.TbModulo.TabIndex = 0
        '
        'TbNeto
        '
        Me.TbNeto.Location = New System.Drawing.Point(82, 113)
        Me.TbNeto.Name = "TbNeto"
        Me.TbNeto.ReadOnly = True
        Me.TbNeto.Size = New System.Drawing.Size(100, 20)
        Me.TbNeto.TabIndex = 0
        '
        'TbTara
        '
        Me.TbTara.Location = New System.Drawing.Point(82, 87)
        Me.TbTara.Name = "TbTara"
        Me.TbTara.ReadOnly = True
        Me.TbTara.Size = New System.Drawing.Size(100, 20)
        Me.TbTara.TabIndex = 0
        '
        'TbBruto
        '
        Me.TbBruto.Location = New System.Drawing.Point(82, 61)
        Me.TbBruto.Name = "TbBruto"
        Me.TbBruto.ReadOnly = True
        Me.TbBruto.Size = New System.Drawing.Size(100, 20)
        Me.TbBruto.TabIndex = 0
        '
        'TbIdCamion
        '
        Me.TbIdCamion.Location = New System.Drawing.Point(82, 32)
        Me.TbIdCamion.Name = "TbIdCamion"
        Me.TbIdCamion.ReadOnly = True
        Me.TbIdCamion.Size = New System.Drawing.Size(100, 20)
        Me.TbIdCamion.TabIndex = 0
        '
        'LbStatusPuerto
        '
        Me.LbStatusPuerto.AutoSize = True
        Me.LbStatusPuerto.Dock = System.Windows.Forms.DockStyle.Top
        Me.LbStatusPuerto.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LbStatusPuerto.Location = New System.Drawing.Point(3, 16)
        Me.LbStatusPuerto.Name = "LbStatusPuerto"
        Me.LbStatusPuerto.Size = New System.Drawing.Size(561, 31)
        Me.LbStatusPuerto.TabIndex = 12
        Me.LbStatusPuerto.Text = "CAPTURA AUTOMATICA DESACTIVADA"
        '
        'BtLimpiar
        '
        Me.BtLimpiar.Dock = System.Windows.Forms.DockStyle.Right
        Me.BtLimpiar.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtLimpiar.Location = New System.Drawing.Point(1051, 16)
        Me.BtLimpiar.Name = "BtLimpiar"
        Me.BtLimpiar.Size = New System.Drawing.Size(87, 322)
        Me.BtLimpiar.TabIndex = 11
        Me.BtLimpiar.Text = "Limpiar"
        Me.BtLimpiar.UseVisualStyleBackColor = True
        '
        'GbPesoPacas
        '
        Me.GbPesoPacas.Controls.Add(Me.CkTextoIzq)
        Me.GbPesoPacas.Controls.Add(Me.BtTestPacas)
        Me.GbPesoPacas.Controls.Add(Me.TbPacasIndicadorNeto)
        Me.GbPesoPacas.Controls.Add(Me.TbPacasIndicadorTara)
        Me.GbPesoPacas.Controls.Add(Me.TbPacasIndicadorBruto)
        Me.GbPesoPacas.Controls.Add(Me.Label38)
        Me.GbPesoPacas.Controls.Add(Me.Label48)
        Me.GbPesoPacas.Controls.Add(Me.Label1)
        Me.GbPesoPacas.Controls.Add(Me.NuPacasCaracterNeto)
        Me.GbPesoPacas.Controls.Add(Me.Label9)
        Me.GbPesoPacas.Controls.Add(Me.Label5)
        Me.GbPesoPacas.Controls.Add(Me.Label35)
        Me.GbPesoPacas.Controls.Add(Me.NuPacasPosicionNeto)
        Me.GbPesoPacas.Controls.Add(Me.Label36)
        Me.GbPesoPacas.Controls.Add(Me.Label37)
        Me.GbPesoPacas.Controls.Add(Me.NuPacasCaracterTara)
        Me.GbPesoPacas.Controls.Add(Me.Label39)
        Me.GbPesoPacas.Controls.Add(Me.Label40)
        Me.GbPesoPacas.Controls.Add(Me.NuPacasPosicionTara)
        Me.GbPesoPacas.Controls.Add(Me.Label41)
        Me.GbPesoPacas.Controls.Add(Me.NuPacasPosicionBruto)
        Me.GbPesoPacas.Controls.Add(Me.NuPesoMinimoPaca)
        Me.GbPesoPacas.Controls.Add(Me.NuPacasCaracterBruto)
        Me.GbPesoPacas.Dock = System.Windows.Forms.DockStyle.Top
        Me.GbPesoPacas.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GbPesoPacas.Location = New System.Drawing.Point(0, 249)
        Me.GbPesoPacas.Name = "GbPesoPacas"
        Me.GbPesoPacas.Size = New System.Drawing.Size(1141, 140)
        Me.GbPesoPacas.TabIndex = 3
        Me.GbPesoPacas.TabStop = False
        Me.GbPesoPacas.Text = "Peso De Pacas"
        '
        'BtTestPacas
        '
        Me.BtTestPacas.Dock = System.Windows.Forms.DockStyle.Right
        Me.BtTestPacas.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtTestPacas.Location = New System.Drawing.Point(1051, 16)
        Me.BtTestPacas.Name = "BtTestPacas"
        Me.BtTestPacas.Size = New System.Drawing.Size(87, 121)
        Me.BtTestPacas.TabIndex = 21
        Me.BtTestPacas.Text = "Envia Cadena Pacas"
        Me.BtTestPacas.UseVisualStyleBackColor = True
        '
        'TbPacasIndicadorNeto
        '
        Me.TbPacasIndicadorNeto.Location = New System.Drawing.Point(124, 99)
        Me.TbPacasIndicadorNeto.Name = "TbPacasIndicadorNeto"
        Me.TbPacasIndicadorNeto.Size = New System.Drawing.Size(105, 20)
        Me.TbPacasIndicadorNeto.TabIndex = 7
        '
        'TbPacasIndicadorTara
        '
        Me.TbPacasIndicadorTara.Location = New System.Drawing.Point(124, 73)
        Me.TbPacasIndicadorTara.Name = "TbPacasIndicadorTara"
        Me.TbPacasIndicadorTara.Size = New System.Drawing.Size(105, 20)
        Me.TbPacasIndicadorTara.TabIndex = 4
        '
        'TbPacasIndicadorBruto
        '
        Me.TbPacasIndicadorBruto.Location = New System.Drawing.Point(124, 47)
        Me.TbPacasIndicadorBruto.Name = "TbPacasIndicadorBruto"
        Me.TbPacasIndicadorBruto.Size = New System.Drawing.Size(105, 20)
        Me.TbPacasIndicadorBruto.TabIndex = 1
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(9, 102)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(80, 13)
        Me.Label38.TabIndex = 3
        Me.Label38.Text = "Indicador Neto:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(362, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "No de Caracteres:"
        '
        'NuPacasCaracterNeto
        '
        Me.NuPacasCaracterNeto.Location = New System.Drawing.Point(461, 100)
        Me.NuPacasCaracterNeto.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPacasCaracterNeto.Name = "NuPacasCaracterNeto"
        Me.NuPacasCaracterNeto.Size = New System.Drawing.Size(62, 20)
        Me.NuPacasCaracterNeto.TabIndex = 9
        Me.NuPacasCaracterNeto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(9, 23)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(145, 13)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Peso minimo (Kg) para paca :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(362, 76)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 13)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "No de Caracteres:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(9, 50)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(109, 13)
        Me.Label35.TabIndex = 3
        Me.Label35.Text = "Indicador Peso Bruto:"
        '
        'NuPacasPosicionNeto
        '
        Me.NuPacasPosicionNeto.Location = New System.Drawing.Point(294, 100)
        Me.NuPacasPosicionNeto.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPacasPosicionNeto.Name = "NuPacasPosicionNeto"
        Me.NuPacasPosicionNeto.Size = New System.Drawing.Size(62, 20)
        Me.NuPacasPosicionNeto.TabIndex = 8
        Me.NuPacasPosicionNeto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(362, 102)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(93, 13)
        Me.Label36.TabIndex = 3
        Me.Label36.Text = "No de Caracteres:"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(9, 76)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(79, 13)
        Me.Label37.TabIndex = 3
        Me.Label37.Text = "Indicador Tara:"
        '
        'NuPacasCaracterTara
        '
        Me.NuPacasCaracterTara.Location = New System.Drawing.Point(461, 74)
        Me.NuPacasCaracterTara.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPacasCaracterTara.Name = "NuPacasCaracterTara"
        Me.NuPacasCaracterTara.Size = New System.Drawing.Size(62, 20)
        Me.NuPacasCaracterTara.TabIndex = 6
        Me.NuPacasCaracterTara.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(235, 50)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(53, 13)
        Me.Label39.TabIndex = 3
        Me.Label39.Text = "Posicion :"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(235, 76)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(53, 13)
        Me.Label40.TabIndex = 3
        Me.Label40.Text = "Posicion :"
        '
        'NuPacasPosicionTara
        '
        Me.NuPacasPosicionTara.Location = New System.Drawing.Point(294, 74)
        Me.NuPacasPosicionTara.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPacasPosicionTara.Name = "NuPacasPosicionTara"
        Me.NuPacasPosicionTara.Size = New System.Drawing.Size(62, 20)
        Me.NuPacasPosicionTara.TabIndex = 5
        Me.NuPacasPosicionTara.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(235, 102)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(53, 13)
        Me.Label41.TabIndex = 3
        Me.Label41.Text = "Posicion :"
        '
        'NuPacasPosicionBruto
        '
        Me.NuPacasPosicionBruto.Location = New System.Drawing.Point(294, 47)
        Me.NuPacasPosicionBruto.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPacasPosicionBruto.Name = "NuPacasPosicionBruto"
        Me.NuPacasPosicionBruto.Size = New System.Drawing.Size(62, 20)
        Me.NuPacasPosicionBruto.TabIndex = 2
        Me.NuPacasPosicionBruto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuPesoMinimoPaca
        '
        Me.NuPesoMinimoPaca.Location = New System.Drawing.Point(160, 21)
        Me.NuPesoMinimoPaca.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPesoMinimoPaca.Name = "NuPesoMinimoPaca"
        Me.NuPesoMinimoPaca.Size = New System.Drawing.Size(69, 20)
        Me.NuPesoMinimoPaca.TabIndex = 0
        Me.NuPesoMinimoPaca.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuPacasCaracterBruto
        '
        Me.NuPacasCaracterBruto.Location = New System.Drawing.Point(461, 47)
        Me.NuPacasCaracterBruto.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPacasCaracterBruto.Name = "NuPacasCaracterBruto"
        Me.NuPacasCaracterBruto.Size = New System.Drawing.Size(62, 20)
        Me.NuPacasCaracterBruto.TabIndex = 3
        Me.NuPacasCaracterBruto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GbIdProduccion
        '
        Me.GbIdProduccion.Controls.Add(Me.BtTestModulos)
        Me.GbIdProduccion.Controls.Add(Me.TbIndicadorID)
        Me.GbIdProduccion.Controls.Add(Me.TbIndicadorSalida)
        Me.GbIdProduccion.Controls.Add(Me.TbIndicadorNeto)
        Me.GbIdProduccion.Controls.Add(Me.TbIndicadorTara)
        Me.GbIdProduccion.Controls.Add(Me.TbIndicadorBruto)
        Me.GbIdProduccion.Controls.Add(Me.TbIndicadorModulo)
        Me.GbIdProduccion.Controls.Add(Me.TbIndicadorEntrada)
        Me.GbIdProduccion.Controls.Add(Me.NuCaracterNeto)
        Me.GbIdProduccion.Controls.Add(Me.NuCaracterSalida)
        Me.GbIdProduccion.Controls.Add(Me.NuPosicionNeto)
        Me.GbIdProduccion.Controls.Add(Me.NuPosicionSalida)
        Me.GbIdProduccion.Controls.Add(Me.NuCaracterModulo)
        Me.GbIdProduccion.Controls.Add(Me.NuCaracterTara)
        Me.GbIdProduccion.Controls.Add(Me.NuCaracterEntrada)
        Me.GbIdProduccion.Controls.Add(Me.NuPosicionModulo)
        Me.GbIdProduccion.Controls.Add(Me.NuPosicionTara)
        Me.GbIdProduccion.Controls.Add(Me.NuPosicionEntrada)
        Me.GbIdProduccion.Controls.Add(Me.NuCaracterBruto)
        Me.GbIdProduccion.Controls.Add(Me.NuCaracterId)
        Me.GbIdProduccion.Controls.Add(Me.NuPosicionBruto)
        Me.GbIdProduccion.Controls.Add(Me.NuPosicionID)
        Me.GbIdProduccion.Controls.Add(Me.Label21)
        Me.GbIdProduccion.Controls.Add(Me.Label34)
        Me.GbIdProduccion.Controls.Add(Me.Label33)
        Me.GbIdProduccion.Controls.Add(Me.Label26)
        Me.GbIdProduccion.Controls.Add(Me.Label8)
        Me.GbIdProduccion.Controls.Add(Me.Label32)
        Me.GbIdProduccion.Controls.Add(Me.Label25)
        Me.GbIdProduccion.Controls.Add(Me.Label3)
        Me.GbIdProduccion.Controls.Add(Me.Label20)
        Me.GbIdProduccion.Controls.Add(Me.Label24)
        Me.GbIdProduccion.Controls.Add(Me.Label23)
        Me.GbIdProduccion.Controls.Add(Me.Label31)
        Me.GbIdProduccion.Controls.Add(Me.Label22)
        Me.GbIdProduccion.Controls.Add(Me.Label30)
        Me.GbIdProduccion.Controls.Add(Me.Label28)
        Me.GbIdProduccion.Controls.Add(Me.Label7)
        Me.GbIdProduccion.Controls.Add(Me.Label29)
        Me.GbIdProduccion.Controls.Add(Me.Label27)
        Me.GbIdProduccion.Controls.Add(Me.Label6)
        Me.GbIdProduccion.Controls.Add(Me.Label4)
        Me.GbIdProduccion.Controls.Add(Me.Label19)
        Me.GbIdProduccion.Dock = System.Windows.Forms.DockStyle.Top
        Me.GbIdProduccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GbIdProduccion.Location = New System.Drawing.Point(0, 104)
        Me.GbIdProduccion.Name = "GbIdProduccion"
        Me.GbIdProduccion.Size = New System.Drawing.Size(1141, 145)
        Me.GbIdProduccion.TabIndex = 2
        Me.GbIdProduccion.TabStop = False
        Me.GbIdProduccion.Text = "Id Modulo y Camion Produccion"
        '
        'BtTestModulos
        '
        Me.BtTestModulos.Dock = System.Windows.Forms.DockStyle.Right
        Me.BtTestModulos.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtTestModulos.Location = New System.Drawing.Point(1051, 16)
        Me.BtTestModulos.Name = "BtTestModulos"
        Me.BtTestModulos.Size = New System.Drawing.Size(87, 126)
        Me.BtTestModulos.TabIndex = 21
        Me.BtTestModulos.Text = "Envia Cadena Modulos"
        Me.BtTestModulos.UseVisualStyleBackColor = True
        '
        'TbIndicadorID
        '
        Me.TbIndicadorID.Location = New System.Drawing.Point(109, 23)
        Me.TbIndicadorID.Name = "TbIndicadorID"
        Me.TbIndicadorID.Size = New System.Drawing.Size(105, 20)
        Me.TbIndicadorID.TabIndex = 0
        '
        'TbIndicadorSalida
        '
        Me.TbIndicadorSalida.Location = New System.Drawing.Point(109, 101)
        Me.TbIndicadorSalida.Name = "TbIndicadorSalida"
        Me.TbIndicadorSalida.Size = New System.Drawing.Size(105, 20)
        Me.TbIndicadorSalida.TabIndex = 9
        '
        'TbIndicadorNeto
        '
        Me.TbIndicadorNeto.Location = New System.Drawing.Point(633, 75)
        Me.TbIndicadorNeto.Name = "TbIndicadorNeto"
        Me.TbIndicadorNeto.Size = New System.Drawing.Size(105, 20)
        Me.TbIndicadorNeto.TabIndex = 18
        '
        'TbIndicadorTara
        '
        Me.TbIndicadorTara.Location = New System.Drawing.Point(633, 49)
        Me.TbIndicadorTara.Name = "TbIndicadorTara"
        Me.TbIndicadorTara.Size = New System.Drawing.Size(105, 20)
        Me.TbIndicadorTara.TabIndex = 15
        '
        'TbIndicadorBruto
        '
        Me.TbIndicadorBruto.Location = New System.Drawing.Point(633, 23)
        Me.TbIndicadorBruto.Name = "TbIndicadorBruto"
        Me.TbIndicadorBruto.Size = New System.Drawing.Size(105, 20)
        Me.TbIndicadorBruto.TabIndex = 12
        '
        'TbIndicadorModulo
        '
        Me.TbIndicadorModulo.Location = New System.Drawing.Point(109, 49)
        Me.TbIndicadorModulo.Name = "TbIndicadorModulo"
        Me.TbIndicadorModulo.Size = New System.Drawing.Size(105, 20)
        Me.TbIndicadorModulo.TabIndex = 3
        '
        'TbIndicadorEntrada
        '
        Me.TbIndicadorEntrada.Location = New System.Drawing.Point(109, 75)
        Me.TbIndicadorEntrada.Name = "TbIndicadorEntrada"
        Me.TbIndicadorEntrada.Size = New System.Drawing.Size(105, 20)
        Me.TbIndicadorEntrada.TabIndex = 6
        '
        'NuCaracterNeto
        '
        Me.NuCaracterNeto.Location = New System.Drawing.Point(970, 76)
        Me.NuCaracterNeto.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuCaracterNeto.Name = "NuCaracterNeto"
        Me.NuCaracterNeto.Size = New System.Drawing.Size(62, 20)
        Me.NuCaracterNeto.TabIndex = 20
        Me.NuCaracterNeto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuCaracterSalida
        '
        Me.NuCaracterSalida.Location = New System.Drawing.Point(445, 102)
        Me.NuCaracterSalida.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuCaracterSalida.Name = "NuCaracterSalida"
        Me.NuCaracterSalida.Size = New System.Drawing.Size(62, 20)
        Me.NuCaracterSalida.TabIndex = 11
        Me.NuCaracterSalida.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuPosicionNeto
        '
        Me.NuPosicionNeto.Location = New System.Drawing.Point(803, 76)
        Me.NuPosicionNeto.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPosicionNeto.Name = "NuPosicionNeto"
        Me.NuPosicionNeto.Size = New System.Drawing.Size(62, 20)
        Me.NuPosicionNeto.TabIndex = 19
        Me.NuPosicionNeto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuPosicionSalida
        '
        Me.NuPosicionSalida.Location = New System.Drawing.Point(278, 102)
        Me.NuPosicionSalida.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPosicionSalida.Name = "NuPosicionSalida"
        Me.NuPosicionSalida.Size = New System.Drawing.Size(62, 20)
        Me.NuPosicionSalida.TabIndex = 10
        Me.NuPosicionSalida.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuCaracterModulo
        '
        Me.NuCaracterModulo.Location = New System.Drawing.Point(445, 50)
        Me.NuCaracterModulo.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuCaracterModulo.Name = "NuCaracterModulo"
        Me.NuCaracterModulo.Size = New System.Drawing.Size(62, 20)
        Me.NuCaracterModulo.TabIndex = 5
        Me.NuCaracterModulo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuCaracterTara
        '
        Me.NuCaracterTara.Location = New System.Drawing.Point(970, 50)
        Me.NuCaracterTara.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuCaracterTara.Name = "NuCaracterTara"
        Me.NuCaracterTara.Size = New System.Drawing.Size(62, 20)
        Me.NuCaracterTara.TabIndex = 17
        Me.NuCaracterTara.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuCaracterEntrada
        '
        Me.NuCaracterEntrada.Location = New System.Drawing.Point(445, 76)
        Me.NuCaracterEntrada.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuCaracterEntrada.Name = "NuCaracterEntrada"
        Me.NuCaracterEntrada.Size = New System.Drawing.Size(62, 20)
        Me.NuCaracterEntrada.TabIndex = 8
        Me.NuCaracterEntrada.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuPosicionModulo
        '
        Me.NuPosicionModulo.Location = New System.Drawing.Point(278, 50)
        Me.NuPosicionModulo.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPosicionModulo.Name = "NuPosicionModulo"
        Me.NuPosicionModulo.Size = New System.Drawing.Size(62, 20)
        Me.NuPosicionModulo.TabIndex = 4
        Me.NuPosicionModulo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuPosicionTara
        '
        Me.NuPosicionTara.Location = New System.Drawing.Point(803, 50)
        Me.NuPosicionTara.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPosicionTara.Name = "NuPosicionTara"
        Me.NuPosicionTara.Size = New System.Drawing.Size(62, 20)
        Me.NuPosicionTara.TabIndex = 16
        Me.NuPosicionTara.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuPosicionEntrada
        '
        Me.NuPosicionEntrada.Location = New System.Drawing.Point(278, 76)
        Me.NuPosicionEntrada.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPosicionEntrada.Name = "NuPosicionEntrada"
        Me.NuPosicionEntrada.Size = New System.Drawing.Size(62, 20)
        Me.NuPosicionEntrada.TabIndex = 7
        Me.NuPosicionEntrada.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuCaracterBruto
        '
        Me.NuCaracterBruto.Location = New System.Drawing.Point(970, 23)
        Me.NuCaracterBruto.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuCaracterBruto.Name = "NuCaracterBruto"
        Me.NuCaracterBruto.Size = New System.Drawing.Size(62, 20)
        Me.NuCaracterBruto.TabIndex = 14
        Me.NuCaracterBruto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuCaracterId
        '
        Me.NuCaracterId.Location = New System.Drawing.Point(445, 24)
        Me.NuCaracterId.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuCaracterId.Name = "NuCaracterId"
        Me.NuCaracterId.Size = New System.Drawing.Size(62, 20)
        Me.NuCaracterId.TabIndex = 2
        Me.NuCaracterId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuPosicionBruto
        '
        Me.NuPosicionBruto.Location = New System.Drawing.Point(803, 23)
        Me.NuPosicionBruto.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPosicionBruto.Name = "NuPosicionBruto"
        Me.NuPosicionBruto.Size = New System.Drawing.Size(62, 20)
        Me.NuPosicionBruto.TabIndex = 13
        Me.NuPosicionBruto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NuPosicionID
        '
        Me.NuPosicionID.Location = New System.Drawing.Point(278, 24)
        Me.NuPosicionID.Maximum = New Decimal(New Integer() {999999999, 0, 0, 0})
        Me.NuPosicionID.Name = "NuPosicionID"
        Me.NuPosicionID.Size = New System.Drawing.Size(62, 20)
        Me.NuPosicionID.TabIndex = 1
        Me.NuPosicionID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(9, 26)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(68, 13)
        Me.Label21.TabIndex = 3
        Me.Label21.Text = "Indicador ID:"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(744, 78)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(53, 13)
        Me.Label34.TabIndex = 3
        Me.Label34.Text = "Posicion :"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(744, 52)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(53, 13)
        Me.Label33.TabIndex = 3
        Me.Label33.Text = "Posicion :"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(219, 104)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(53, 13)
        Me.Label26.TabIndex = 3
        Me.Label26.Text = "Posicion :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(219, 52)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Posicion :"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(744, 26)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(53, 13)
        Me.Label32.TabIndex = 3
        Me.Label32.Text = "Posicion :"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(219, 78)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(53, 13)
        Me.Label25.TabIndex = 3
        Me.Label25.Text = "Posicion :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(219, 27)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Posicion :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(9, 104)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(86, 13)
        Me.Label20.TabIndex = 3
        Me.Label20.Text = "Indicador Salida:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(520, 74)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(80, 13)
        Me.Label24.TabIndex = 3
        Me.Label24.Text = "Indicador Neto:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(520, 52)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(79, 13)
        Me.Label23.TabIndex = 3
        Me.Label23.Text = "Indicador Tara:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(871, 78)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(93, 13)
        Me.Label31.TabIndex = 3
        Me.Label31.Text = "No de Caracteres:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(520, 26)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(109, 13)
        Me.Label22.TabIndex = 3
        Me.Label22.Text = "Indicador Peso Bruto:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(871, 52)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(93, 13)
        Me.Label30.TabIndex = 3
        Me.Label30.Text = "No de Caracteres:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(346, 103)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(93, 13)
        Me.Label28.TabIndex = 3
        Me.Label28.Text = "No de Caracteres:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(346, 52)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 13)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "No de Caracteres:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(871, 26)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(93, 13)
        Me.Label29.TabIndex = 3
        Me.Label29.Text = "No de Caracteres:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(346, 78)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(93, 13)
        Me.Label27.TabIndex = 3
        Me.Label27.Text = "No de Caracteres:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(9, 52)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(92, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Indicador Modulo:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(346, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "No de Caracteres:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(9, 78)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(94, 13)
        Me.Label19.TabIndex = 3
        Me.Label19.Text = "Indicador Entrada:"
        '
        'GbPuerto
        '
        Me.GbPuerto.Controls.Add(Me.Label43)
        Me.GbPuerto.Controls.Add(Me.TbReceivedBytesThreshold)
        Me.GbPuerto.Controls.Add(Me.TbWriteBuffersize)
        Me.GbPuerto.Controls.Add(Me.TbReadBuffersize)
        Me.GbPuerto.Controls.Add(Me.CbPlantaElabora)
        Me.GbPuerto.Controls.Add(Me.CbHanshake)
        Me.GbPuerto.Controls.Add(Me.CbStopBits)
        Me.GbPuerto.Controls.Add(Me.CbParity)
        Me.GbPuerto.Controls.Add(Me.CbDataBits)
        Me.GbPuerto.Controls.Add(Me.CbBaudRate)
        Me.GbPuerto.Controls.Add(Me.CbDtrEnable)
        Me.GbPuerto.Controls.Add(Me.CbPuertosSeriales)
        Me.GbPuerto.Controls.Add(Me.Label18)
        Me.GbPuerto.Controls.Add(Me.Label17)
        Me.GbPuerto.Controls.Add(Me.Label16)
        Me.GbPuerto.Controls.Add(Me.Label15)
        Me.GbPuerto.Controls.Add(Me.Label14)
        Me.GbPuerto.Controls.Add(Me.Label44)
        Me.GbPuerto.Controls.Add(Me.Label2)
        Me.GbPuerto.Controls.Add(Me.Label47)
        Me.GbPuerto.Controls.Add(Me.Label46)
        Me.GbPuerto.Controls.Add(Me.Label45)
        Me.GbPuerto.Dock = System.Windows.Forms.DockStyle.Top
        Me.GbPuerto.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GbPuerto.Location = New System.Drawing.Point(0, 0)
        Me.GbPuerto.Name = "GbPuerto"
        Me.GbPuerto.Size = New System.Drawing.Size(1141, 104)
        Me.GbPuerto.TabIndex = 1
        Me.GbPuerto.TabStop = False
        Me.GbPuerto.Text = "Configuraciones Generales"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(10, 30)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(79, 13)
        Me.Label43.TabIndex = 0
        Me.Label43.Text = "Planta Elabora:"
        '
        'CbPlantaElabora
        '
        Me.CbPlantaElabora.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CbPlantaElabora.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbPlantaElabora.FormattingEnabled = True
        Me.CbPlantaElabora.Location = New System.Drawing.Point(91, 27)
        Me.CbPlantaElabora.Name = "CbPlantaElabora"
        Me.CbPlantaElabora.Size = New System.Drawing.Size(121, 21)
        Me.CbPlantaElabora.TabIndex = 0
        '
        'CbStopBits
        '
        Me.CbStopBits.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbStopBits.FormattingEnabled = True
        Me.CbStopBits.Location = New System.Drawing.Point(1014, 27)
        Me.CbStopBits.Name = "CbStopBits"
        Me.CbStopBits.Size = New System.Drawing.Size(93, 21)
        Me.CbStopBits.TabIndex = 5
        '
        'CbParity
        '
        Me.CbParity.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbParity.FormattingEnabled = True
        Me.CbParity.Location = New System.Drawing.Point(831, 27)
        Me.CbParity.Name = "CbParity"
        Me.CbParity.Size = New System.Drawing.Size(93, 21)
        Me.CbParity.TabIndex = 4
        '
        'CbDataBits
        '
        Me.CbDataBits.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbDataBits.FormattingEnabled = True
        Me.CbDataBits.Location = New System.Drawing.Point(680, 27)
        Me.CbDataBits.Name = "CbDataBits"
        Me.CbDataBits.Size = New System.Drawing.Size(93, 21)
        Me.CbDataBits.TabIndex = 3
        '
        'CbBaudRate
        '
        Me.CbBaudRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbBaudRate.FormattingEnabled = True
        Me.CbBaudRate.Location = New System.Drawing.Point(486, 27)
        Me.CbBaudRate.Name = "CbBaudRate"
        Me.CbBaudRate.Size = New System.Drawing.Size(93, 21)
        Me.CbBaudRate.TabIndex = 2
        '
        'CbPuertosSeriales
        '
        Me.CbPuertosSeriales.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbPuertosSeriales.FormattingEnabled = True
        Me.CbPuertosSeriales.Location = New System.Drawing.Point(301, 27)
        Me.CbPuertosSeriales.Name = "CbPuertosSeriales"
        Me.CbPuertosSeriales.Size = New System.Drawing.Size(84, 21)
        Me.CbPuertosSeriales.TabIndex = 1
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(930, 29)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(78, 13)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Bits de parada:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(779, 30)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(46, 13)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "Paridad:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(585, 30)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(71, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Bits de datos:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(391, 30)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(89, 13)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Bits por segundo:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(225, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Puerto Serial:"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.TsNombrePc, Me.TsSeparador, Me.ToolStripStatusLabel2, Me.TsIpComputadora, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel4, Me.TsIdConfiguracion, Me.TsIdConf})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 754)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1141, 22)
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(75, 17)
        Me.ToolStripStatusLabel1.Text = "Nombre PC :"
        '
        'TsNombrePc
        '
        Me.TsNombrePc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.TsNombrePc.Name = "TsNombrePc"
        Me.TsNombrePc.Size = New System.Drawing.Size(0, 17)
        '
        'TsSeparador
        '
        Me.TsSeparador.Name = "TsSeparador"
        Me.TsSeparador.Size = New System.Drawing.Size(10, 17)
        Me.TsSeparador.Text = "|"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(76, 17)
        Me.ToolStripStatusLabel2.Text = "Direccion IP :"
        '
        'TsIpComputadora
        '
        Me.TsIpComputadora.Name = "TsIpComputadora"
        Me.TsIpComputadora.Size = New System.Drawing.Size(0, 17)
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(10, 17)
        Me.ToolStripStatusLabel3.Text = "|"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(103, 17)
        Me.ToolStripStatusLabel4.Text = "ID Configuracion :"
        '
        'TsIdConfiguracion
        '
        Me.TsIdConfiguracion.Name = "TsIdConfiguracion"
        Me.TsIdConfiguracion.Size = New System.Drawing.Size(0, 17)
        '
        'TsIdConf
        '
        Me.TsIdConf.Name = "TsIdConf"
        Me.TsIdConf.Size = New System.Drawing.Size(0, 17)
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GuardarToolStripMenuItem, Me.ModificarToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1141, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'GuardarToolStripMenuItem
        '
        Me.GuardarToolStripMenuItem.Name = "GuardarToolStripMenuItem"
        Me.GuardarToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.GuardarToolStripMenuItem.Text = "Guardar"
        '
        'ModificarToolStripMenuItem
        '
        Me.ModificarToolStripMenuItem.Name = "ModificarToolStripMenuItem"
        Me.ModificarToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.ModificarToolStripMenuItem.Text = "Modificar"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(547, 50)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(97, 13)
        Me.Label48.TabIndex = 3
        Me.Label48.Text = "Posicion del Texto:"
        '
        'CkTextoIzq
        '
        Me.CkTextoIzq.AutoSize = True
        Me.CkTextoIzq.Location = New System.Drawing.Point(650, 50)
        Me.CkTextoIzq.Name = "CkTextoIzq"
        Me.CkTextoIzq.Size = New System.Drawing.Size(139, 17)
        Me.CkTextoIzq.TabIndex = 22
        Me.CkTextoIzq.Text = "Texto a la Izquierda"
        Me.CkTextoIzq.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(391, 64)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(90, 13)
        Me.Label45.TabIndex = 3
        Me.Label45.Text = "Read Buffer Size:"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(585, 64)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(89, 13)
        Me.Label46.TabIndex = 3
        Me.Label46.Text = "Write Buffer Size:"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(779, 64)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(135, 13)
        Me.Label47.TabIndex = 3
        Me.Label47.Text = "Received Bytes Threshold:"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(225, 64)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(62, 13)
        Me.Label44.TabIndex = 0
        Me.Label44.Text = "Estatus Dtr:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(10, 64)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(80, 13)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Control de flujo:"
        '
        'CbDtrEnable
        '
        Me.CbDtrEnable.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbDtrEnable.FormattingEnabled = True
        Me.CbDtrEnable.Location = New System.Drawing.Point(301, 61)
        Me.CbDtrEnable.Name = "CbDtrEnable"
        Me.CbDtrEnable.Size = New System.Drawing.Size(84, 21)
        Me.CbDtrEnable.TabIndex = 7
        '
        'CbHanshake
        '
        Me.CbHanshake.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbHanshake.FormattingEnabled = True
        Me.CbHanshake.Location = New System.Drawing.Point(91, 61)
        Me.CbHanshake.Name = "CbHanshake"
        Me.CbHanshake.Size = New System.Drawing.Size(121, 21)
        Me.CbHanshake.TabIndex = 6
        '
        'TbReadBuffersize
        '
        Me.TbReadBuffersize.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TbReadBuffersize.Location = New System.Drawing.Point(486, 61)
        Me.TbReadBuffersize.Name = "TbReadBuffersize"
        Me.TbReadBuffersize.Size = New System.Drawing.Size(93, 20)
        Me.TbReadBuffersize.TabIndex = 8
        '
        'TbWriteBuffersize
        '
        Me.TbWriteBuffersize.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TbWriteBuffersize.Location = New System.Drawing.Point(680, 61)
        Me.TbWriteBuffersize.Name = "TbWriteBuffersize"
        Me.TbWriteBuffersize.Size = New System.Drawing.Size(93, 20)
        Me.TbWriteBuffersize.TabIndex = 9
        '
        'TbReceivedBytesThreshold
        '
        Me.TbReceivedBytesThreshold.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TbReceivedBytesThreshold.Location = New System.Drawing.Point(920, 61)
        Me.TbReceivedBytesThreshold.Name = "TbReceivedBytesThreshold"
        Me.TbReceivedBytesThreshold.Size = New System.Drawing.Size(88, 20)
        Me.TbReceivedBytesThreshold.TabIndex = 10
        '
        'ConfiguracionParametros
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1141, 776)
        Me.Controls.Add(Me.PanelParametrosBascula)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimumSize = New System.Drawing.Size(1134, 671)
        Me.Name = "ConfiguracionParametros"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Configuracion De Parametros"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.PanelParametrosBascula.ResumeLayout(False)
        Me.GbPruebaSerial.ResumeLayout(False)
        Me.GbPruebaSerial.PerformLayout()
        Me.GbResultado.ResumeLayout(False)
        Me.GbResultado.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.GbPesoPacas.ResumeLayout(False)
        Me.GbPesoPacas.PerformLayout()
        CType(Me.NuPacasCaracterNeto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPacasPosicionNeto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPacasCaracterTara, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPacasPosicionTara, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPacasPosicionBruto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPesoMinimoPaca, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPacasCaracterBruto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GbIdProduccion.ResumeLayout(False)
        Me.GbIdProduccion.PerformLayout()
        CType(Me.NuCaracterNeto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuCaracterSalida, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPosicionNeto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPosicionSalida, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuCaracterModulo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuCaracterTara, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuCaracterEntrada, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPosicionModulo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPosicionTara, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPosicionEntrada, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuCaracterBruto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuCaracterId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPosicionBruto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NuPosicionID, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GbPuerto.ResumeLayout(False)
        Me.GbPuerto.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PanelParametrosBascula As Panel
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents TsNombrePc As ToolStripStatusLabel
    Friend WithEvents TsSeparador As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents TsIpComputadora As ToolStripStatusLabel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GbIdProduccion As GroupBox
    Friend WithEvents GbPuerto As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents CbPuertosSeriales As ComboBox
    Friend WithEvents GbPesoPacas As GroupBox
    Friend WithEvents NuCaracterId As NumericUpDown
    Friend WithEvents NuPosicionID As NumericUpDown
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents GuardarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents TsIdConfiguracion As ToolStripStatusLabel
    Friend WithEvents TsIdConf As ToolStripStatusLabel
    Friend WithEvents TbIndicadorSalida As TextBox
    Friend WithEvents TbIndicadorEntrada As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents TbIndicadorID As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents TbIndicadorNeto As TextBox
    Friend WithEvents TbIndicadorTara As TextBox
    Friend WithEvents TbIndicadorBruto As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents NuCaracterSalida As NumericUpDown
    Friend WithEvents NuPosicionSalida As NumericUpDown
    Friend WithEvents NuCaracterEntrada As NumericUpDown
    Friend WithEvents NuPosicionEntrada As NumericUpDown
    Friend WithEvents NuCaracterNeto As NumericUpDown
    Friend WithEvents NuPosicionNeto As NumericUpDown
    Friend WithEvents NuCaracterTara As NumericUpDown
    Friend WithEvents NuPosicionTara As NumericUpDown
    Friend WithEvents NuCaracterBruto As NumericUpDown
    Friend WithEvents NuPosicionBruto As NumericUpDown
    Friend WithEvents Label34 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents TbPacasIndicadorNeto As TextBox
    Friend WithEvents TbPacasIndicadorTara As TextBox
    Friend WithEvents TbPacasIndicadorBruto As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents NuPacasCaracterNeto As NumericUpDown
    Friend WithEvents Label5 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents NuPacasPosicionNeto As NumericUpDown
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents NuPacasCaracterTara As NumericUpDown
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents NuPacasPosicionTara As NumericUpDown
    Friend WithEvents Label41 As Label
    Friend WithEvents NuPacasPosicionBruto As NumericUpDown
    Friend WithEvents NuPacasCaracterBruto As NumericUpDown
    Friend WithEvents TbIndicadorModulo As TextBox
    Friend WithEvents NuCaracterModulo As NumericUpDown
    Friend WithEvents NuPosicionModulo As NumericUpDown
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents NuPesoMinimoPaca As NumericUpDown
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ModificarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TbCadenaPuertoSerial As TextBox
    Friend WithEvents GbPruebaSerial As GroupBox
    Friend WithEvents BtLimpiar As Button
    Friend WithEvents BtTestPacas As Button
    Friend WithEvents BtTestModulos As Button
    Friend WithEvents LbStatusPuerto As Label
    Friend WithEvents GbResultado As GroupBox
    Friend WithEvents TbModulo As TextBox
    Friend WithEvents TbNeto As TextBox
    Friend WithEvents TbTara As TextBox
    Friend WithEvents TbBruto As TextBox
    Friend WithEvents TbIdCamion As TextBox
    Friend WithEvents Label42 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents BtProbarConfiguracion As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label43 As Label
    Friend WithEvents CbPlantaElabora As ComboBox
    Friend WithEvents CbBaudRate As ComboBox
    Friend WithEvents Label14 As Label
    Friend WithEvents CbStopBits As ComboBox
    Friend WithEvents CbParity As ComboBox
    Friend WithEvents CbDataBits As ComboBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents CkTextoIzq As CheckBox
    Friend WithEvents TbReceivedBytesThreshold As TextBox
    Friend WithEvents TbWriteBuffersize As TextBox
    Friend WithEvents TbReadBuffersize As TextBox
    Friend WithEvents CbHanshake As ComboBox
    Friend WithEvents CbDtrEnable As ComboBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents SpCapturaAuto As IO.Ports.SerialPort
End Class
