IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Sp_InsertaAlmacenEncabezado')
DROP PROCEDURE Sp_InsertaAlmacenEncabezado
GO
Create Procedure Sp_InsertaAlmacenEncabezado
@IdAlmacenEncabezado int output,
@Descripcion varchar(20),
@TipoAlmacen int,
@CantidadLotes int,
@CantidadNiveles int,
@Columnas int,
@Filas int,
@FechaAlta datetime
as
begin
set nocount on
merge AlmacenEncabezado as target
using (select @IdAlmacenEncabezado
			 ,@Descripcion
			 ,@TipoAlmacen
			 ,@CantidadLotes
			 ,@CantidadNiveles
			 ,@Columnas
			 ,@Filas
			 ,@FechaAlta)
as source(IdAlmacenEncabezado
		 ,Descripcion
		 ,TipoAlmacen
		 ,CantidadLotes
		 ,CantidadNiveles
		 ,Columnas
		 ,Filas
		 ,FechaAlta)
on (target.IdAlmacenEncabezado = source.IdAlmacenEncabezado)
when matched then 
update set Descripcion = source.Descripcion,
		   TipoAlmacen = source.TipoAlmacen,
		   CantidadLotes = source.CantidadLotes,
		   CantidadNiveles = source.CantidadNiveles,
		   Columnas = source.Columnas,
		   Filas = source.Filas,
		   FechaAlta = source.FechaAlta
when not matched then
insert(Descripcion,TipoAlmacen,CantidadLotes,CantidadNiveles,Columnas,Filas,FechaAlta)
values(source.Descripcion,source.TipoAlmacen,source.CantidadLotes,source.CantidadNiveles,source.Columnas,source.Filas,source.FechaAlta);
set @IdAlmacenEncabezado = SCOPE_IDENTITY()
end
return @IdAlmacenEncabezado
GO
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Sp_InsertaAlmacenDetalle')
DROP PROCEDURE Sp_InsertaAlmacenDetalle
GO
Create Procedure Sp_InsertaAlmacenDetalle
@IdAlmacenDetalle int,
@IdAlmacenEncabezado int,
@IdLote int,
@Nivel varchar(1),
@PosicionColumna int,
@PosicionFila int,
@BaleID int,
@EstatusAlmacen int
as
begin
set nocount on
merge AlmacenDetalle as target
using (select @IdAlmacenDetalle
			 ,@IdAlmacenEncabezado
			 ,@IdLote
			 ,@Nivel
			 ,@PosicionColumna
			 ,@PosicionFila
			 ,@BaleID
			 ,@EstatusAlmacen
			 )
as source(IdAlmacenDetalle
		 ,IdAlmacenEncabezado
		 ,IdLote
		 ,Nivel
		 ,PosicionColumna
		 ,PosicionFila
		 ,BaleID
		 ,EstatusAlmacen)
on (target.IdAlmacenEncabezado = source.IdAlmacenEncabezado and 
	target.IdLote = source.IdLote and 
	target.Nivel = source.Nivel and
	target.PosicionColumna = source.PosicionColumna and
	target.PosicionFila = source.PosicionFila )
when matched then 
update set IdAlmacenEncabezado = source.IdAlmacenEncabezado,
		   IdLote = source.IdLote,
		   Nivel = source.Nivel,
		   PosicionColumna = source.PosicionColumna,
		   PosicionFila = source.PosicionFila
when not matched then
insert(IdAlmacenEncabezado
	  ,IdLote
	  ,Nivel
	  ,PosicionColumna
	  ,PosicionFila
	  ,BaleID
	  )
values(source.IdAlmacenEncabezado
	  ,source.IdLote
	  ,source.Nivel
	  ,source.PosicionColumna
	  ,source.PosicionFila
	  ,source.BaleID
	  );
end
GO
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Sp_ConsultaAlmacenEncabezado')
DROP PROCEDURE Sp_ConsultaAlmacenEncabezado
GO
Create Procedure Sp_ConsultaAlmacenEncabezado
@IdAlmacenEncabezado int,
@Descripcion varchar(20)
as
if @IdAlmacenEncabezado = 0 and @Descripcion <> ''
	begin
		Select IdAlmacenEncabezado
			  ,Descripcion 
			  ,TipoAlmacen
			  ,CantidadLotes
			  ,CantidadNiveles
			  ,Columnas
			  ,Filas
			  ,FechaAlta
		from   AlmacenEncabezado
		where Descripcion like '%'+@IdAlmacenEncabezado+'%'
	end
else if @IdAlmacenEncabezado > 0 and @Descripcion = ''
	begin
		Select IdAlmacenEncabezado
			  ,Descripcion 
			  ,TipoAlmacen
			  ,CantidadLotes
			  ,CantidadNiveles
			  ,Columnas
			  ,Filas
			  ,FechaAlta
		from   AlmacenEncabezado
		where IdAlmacenEncabezado = @IdAlmacenEncabezado
	end
else
	begin
		Select IdAlmacenEncabezado
			  ,Descripcion 
			  ,TipoAlmacen
			  ,CantidadLotes
			  ,CantidadNiveles
			  ,Columnas
			  ,Filas
			  ,FechaAlta
		from   AlmacenEncabezado
	end	
go
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'sp_ConsultaLoteAlmacen')
DROP PROCEDURE sp_ConsultaLoteAlmacen
GO
Create procedure sp_ConsultaLoteAlmacen
@IdAlmacenEncabezado int ,
@IdLote int ,
@Nivel varchar(1)
as
select IdAlmacenDetalle
	  ,IdAlmacenEncabezado
	  ,IdLote
	  ,Nivel
	  ,PosicionColumna
	  ,PosicionFila
	  ,isnull(BaleID,0) as BaleiD
	  ,ISNULL(EstatusAlmacen,0) as EstatusAlmacen
from AlmacenDetalle
where IdAlmacenEncabezado = @IdAlmacenEncabezado and IdLote = @IdLote and Nivel = @Nivel
order by PosicionFila,PosicionColumna
go
IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Sp_ActualizaAlmacenDetalle')
DROP PROCEDURE Sp_ActualizaAlmacenDetalle
GO
Create Procedure Sp_ActualizaAlmacenDetalle
@IdAlmacenEncabezado int,
@IdLote int,
@Nivel varchar(1),
@PosicionColumna int,
@PosicionFila int,
@BaleID int,
@EstatusAlmacen int
as
update AlmacenDetalle
set baleid = @BaleID,
	EstatusAlmacen = @EstatusAlmacen
where IdAlmacenEncabezado = @IdAlmacenEncabezado and 
	  IdLote = @IdLote and
	  Nivel = @Nivel and
	  PosicionColumna = @PosicionColumna and
	  PosicionFila = @PosicionFila