drop table [dbo].[AlmacenEncabezado]
go
CREATE TABLE [dbo].[AlmacenEncabezado]
(	[IdAlmacenEncabezado] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[Descripcion] [varchar](20) NULL,
	[TipoAlmacen] [int] NULL,
	[CantidadLotes] [int] NULL,
	[CantidadNiveles] [int] NULL,
	[Columnas] [int] NULL,
	[Filas] [int] NULL,
	[FechaAlta] [datetime] NULL)
go
drop table [dbo].[AlmacenDetalle]
CREATE TABLE [dbo].[AlmacenDetalle](
	[IdAlmacenDetalle] [int] PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[IdAlmacenEncabezado] [int] NULL,
	[IdLote] [int] NULL,
	[Nivel] [varchar](1) NULL,
	[PosicionColumna] [int] NULL,
	[PosicionFila] [int] NULL,
	[BaleID] [int] NULL,
	[EstatusAlmacen] [int] NULL)